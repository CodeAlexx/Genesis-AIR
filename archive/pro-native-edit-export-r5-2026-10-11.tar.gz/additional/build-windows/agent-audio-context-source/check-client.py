from pathlib import Path
import array,hashlib,json,math,shutil,subprocess,wave
import numpy as np
root=Path(__file__).resolve().parent
source=root.parent/'agent-audio-edit-history/cases'
work=root/'client-first';work.mkdir(exist_ok=False)
names=['compressor','gate','limiter','plain']
for name in names:shutil.copyfile(source/(name+'.air'),work/(name+'.air'))
(work/'cases.tsv').write_text('\n'.join(names)+'\n')
worker=root/'runtime/genesis-gcompose.exe';client=root/'native/Release/audio-context.exe'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
hashes={str(p):sha(p) for p in [worker,client]+[source/(n+'-authored.wav') for n in names]}
report={'passed':False,'hashes':hashes,'cases':[]}
def pcm(path):
 with wave.open(str(path),'rb') as f:return np.frombuffer(f.readframes(f.getnframes()),dtype='<i2').reshape(-1,2).copy()
try:
 run=subprocess.run([str(client),str(worker),str(work)],capture_output=True,timeout=120,creationflags=subprocess.CREATE_NO_WINDOW)
 (work/'stdout.log').write_bytes(run.stdout);(work/'stderr.log').write_bytes(run.stderr)
 assert run.returncode==0,(run.returncode,run.stdout,run.stderr[-2000:])
 for name in names:
  raw=np.frombuffer((source/(name+'-independent-reference.stdout.log')).read_bytes(),dtype='<f4').reshape(-1,2)
  expected=np.sign(raw)*np.floor(np.abs(np.clip(raw,-1,1))*32767+.5)
  for variant in ('original','split','head','tail','repeated'):
   target=expected.copy()
   if variant=='head':target[:96000]=0
   elif variant=='tail':target=target[:96000]
   elif variant=='repeated':target[96000:120000]=0
   prefix=work/(name+'-'+variant)
   got=pcm(prefix.with_suffix('.wav'));assert got.shape==target.shape,(name,variant,got.shape,target.shape)
   err=float(np.max(np.abs(got-target)));assert err<=1,(name,variant,err)
   chunks=np.concatenate([pcm(Path(p)) for p in (work/(name+'-'+variant+'-pulls.txt')).read_text().splitlines()])
   ce=float(np.max(np.abs(chunks-target)));assert chunks.shape==target.shape and ce<=1,(name,variant,ce)
   graph=json.loads(prefix.with_suffix('.air').read_text())
   assert graph['revision']==(2 if variant=='original' else 3),(name,variant,graph['revision'])
   for clip in graph['clips']:
    start=round(clip['start']*1600);end=round((clip['start']+clip['length'])*1600)
    visible=raw[start:end]
    # Only the post-Split/head retained body exists; encoded context records
    # source crop, rather than changing the independent original DSP reference.
    n=600
    expected_peaks=np.array([np.max(np.abs(visible[k*len(visible)//n:(k+1)*len(visible)//n]),initial=0.) for k in range(n)])
    actual=np.loadtxt(work/(name+'-'+variant+'-peaks-'+str(clip['id'])+'.txt'))
    pe=float(np.max(np.abs(actual-expected_peaks)));assert pe<=2e-6,(name,variant,clip['id'],pe)
   report['cases'].append({'effect':name,'operation':variant,'maximum_whole_pcm_error':err,'maximum_retained_pcm_error':ce,'graph_revision':graph['revision'],'all_body_peaks_checked':True})
 assert all(sha(Path(p))==h for p,h in hashes.items())
 report['passed']=True
finally:(work/'report.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
