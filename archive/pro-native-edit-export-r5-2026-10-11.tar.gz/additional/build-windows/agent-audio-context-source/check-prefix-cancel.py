from pathlib import Path
import hashlib,json,sys
base=Path(__file__).resolve().parent;sys.path.insert(0,str(base.parents[1]/'tests'))
from audio_edit_context import cancel_prefix
root=base/'prefix-cancel-first';root.mkdir(exist_ok=False)
worker=(base/'runtime-stream-bounded/genesis-gcompose.exe').resolve()
client=(base/'qualified-native/Release/audio-context-qualified.exe').resolve()
doc=json.loads((base/'audio-edit-context-181rve0z/compressor.air').read_text(encoding='utf8'))
report={'passed':False,'worker_sha256':hashlib.sha256(worker.read_bytes()).hexdigest(),'client_sha256':hashlib.sha256(client.read_bytes()).hexdigest()}
try:report.update(cancel_prefix(root,client,worker,doc));report['passed']=True
finally:(root/'report.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf8')
print(json.dumps(report,indent=2))
