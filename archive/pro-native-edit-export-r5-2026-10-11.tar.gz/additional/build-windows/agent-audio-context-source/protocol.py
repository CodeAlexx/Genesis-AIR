from pathlib import Path
import array,hashlib,json,math,os,subprocess,sys,time,wave
import numpy as np
root=Path(__file__).resolve().parent;repo=root.parents[1]
sys.path.insert(0,str(repo/'tests'))
from nested_waveforms import Worker,buckets,data_offset
from audio_stream import wire
from media_runtime import tool
worker=root/'runtime/genesis-gcompose.exe'
output=root/'protocol-first';output.mkdir(exist_ok=False)
source_root=repo/'build-windows/agent-audio-edit-history/cases'
SR=48000;full=SR*4;crop=SR*2;body=SR*2
specs=[('compressor','acompressor=threshold='+str(10**(-24/20))+':ratio=12:attack=80:release=1200'),
       ('gate','agate=threshold='+str(10**(-18/20))+':release=1200'),
       ('limiter','alimiter=limit='+str(10**(-12/20))+':level=disabled'),('plain','-')]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
report={'passed':False,'worker_sha256':sha(worker),'cases':[],'refusals':[]}
def rows(source,chain,token='',bus_context=False):
    leaf=f'NESTLEAF bus.leaf bus 96000 192000 {wire(source)} 2 2 1 0 0 2 {chain}'
    bus='NESTBUS bus - 96000 192000 96000 192000 1 0 0 2 -'
    if token:
        if bus_context:bus+=' '+token
        else:leaf+=' '+token
    return [leaf,bus]
def define(p,cache,definitions):
    p.command('NESTBEGIN '+wire(cache))
    for line in definitions:p.command(line)
try:
  for name,chain in specs:
    source=source_root/(name+'-authored.wav');original=sha(source)
    cmd=[str(tool(worker,'ffmpeg')),'-nostdin','-v','error','-i',str(source),'-af',chain if chain!='-' else 'anull','-f','f32le','pipe:1']
    ref=subprocess.run(cmd,capture_output=True,timeout=30,creationflags=subprocess.CREATE_NO_WINDOW);assert ref.returncode==0,ref.stderr
    expected=np.frombuffer(ref.stdout,dtype='<f4').reshape(-1,2)[crop:crop+body];assert len(expected)==body
    cache=output/name;cache.mkdir();p=Worker(worker)
    try:
      definitions=rows(source,chain,'AUDIOCTX:0:4:192000:96000')
      define(p,cache,definitions);start=time.perf_counter();p.command('NESTCOMMIT');elapsed=time.perf_counter()-start
      raw=next(cache.glob('*-0-output.rf64')).read_bytes();actual=np.frombuffer(raw,dtype='<f4',offset=data_offset(raw)).reshape(-1,2)
      error=float(np.max(np.abs(actual-expected)));assert error<=2e-6,(name,error)
      wav=output/(name+'.wav');p.command(f'PLAYWAVE {wire(wav)} {body}');p.command('NESTMIX bus 96000 192000 0');p.command('WAVECLOSE '+wire(wav))
      with wave.open(str(wav),'rb') as r:pcm=np.frombuffer(r.readframes(r.getnframes()),dtype='<i2').reshape(-1,2)
      wanted=np.sign(expected)*np.floor(np.abs(np.clip(expected,-1,1))*32767+.5)
      pcmerror=float(np.max(np.abs(pcm-wanted)));assert pcmerror<=1,(name,pcmerror)
      for n in (600,25567,65536):
        path=cache/f'env{n}.f32';define(p,cache,definitions);p.command(f'NESTPEAK bus {n} {wire(path)}')
        peaks=np.frombuffer(path.read_bytes(),dtype='<f4');wanted=buckets(array.array('f',expected.flatten()),n)
        pe=float(np.max(np.abs(peaks-np.array(wanted))));assert pe<=2e-6,(name,n,pe)
        report['cases'].append(dict(effect=name,buckets=n,float_maximum_error=error,pcm_maximum_error=pcmerror,peak_maximum_error=pe,cold_commit_seconds=elapsed,source_immutable=sha(source)==original))
    finally:p.close()
    assert not list(cache.glob('*.rf64'));assert sha(source)==original
  # Malformed context must refuse before any accepted cache/source mutation and
  # subsequent valid processing must recover in this same retained worker.
  cache=output/'refusals';cache.mkdir();p=Worker(worker);source=source_root/'plain-authored.wav'
  try:
    valid=rows(source,'-','AUDIOCTX:0:4:192000:96000');define(p,cache,valid);p.command('NESTCOMMIT')
    for token in ('AUDIOCTX:0:4:192000:192000','AUDIOCTX:0:4:192000:96002','AUDIOCTX:nan:4:192000:96000','AUDIOCTX:0:0:192000:96000','AUDIOCTX:0:4:0:0','AUDIOCTX:0:4:1036800001:96000','AUDIOCTX:0:4:192000:96000 AUDIOCTX:0:4:192000:96000'):
      before={f.name:sha(f) for f in cache.iterdir()};p.command('NESTBEGIN '+wire(cache));p.command(rows(source,'-',token)[0],'GA_AUDIO_CONTEXT')
      assert {f.name:sha(f) for f in cache.iterdir()}==before
      path=cache/f'recovery{len(report["refusals"])}.f32';p.command(f'NESTENV bus 3 {wire(path)}')
      assert np.frombuffer(path.read_bytes(),dtype='<f4').min()>0
      report['refusals'].append(dict(token=token,retained_cache_unchanged=True,same_worker_recovered=True))
  finally:p.close()
  assert not list(cache.glob('*.rf64'))
  report['passed']=True
finally:
  (output/'report.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
