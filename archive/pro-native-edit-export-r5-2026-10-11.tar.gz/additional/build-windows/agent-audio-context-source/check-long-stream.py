from pathlib import Path
import ctypes,hashlib,json,subprocess,sys,time
import numpy as np
base=Path(__file__).resolve().parent;repo=base.parents[1];sys.path.insert(0,str(repo/'tests'))
from nested_waveforms import Worker
from audio_stream import wire
from audio_edit_context import pcm,quantize
from media_runtime import tool
worker=base/'runtime-stream-final/genesis-gcompose.exe';source_info=json.loads((repo/'build-windows/1080p-test-media.json').read_text(encoding='utf8'))
source=Path(source_info['path']);root=base/'long-stream-final-2';root.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
before=sha(source);assert before==source_info['sha256'].lower()
duration=1278.35;total=61360800;count=24000
chain='equalizer=f=100:t=q:w=1:g=2.5,equalizer=f=1000:t=q:w=1:g=0,equalizer=f=8000:t=q:w=1:g=0'
ffmpeg=tool(worker,'ffmpeg');report={'passed':False,'source_sha256':before,'worker_sha256':sha(worker),'body_frames':total,'requests':[]}
def reference(crop):
 stages=f'atrim=start_sample=0:end_sample=56375235,asetpts=N/SR/TB,aresample=48000,aformat=sample_fmts=flt:sample_rates=48000:channel_layouts=stereo,{chain},atrim=start_sample={crop}:end_sample={crop+count}'
 r=subprocess.run([str(ffmpeg),'-nostdin','-v','error','-i',str(source),'-map','0:a:0','-af',stages,'-f','f32le','pipe:1'],capture_output=True,timeout=120,creationflags=0x08000000)
 assert r.returncode==0,r.stderr
 values=np.frombuffer(r.stdout,dtype='<f4').reshape(-1,2);assert len(values)==count
 return quantize(values)
class Counters(ctypes.Structure):
 _fields_=[('cb',ctypes.c_uint32),('PageFaultCount',ctypes.c_uint32)]+[(n,ctypes.c_size_t) for n in ('PeakWorkingSetSize','WorkingSetSize','QuotaPeakPagedPoolUsage','QuotaPagedPoolUsage','QuotaPeakNonPagedPoolUsage','QuotaNonPagedPoolUsage','PagefileUsage','PeakPagefileUsage')]
def memory(p):
 c=Counters();c.cb=ctypes.sizeof(c)
 dll=ctypes.WinDLL('psapi');dll.GetProcessMemoryInfo.argtypes=[ctypes.c_void_p,ctypes.POINTER(Counters),ctypes.c_uint32]
 assert dll.GetProcessMemoryInfo(int(p.process._handle),ctypes.byref(c),c.cb)
 return {'working_set_bytes':c.WorkingSetSize,'peak_working_set_bytes':c.PeakWorkingSetSize,'private_commit_bytes':c.PagefileUsage}
for start in (0,57600000):
 p=Worker(worker)
 try:
  for index,crop in enumerate((start,start+count)):
   out=root/f'{start}-{index}.wav';p.command(f'PLAYWAVE {wire(out)} {count}')
   row=f'AUDIOSTREAM {wire(source)} {crop/48000} 0.5 0 1 0 0 {duration} {crop/48000} {chain} 20 {duration-crop/48000} {count} AUDIOCTX:0:{duration}:{total}:{crop}:{count}'
   begin=time.perf_counter();p.command(row);elapsed=time.perf_counter()-begin
   p.command('WAVECLOSE '+wire(out));actual=pcm(out);wanted=reference(crop)
   error=int(np.max(np.abs(actual.astype(np.int32)-wanted.astype(np.int32))));assert error<=1,(crop,error)
   assert not list(root.rglob('*.rf64'))
   report['requests'].append({'crop':crop,'frames':count,'cold_original_prefix_seconds':elapsed,'retained':index>0,'maximum_pcm_error':error,'nonzero_values':int(np.count_nonzero(actual)),**memory(p)})
 finally:p.close()
report.update(passed=True,source_immutable=sha(source)==before,worker_closed=True,no_rf64_intermediate=True)
(root/'report.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf8');print(json.dumps(report,indent=2))
