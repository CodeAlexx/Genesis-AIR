from pathlib import Path
import hashlib,json,subprocess,sys,time,wave
import numpy as np
base=Path(__file__).resolve().parent;repo=base.parents[1]
sys.path.insert(0,str(repo/'tests'))
from nested_waveforms import Worker
from audio_stream import wire
from audio_edit_context import pcm,quantize
from media_runtime import tool
worker=base/'runtime-stream-final/genesis-gcompose.exe'
root=base/'stream-contract-final';root.mkdir(exist_ok=False)
source=base.parent/'agent-audio-edit-history/cases/plain-authored.wav'
chain='acompressor=threshold='+str(10**(-24/20))+':ratio=12:attack=80:release=1200'
ffmpeg=tool(worker,'ffmpeg')
def raw(fx):
 r=subprocess.run([str(ffmpeg),'-nostdin','-v','error','-i',str(source),'-af',fx,'-f','f32le','pipe:1'],capture_output=True,timeout=30,creationflags=0x08000000)
 assert r.returncode==0,r.stderr
 return np.frombuffer(r.stdout,dtype='<f4').reshape(-1,2).copy()
expected=quantize(raw(chain));report={'passed':False,'worker_sha256':hashlib.sha256(worker.read_bytes()).hexdigest(),'refusals':[],'tails':[]}
def line(crop,count,token=None,remaining='4',path=source):
 token=token or f'AUDIOCTX:0:4:192000:{crop}:{count}'
 return f'AUDIOSTREAM {wire(path)} {crop/48000} {count/48000} 0 1 0 0 4 {crop/48000} {chain} 99 {remaining} {count} {token}'
p=Worker(worker)
try:
 cursor=0
 for case,token,remaining,path in [('prime',None,'4',source),('nan','AUDIOCTX:nan:4:192000:4800:4800','4',source),('count','AUDIOCTX:0:4:192000:9600:4799','4',source),('overflow','AUDIOCTX:0:4:192000:192000:4800','4',source),('duplicate','AUDIOCTX:0:4:192000:19200:4800 AUDIOCTX:0:4:192000:19200:4800','4',source),('identity','AUDIOCTX:0.1:4:192000:24000:4800','4',source),('duration',None,'nan',source),('missingpath',None,'4',root/'missing.wav')]:
  out=root/(case+'.wav');p.command(f'PLAYWAVE {wire(out)} 4800')
  if case!='prime':
   bad=token or f'AUDIOCTX:0:4:192000:{cursor}:4800'
   p.command(line(cursor,4800,bad,remaining,path),'GA_AUDIO_CONTEXT')
  p.command(line(cursor,4800));p.command('WAVECLOSE '+wire(out))
  got=pcm(out);err=int(np.max(np.abs(got.astype(np.int32)-expected[cursor:cursor+4800].astype(np.int32))))
  assert got.shape==(4800,2) and err<=1,(case,err)
  if case!='prime':report['refusals'].append({'case':case,'valid_continuation_max_pcm_error':err,'retained_decoder_preserved':True})
  cursor+=4800
finally:p.close()
p=Worker(worker)
try:
 out=root/'one-endpoint.wav';p.command(f'PLAYWAVE {wire(out)} 2');p.command(line(191999,2));p.command('WAVECLOSE '+wire(out))
 got=pcm(out);assert np.array_equal(got[0],expected[-1]) and np.array_equal(got[1],[0,0])
 report['one_endpoint_zero_pad_exact']=True
finally:p.close()
for name,fx in [('compressor',chain),('gate','agate=threshold='+str(10**(-18/20))+':release=1200'),('limiter','alimiter=limit='+str(10**(-12/20))+':level=disabled'),('eq','equalizer=f=100:t=q:w=1:g=4.5,equalizer=f=1000:t=q:w=1:g=-2,equalizer=f=8000:t=q:w=1:g=1.5'),('normalize','loudnorm=I=-14'),('tempo15','atempo=1.5,'+chain),('tempo05','atempo=0.5,'+chain)]:
 speed=1.5 if name=='tempo15' else .5 if name=='tempo05' else 1
 duration=4*speed
 p=Worker(worker)
 try:
  a=root/(name+'-legacy.wav');b=root/(name+'-context.wav')
  for out,ctx in ((a,''),(b,f' AUDIOCTX:0:{duration}:192000:0:192000')):
   p.command(f'WAVE {wire(out)} 8');p.command(f'AUDIO {wire(source)} 0 {duration} 0 1 0 0 4 0 {fx}{ctx}');p.command('WAVECLOSE '+wire(out))
  old,new=pcm(a),pcm(b);error=int(np.max(np.abs(old.astype(np.int32)-new.astype(np.int32))))
  tail=int(np.count_nonzero(old[192000:]));report['tails'].append({'effect':name,'maximum_pcm_error':error,'legacy_after_body_nonzero_values':tail})
  assert error<=1 and tail==0,(name,error,tail)
 finally:p.close()
report['passed']=True
(root/'report.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf8')
print(json.dumps(report,indent=2))
