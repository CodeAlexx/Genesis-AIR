param([string]$OutputName="runtime-final")
$ErrorActionPreference = 'Stop'
$repo = (Resolve-Path (Join-Path $PSScriptRoot '../..')).Path
$deps = Join-Path $repo 'build-windows/deps'
$ffmpeg = Get-Content (Join-Path $repo 'windows/ffmpeg-source.json') -Raw | ConvertFrom-Json
$env:CARGO_HOME = Join-Path $deps 'cargo'
$env:RUSTUP_HOME = Join-Path $deps 'rustup'
$env:GENESIS_FFMPEG_SDK = Join-Path $deps ('ffmpeg-pinned/' + $ffmpeg.name.Replace('.zip',''))
$env:GENESIS_OPENCL_HEADERS = Join-Path $deps 'OpenCL-Headers'
$env:GENESIS_OPENCL_LIB = Join-Path $deps 'opencl-build/Release'
$env:GENESIS_WINDOWS_COMPAT = Join-Path $repo 'windows/compat'
$env:GENESIS_FFMPEG_IMPORTS = Join-Path $deps 'ffmpeg-msvc-imports'
$env:CARGO_TARGET_DIR = Join-Path $PSScriptRoot 'target'
$vswhere = Join-Path ${env:ProgramFiles(x86)} 'Microsoft Visual Studio/Installer/vswhere.exe'
$vs = (& $vswhere -latest -products '*' -requires Microsoft.VisualStudio.Component.VC.Tools.x86.x64 -property installationPath | Select-Object -First 1)
$dev = Join-Path $vs 'Common7/Tools/VsDevCmd.bat'
$environmentLines = & cmd.exe /d /s /c "`"$dev`" -arch=x64 -host_arch=x64 >nul && set"
if ($LASTEXITCODE -ne 0) { throw 'MSVC environment failed' }
foreach ($line in $environmentLines) {
  if ($line -match '^([^=]+)=(.*)$') { [Environment]::SetEnvironmentVariable($matches[1],$matches[2],'Process') }
}
$cargo = Join-Path $deps 'cargo/bin/cargo.exe'
$version = & (Join-Path $deps 'cargo/bin/rustc.exe') --version
$toolchain = if ($version -match '^rustc 1\.98\.1 ') {'+stable'} else {'+1.98.1'}
& $cargo $toolchain build --release --locked --manifest-path (Join-Path $PSScriptRoot 'gcompose/Cargo.toml') *> (Join-Path $PSScriptRoot 'build.log')
if ($LASTEXITCODE -ne 0) { Get-Content (Join-Path $PSScriptRoot 'build.log') -Tail 60; throw 'Private worker build failed' }
$destination = Join-Path $PSScriptRoot $OutputName
New-Item -ItemType Directory -Force -Path $destination | Out-Null
Copy-Item -LiteralPath (Join-Path $PSScriptRoot 'target/release/gcompose.exe') -Destination (Join-Path $destination 'genesis-gcompose.exe')
& (Join-Path $repo 'windows/share-media-runtime.ps1') -Sdk $env:GENESIS_FFMPEG_SDK -Destination $destination -MmAirRoot 'C:\MM-Air'
Copy-Item -LiteralPath (Join-Path $env:GENESIS_OPENCL_LIB 'OpenCL.dll') -Destination $destination
Get-FileHash -Algorithm SHA256 (Join-Path $destination 'genesis-gcompose.exe')
