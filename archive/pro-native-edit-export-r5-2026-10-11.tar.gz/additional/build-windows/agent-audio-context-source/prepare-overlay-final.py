from pathlib import Path
import difflib,hashlib,json,re,subprocess
base=Path(__file__).resolve().parent;repo=base.parents[1];canonical=repo/'build-windows/gcompose-source'
sha=lambda data:hashlib.sha256(data).hexdigest()
lf=lambda data:data.replace(b'\r\n',b'\n')
maintained=(repo/'windows/gcompose-windows.patch').read_bytes();key=b'diff --git a/gcompose/src/main.rs b/gcompose/src/main.rs'
prefix=maintained[:maintained.index(key)]
old=subprocess.check_output(['git','-C',str(canonical),'show','HEAD:gcompose/src/main.rs'])
new=(base/'gcompose/src/main.rs').read_bytes()
hunk=''.join(difflib.unified_diff(lf(old).decode('utf8').splitlines(True),lf(new).decode('utf8').splitlines(True),fromfile='a/gcompose/src/main.rs',tofile='b/gcompose/src/main.rs'))
patch=prefix+key+b'\n'+hunk.encode('utf8');proposed=base/'proposed-gcompose-stream-final.patch';proposed.write_bytes(patch)
proof=base/'overlay-proof-stream-final';proof.mkdir(exist_ok=False)
subprocess.run(['git','init','-q',str(proof)],check=True)
files=re.findall(rb'^diff --git a/(\S+) b/',patch,re.M);originals={}
for encoded in files:
 name=encoded.decode();data=subprocess.check_output(['git','-C',str(canonical),'show','HEAD:'+name]);originals[name]=data
 target=proof/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data)
def apply(*args):subprocess.run(['git','-C',str(proof),'apply',*args,str(proposed.resolve())],check=True)
apply('--check');apply();hashes={}
for name in originals:
 actual=lf((proof/name).read_bytes());expected=lf((base/name).read_bytes())
 assert actual==expected,name;hashes[name]=sha(actual)
apply('--reverse','--check');apply('--reverse')
assert all(lf((proof/n).read_bytes())==lf(v) for n,v in originals.items())
apply('--check');apply()
report=dict(pinned_commit=subprocess.check_output(['git','-C',str(canonical),'rev-parse','HEAD'],text=True).strip(),
 proposed_patch_sha256=sha(patch),unchanged_six_blocks_byte_exact=patch[:patch.index(key)]==prefix,
 forward_reverse_normalized_lf_byte_exact=True,applied_lf_hashes=hashes,
 canonical_main_before_sha256=sha((canonical/'gcompose/src/main.rs').read_bytes()),private_main_sha256=sha(new))
(base/'overlay-proof-stream-final.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf8');print(json.dumps(report,indent=2))
