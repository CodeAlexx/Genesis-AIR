from pathlib import Path
import hashlib,json,subprocess
base=Path(__file__).resolve().parent;repo=base.parents[1];canonical=repo/'build-windows/gcompose-source/gcompose'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
baseline=json.loads((base/'baseline.json').read_text(encoding='utf8'))
assert all(sha(canonical/name)==digest for name,digest in baseline['files'].items()),'Canonical source drifted before migration'
proof=json.loads((base/'overlay-proof-audio-history.json').read_text(encoding='utf8'))
source=base/'gcompose/src/main.rs';patch=base/'proposed-gcompose-audio-history.patch';maintained=repo/'windows/gcompose-windows.patch'
assert sha(source)==proof['private_main_sha256'] and sha(patch)==proof['proposed_patch_sha256']
matrix=json.loads((base/'matrix-final.json').read_text(encoding='utf8'));assert matrix['passed']
worker=base/'runtime-stream-tail/genesis-gcompose.exe';assert sha(worker)==matrix['worker_sha256']
oldpatch=maintained.read_bytes();key=b'diff --git a/gcompose/src/main.rs b/gcompose/src/main.rs'
assert oldpatch[:oldpatch.index(key)]==patch.read_bytes()[:patch.read_bytes().index(key)]
(base/'canonical-main-before.rs').write_bytes((canonical/'src/main.rs').read_bytes())
(base/'maintained-overlay-before.patch').write_bytes(oldpatch)
maintained.write_bytes(patch.read_bytes());(canonical/'src/main.rs').write_bytes(source.read_bytes())
subprocess.run(['git','-C',str(canonical.parent),'apply','--reverse','--check',str(maintained)],check=True)
for name,digest in baseline['files'].items():
 if name.replace('\\','/')!='src/main.rs':assert sha(canonical/name)==digest,name
assert (canonical/'src/main.rs').read_bytes()==source.read_bytes()
tracked=('src/timeline_media.ai','tests/audio_edit_context.ai','tests/audio_edit_context.py','windows/gcompose-windows.patch')
report=dict(schema='genesis.audio-history.source-migration.v1',production={name:sha(repo/name) for name in tracked},
 canonical_main_before_sha256=baseline['files']['src\\main.rs'],canonical_main_after_sha256=sha(source),
 canonical_private_main_byte_exact=True,all_other_canonical_files_byte_exact=True,unrelated_six_patch_blocks_byte_exact=True,
 canonical_reverse_apply_check=True,pinned_commit=proof['pinned_commit'],worker_sha256=sha(worker),
 client_sha256=matrix['client_sha256'],binary_sha256=matrix['binary_sha256'],matrix_report_sha256=sha(base/'matrix-final.json'))
(base/'final-source-receipt.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf8');print(json.dumps(report,indent=2))
