from pathlib import Path
import hashlib,json,sys,wave
import numpy as np
root=Path(__file__).resolve().parent;sys.path.insert(0,str(root.parents[1]/'tests'))
from nested_waveforms import Worker
from audio_stream import wire
worker=root/'runtime/genesis-gcompose.exe'
source=root.parent/'agent-audio-edit-history/cases/plain-authored.wav'
work=root/'tails-first';work.mkdir(exist_ok=False)
results=[]
def pcm(path):
 with wave.open(str(path),'rb') as f:return np.frombuffer(f.readframes(f.getnframes()),dtype='<i2').reshape(-1,2)
for name,chain in [('delay','aecho=0.8:0.9:250:0.4'),('reverb','aecho=0.8:0.9:47|97|151|211:0.15|0.12|0.09|0.06')]:
 p=Worker(worker);cache=work/name;cache.mkdir()
 try:
  original=work/(name+'-legacy.wav');new=work/(name+'-context.wav')
  p.command(f'WAVE {wire(original)} 8');p.command(f'AUDIO {wire(source)} 0 4 0 1 0 0 4 0 {chain}');p.command('WAVECLOSE '+wire(original))
  p.command('NESTBEGIN '+wire(cache))
  for index,start in enumerate((0,96000)):
   end=start+96000;ident='bus'+str(index)
   p.command(f'NESTLEAF {ident}.leaf {ident} {start} {end} {wire(source)} {index*2} 2 1 0 0 2 {chain} AUDIOCTX:0:4:192000:{start}')
   p.command(f'NESTBUS {ident} - {start} {end} {start} {end} 1 0 0 2 -')
  p.command('NESTCOMMIT');p.command(f'WAVE {wire(new)} 8')
  p.command('NESTMIX bus0 0 96000 0');p.command('NESTMIX bus1 96000 192000 96000');p.command('WAVECLOSE '+wire(new))
  a=pcm(original);b=pcm(new);assert a.shape==b.shape==(384000,2)
  assert np.array_equal(a[:192000],b[:192000])
  tail_nonzero=int(np.count_nonzero(a[192000:]));loss=int(np.max(np.abs(a[192000:].astype(np.int32)-b[192000:].astype(np.int32))))
  assert tail_nonzero and loss
  results.append(dict(effect=name,authored_body_sample_values_exact=True,legacy_after_body_nonzero_values=tail_nonzero,context_tail_loss_maximum_pcm_codes=loss,legacy_tail_policy_requires_explicit_repair=True))
 finally:p.close()
(work/'report.json').write_text(json.dumps(dict(worker_sha256=hashlib.sha256(worker.read_bytes()).hexdigest(),results=results),indent=2)+'\n')
print(json.dumps(results,indent=2))
