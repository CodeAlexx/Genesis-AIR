from pathlib import Path
import hashlib,json,sys
import numpy as np
base=Path(__file__).resolve().parent;sys.path.insert(0,str(base.parents[1]/'tests'))
from audio_edit_context import stream_contract,edited_tails,cancel_prefix,run
from media_runtime import tool
root=base/'tail-focused-final';root.mkdir(exist_ok=False)
worker=(base/'runtime-stream-tail/genesis-gcompose.exe').resolve();client=(base/'tail-native/Release/audio-context-tail.exe').resolve()
previous=base/'audio-edit-context-ipph1kj8';source=next(previous.glob('authored 48000*.wav'))
docs={name:json.loads((previous/(name+'.air')).read_text(encoding='utf8')) for name in ('tempo15','tempo05','compressor')}
chain='acompressor=threshold='+str(10**(-24/20))+':ratio=12:attack=80:release=1200';ffmpeg=tool(worker,'ffmpeg')
data=run([ffmpeg,'-nostdin','-v','error','-i',source,'-af','atrim=start_sample=0:end_sample=192000,asetpts=N/SR/TB,aresample=48000,aformat=sample_fmts=flt:sample_rates=48000:channel_layouts=stereo,'+chain,'-f','f32le','pipe:1'])
raw=np.frombuffer(data,dtype='<f4').reshape(-1,2)
report={'passed':False,'worker_sha256':hashlib.sha256(worker.read_bytes()).hexdigest()}
try:
 report['protocol']=stream_contract(root,worker,source,raw,ffmpeg)
 report['edited_tails']=edited_tails(root,client,worker,ffmpeg,docs,source)
 report['cancellation']=cancel_prefix(root,client,worker,docs['compressor']);report['passed']=True
finally:(root/'report.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf8')
print(json.dumps(report,indent=2))
