"""Explicit r5 archive invocation. Run only after publication, root-ready and staging.

This file does not publish, stage, test, launch an app, or alter existing proofs.
It requires both cadence summaries and all named histories before invoking the
existing strict archive builder. The builder owns sanitization/index checks.
"""
from pathlib import Path
import argparse
import hashlib
import json
import runpy
import sys

ROOT = Path(__file__).resolve().parents[2]
WORK = ROOT / "build-windows"
PREFIX = "pro-native-edit-export-r5-2026-10-11"
BASE = WORK / PREFIX
PAYLOAD = {
    "app_sha256": "b07975912822d2d8a19fbcc4ac89ec21f4a7e7f797f041ad94b66e25173b4b74",
    "worker_sha256": "a8e662712fd9812011b783b3abe8b239a17b1bddbb45434a2bf974c34a4495b7",
    "audio_library_sha256": "75f931f6313ffab3fa10d1b5bb49a68c7d643b2126094fd6131dd555e9d7d4ba",
}
TEXT = {".json", ".txt", ".log", ".exit", ".tsv", ".md", ".py",
        ".ps1", ".sh", ".ai", ".patch", ".toml", ".cmake", ".h", ".lock"}
PRIOR = (
    "pro-native-edit-export-2026-10-11",
    "pro-native-edit-export-r2-2026-10-11",
    "pro-native-edit-export-r3-2026-10-11",
    "pro-native-edit-export-r4-2026-10-11",
    PREFIX,
)
COMPONENTS = (
    "agent-title-caret", "agent-keyframe-controls", "agent-audio-context",
    "agent-audio-edit-history", "agent-compound-context-investigation",
    "agent-snap-candidate", "agent-export-ownership", "agent-export-session-path",
    "agent-recorder-retention-r5", "agent-preview-stream-r3",
    "agent-nested-context-maintained", "agent-nested-context-audit",
)
AUDIO_PROOFS = (
    "protocol-first", "prefix-cancel-first", "stream-contract-final",
    "long-stream-final", "long-stream-final-2", "long-stream-tail",
    "tail-focused-final", "tail-focused-final-2", "tails-first",
    "overlay-proof", "overlay-proof-audio-history", "overlay-proof-stream-final",
)


def require(condition, message):
    if not condition:
        raise ValueError(message)


def owned(value, directory=False):
    path = Path(value)
    if not path.is_absolute():
        path = ROOT / path
    resolved = path.resolve(strict=True)
    require(resolved.is_relative_to(WORK), "Evidence outside build-windows: " + str(path))
    require(not path.is_symlink(), "Symlink proof refused: " + str(path))
    require(resolved.is_dir() if directory else resolved.is_file(), "Wrong proof type: " + str(path))
    return resolved


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--cadence-4k", type=Path,
                        default=BASE / "cadence-4k/attempt1/accepted-summary.json",
                        help="Exact accepted 4K attempt, if different from attempt1")
    parser.add_argument("--history-directory", action="append", default=[],
                        help="Additional required owned component proof directory")
    args = parser.parse_args()
    builder = owned(BASE / "archive_checkpoint.py")
    gates = {
        "frozen": WORK / (PREFIX + "-frozen.json"),
        "build": WORK / (PREFIX + "-build-receipt.json"),
        "background": WORK / (PREFIX + "-repeat1-background-receipt.json"),
        "accepted-background-log": WORK / (PREFIX + "-repeat1-background.log"),
        "accepted-background-exit": WORK / (PREFIX + "-repeat1-background.exit"),
        "publication": WORK / (PREFIX + "-publication.json"),
        "root-ready": WORK / (PREFIX + "-root-ready.json"),
        "native-ui": BASE / "native-workflow/receipt.json",
        "device": BASE / "device/receipt.json",
    }
    gates = {name: owned(path) for name, path in gates.items()}
    require(sha(gates["build"]) == "c6fa429d185c135b1c7a51236889a9aaacf563b76c901c75139b4b90304eab6d",
            "Different r5 build receipt")
    require(sha(gates["background"]) == "7037dd636eb1a8629c938f20de98c54ff852f1695679688af8e03155b31cef45",
            "Different accepted repeat1 background receipt")
    require(gates["accepted-background-exit"].read_text().strip() == "0", "Repeat1 background exit failed")
    cadences = [owned(BASE / "cadence-1080/attempt1/accepted-summary.json"), owned(args.cadence_4k)]
    for report in cadences:
        value = load(report)
        require(value.get("accepted") is True and value.get("passed") is True, "Cadence not accepted")
        for key, expected in PAYLOAD.items():
            require(value.get(key, "").lower() == expected, "Cadence payload mismatch: " + key)
    require(load(cadences[0])["raw_profile_sha256"].lower() ==
            "216460418ffb70760959e339adf77b2c848a58930a48e8feb1356b5c5a8aff22", "Different accepted 1080 trace")
    exported = owned(BASE / "native-title-export/attempt1/receipt.json")
    require(sha(exported) == "b07488ac3442dec8b1a1befeded5957f285d97dcea1235f0f349e49d90ae67a6",
            "Different independently inspected r5 export")
    owned(BASE / "native-title-export/attempt1/verify.py")

    histories = [owned(WORK / name, directory=True) for name in (*PRIOR, *COMPONENTS)]
    histories += [owned(path, directory=True) for path in args.history_directory]
    audio_root = owned(WORK / "agent-audio-context-source", directory=True)
    histories += [owned(audio_root / name, directory=True) for name in AUDIO_PROOFS]
    # Require the failed/capped histories, not merely an otherwise empty candidate directory.
    for relative in (
        "pro-native-edit-export-2026-10-11/background-failure",
        "pro-native-edit-export-r3-2026-10-11/background-failure",
        "pro-native-edit-export-r5-2026-10-11/background-failure",
        "pro-native-edit-export-r4-2026-10-11/cadence-1080/attempt1",
        "pro-native-edit-export-r4-2026-10-11/cadence-1080/attempt2",
    ):
        directory = owned(WORK / relative, directory=True)
        require(any(path.is_file() for path in directory.rglob("*")), "Empty required failure history: " + relative)

    evidence = {owned(__file__), exported}
    # Bind old frozen application/overlay bytes individually, without SDK/runtime trees.
    for prefix in PRIOR:
        frozen_path = owned(WORK / (prefix + "-frozen.json"))
        snapshot = owned(WORK / (prefix + "-source"), directory=True)
        for name, expected in load(frozen_path)["source_sha256"].items():
            path = owned(snapshot / name)
            require(sha(path) == expected.lower(), "Historical frozen source drift: " + str(path))
            evidence.add(path)
        evidence.update(owned(path) for path in WORK.glob(prefix + "-*")
                        if path.is_file() and path.suffix in TEXT)
    # Select top-level audio proof/driver text only: never recurse through its worker,
    # runtime, target or full SDK copies. Each selected proof subdirectory is above.
    evidence.update(owned(path) for path in audio_root.iterdir()
                    if path.is_file() and (path.suffix in TEXT or path.name == "CMakeLists.txt"))
    command = [str(builder), "--prefix", PREFIX]
    for name, path in gates.items():
        command += ["--" + name, str(path)]
    for path in cadences:
        command += ["--cadence", str(path)]
    for path in sorted(set(histories)):
        command += ["--history-directory", str(path)]
    for path in sorted(evidence):
        command += ["--evidence", str(path)]
    # In-process CLI invocation avoids Windows' command-line limit when retaining
    # all historical frozen source witnesses. Builder validation is unchanged.
    # Only this explicit invocation writes the archive, after all preconditions.
    previous_argv = sys.argv
    try:
        sys.argv = command
        runpy.run_path(str(builder), run_name="__main__")
    finally:
        sys.argv = previous_argv


if __name__ == "__main__":
    main()
