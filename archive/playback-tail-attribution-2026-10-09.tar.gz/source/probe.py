"""Isolated native preview phase probe; no desktop and no application audio clock."""
import argparse, json, os, re, statistics, subprocess, sys, time
from pathlib import Path
from queue import Queue
from threading import Thread
sys.path.insert(0,str(Path(__file__).resolve().parents[2]/'tests'))
from preview_fit import wire
from video_transfer import neutral
parser=argparse.ArgumentParser()
parser.add_argument('--worker',type=Path,required=True)
parser.add_argument('--source',type=Path,required=True)
parser.add_argument('--report',type=Path,required=True)
parser.add_argument('--canvas',type=int,nargs=2,default=[1280,720])
parser.add_argument('--pace',action='store_true')
args=parser.parse_args()
args.report.parent.mkdir(parents=True,exist_ok=True)
env=dict(os.environ,GENESIS_MEDIA_PROFILE='1')
for key in ['GENESIS_SOFTWARE_DECODE','GENESIS_VIDEO_BACKEND']:env.pop(key,None)
argv=[str(args.worker.resolve()),'--serve','--size',*map(str,args.canvas)]
p=subprocess.Popen(argv,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,encoding='utf8',errors='replace',env=env,creationflags=subprocess.CREATE_NO_WINDOW)
replies,diagnostics=Queue(),[]
def read():
    for line in p.stdout:replies.put(line.rstrip())
    replies.put('')
def errors():diagnostics.extend(p.stderr)
reader,logger=Thread(target=read),Thread(target=errors)
reader.start();logger.start()
fields=neutral();fields[0]=wire(args.source.resolve())
output=args.report.with_suffix('.rgba')
rows=[]
try:
    for target in [1367,1636,4389,5301]:
        start=time.perf_counter()
        for n,frame in enumerate(range(target-60,target+61)):
            if args.pace and n:time.sleep(max(0,(start+n/59.94005994)-time.perf_counter()))
            fields[2]=str(frame)
            command='PREVIEWFIT 480 270 '+' '.join(fields)+' '+wire(output.resolve())
            before=time.perf_counter_ns()
            p.stdin.write(command+'\n');p.stdin.flush()
            reply=replies.get(timeout=30)
            assert reply=='DONE '+str(output.resolve()),(frame,reply,diagnostics[-10:])
            rows.append({'region':target,'frame':frame,'wall_us':(time.perf_counter_ns()-before)//1000,'cold':n==0})
            if n==0:start=time.perf_counter()-1/59.94005994
finally:
    p.stdin.close();p.wait(timeout=30);reader.join(timeout=2);logger.join(timeout=2)
assert p.returncode==0,diagnostics[-10:]
args.report.with_suffix('.log').write_text(''.join(diagnostics),encoding='utf8')
phases=[];color={};last=None
for line in diagnostics:
    numbers={k:int(v) for k,v in re.findall(r'([a-z_]+)=(-?\d+)',line)}
    if 'gpu_color_us' in numbers:color=numbers
    if 'video_frame' in numbers:
        last={'frame':numbers.pop('video_frame'),**numbers,**color};phases.append(last);color={}
    if 'upload_us' in numbers and last is not None:last.update(numbers)
for row in rows:
    matches=[v for v in phases if v['frame']==row['frame']]
    if matches:row.update(matches[0])
steady=[v for v in rows if not v['cold']]
summary={key:{'median':statistics.median(v[key] for v in steady if key in v),'p95':sorted(v[key] for v in steady if key in v)[int(.95*(sum(key in v for v in steady)-1))],'maximum':max(v[key] for v in steady if key in v)} for key in ['wall_us','receive_us','read_us','send_us','blit_us','gpu_color_us','lock_us','submit_us','map_us','copy_us','upload_us','compose_us','download_us','write_us','finish_us'] if any(key in v for v in steady)}
report={'scope':f'native D3D decode/color +{args.canvas[0]}x{args.canvas[1]} OpenCL composition and480x270 fitted output; excludes AIR/event/painter/audio/native display','canvas':args.canvas,'paced':args.pace,'summary_us':summary,'largest':sorted(steady,key=lambda v:v['wall_us'],reverse=True)[:15],'rows':rows}
args.report.write_text(json.dumps(report,indent=2))
print(json.dumps({k:v for k,v in report.items() if k!='rows'},indent=2))
