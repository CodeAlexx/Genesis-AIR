"""Isolated odd-visible P010 edge reproduction, without changing GPU math."""
from array import array
import json
import os
from pathlib import Path
import subprocess
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[2] / 'tests'))
from hdr_preview import capture, FLAGS
from media_runtime import tool

repo = Path(__file__).resolve().parents[2]
worker = Path(sys.argv[1]).resolve() if len(sys.argv)>1 else repo / 'build-windows/agent-playback-tcp-native/genesis-gcompose.exe'
root = repo / ('build-windows/agent-playback-odd-source-fixed' if len(sys.argv)>1 else 'build-windows/agent-playback-odd-source')
root.mkdir(exist_ok=True)
ffmpeg = tool(worker, 'ffmpeg')
rows = []
for width, height in ((514,290),(513,289),(513,290),(514,289)):
    raw = root / f'{width}x{height}.yuv'
    cw,ch = (width+1)//2,(height+1)//2
    with raw.open('wb') as stream:
        for frame in range(2):
            stream.write((array('H',[512+frame*32])*(width*height)).tobytes())
            for plane in range(2):
                data = array('H')
                for y in range(ch):
                    for x in range(cw):
                        data.append(640 if (plane==0 and x==cw-1) or (plane==1 and y==ch-1) else 512)
                stream.write(data.tobytes())
    source = raw.with_suffix('.mp4')
    command = [str(ffmpeg),'-nostdin','-v','error','-y','-f','rawvideo','-pixel_format','yuv420p10le',
        '-video_size',f'{width}x{height}','-framerate','24','-i',str(raw),
        '-c:v','libaom-av1','-cpu-used','8','-crf','0','-b:v','0','-aom-params','lossless=1',
        '-color_primaries','bt2020','-color_trc','smpte2084','-colorspace','bt2020nc',
        '-color_range','tv','-chroma_sample_location','left',
        '-bsf:v','av1_metadata=color_primaries=9:transfer_characteristics=16:matrix_coefficients=9:color_range=0:chroma_sample_position=1',str(source)]
    result = subprocess.run(command,capture_output=True,timeout=120,creationflags=FLAGS)
    assert result.returncode == 0,result.stderr.decode(errors='replace')
    gpu,gpu_log = capture(worker,source,[0,1,0],root,True,512,288)
    (root/f'{width}x{height}.gpu.log').write_text(gpu_log,encoding='utf8')
    row = dict(width=width,height=height,hardware='Native GPU HDR preview:' in gpu_log,rewind=gpu[0]==gpu[2])
    try:
        cpu,cpu_log = capture(worker,source,[0,1,0],root,False,512,288)
        (root/f'{width}x{height}.cpu.log').write_text(cpu_log,encoding='utf8')
        deltas = [abs(a-b)*255 for p,q in zip(cpu,gpu) for a,b in zip(p,q)]
        row.update(maximum=max(deltas),mean=sum(deltas)/len(deltas))
    except AssertionError as error:
        row['reference_failure']=str(error)
    rows.append(row)
    print(row,flush=True)
    (root/'report.json').write_text(json.dumps(rows,indent=2)+'\n')
