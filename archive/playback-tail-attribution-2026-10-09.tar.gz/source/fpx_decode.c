// fpx_decode.c — thin libav C shim for faithful, frame-accurate video decode to RGBA8,
// callable from Mojo via external_call (mirrors how serenitymojo uses cshim libraries).
// Mirrors FramePFX's decode/scale path (FFmpegMedia: av_read_frame -> send/receive ->
// sws_scale SWS_BICUBIC), output AV_PIX_FMT_RGBA (MojoGUI draw_image wants RGBA8).
//
// Build .so:  cc -O2 -fPIC -shared fpx_decode.c $(pkg-config --cflags --libs \
//                 libavformat libavcodec libswscale libavutil) -o libfpxdecode.so
// Build test: cc -DFPX_TEST -O2 fpx_decode.c $(pkg-config --cflags --libs \
//                 libavformat libavcodec libswscale libavutil) -o fpxtest
#include <libavformat/avformat.h>
#include <libavcodec/avcodec.h>
#include <libswscale/swscale.h>
#include <libavutil/imgutils.h>
#include <libavutil/pixdesc.h>
#include <libavutil/hwcontext.h>
#include <libavutil/time.h>
#include <libavutil/cpu.h>
#if defined(_M_X64) || defined(__SSE2__)
#include <emmintrin.h>
#endif
#include <libavfilter/avfilter.h>
#include <libavfilter/buffersrc.h>
#include <libavfilter/buffersink.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <limits.h>
#ifdef _WIN32
#define COBJMACROS
#include <libavutil/hwcontext_d3d11va.h>
int genesis_preview_frame(void**, const AVFrame*, float*, int, int, int, int);
void genesis_preview_close(void**);
#endif

static int working_hdr = 0;
static int preview_enabled = 1;
void fpx_set_hdr(int hdr) { working_hdr = hdr != 0; }
void fpx_set_preview(int enabled) { preview_enabled = enabled != 0; }
int fpx_working_hdr(void) { return working_hdr; }

typedef struct {
    AVFormatContext* fmt;
    AVCodecContext*  dec;
    struct SwsContext* sws;
    struct SwsContext* sws2;     // scaled-output context (lazy, for fpx_decode_frame_scaled)
    int sw, sh;                  // current scaled target size
    struct SwsContext* sws_lb;   // letterbox context (aspect-preserving, lazy)
    AVFilterGraph* color_graph;
    AVFilterContext *color_src, *color_sink;
    AVFrame* color_frame;
    int color_width, color_height;
    struct SwsContext* sws_hi;
    int hi_dw, hi_dh;
    uint16_t* hi_rgba;
    size_t hi_capacity;
    int lb_dw, lb_dh;            // current letterbox inner (fit) size
    int vindex;
    int cpu_format;
    enum AVPixelFormat hw_format;
    AVFrame* hw_transfer;
#ifdef _WIN32
    ID3D11Texture2D* staging;
    AVBufferRef* staging_frames;
    AVBufferPool* transfer_pool;
    int transfer_width, transfer_height;
    int transfer_failed;
    void* gpu_preview;
    int gpu_preview_failed;
#endif
    int width, height;
    AVRational time_base;
    AVRational frame_rate;
    AVPacket* pkt;
    AVFrame*  frame;
    // Sequential-decode position tracking (fpx_decode_frame_letterbox): pts of the last frame
    // returned, and whether that position is known. Lets a forward in-window request decode forward
    // from here instead of seeking to a keyframe + redecoding (the per-frame playback/render cost).
    // calloc-zeroed at open => have_pos=0 (unknown) until the first decode. ANY seek (here or in the
    // sibling _scaled/_rgba decoders, which share the handle) clears have_pos so we never decode
    // forward from a stale position.
    int64_t cur_pts;
    int have_pos;
} FpxCtx;

#ifdef _WIN32
static void fpx_transfer_clear(FpxCtx* c) {
    if (c->staging) ID3D11Texture2D_Release(c->staging);
    c->staging = NULL;
    av_buffer_unref(&c->staging_frames);
    av_buffer_pool_uninit(&c->transfer_pool);
}

// D3D11 staging memory can be uncached/write-combined. The public libavutil
// copy primitive dispatches suitable CPU reads while preserving every byte.
// Cache the staging resource and reuse aligned AVFrame backing buffers.
static int fpx_d3d11_prepare(FpxCtx* c) {
    AVFrame* input = c->frame;
    if (input->format != AV_PIX_FMT_D3D11 || !input->hw_frames_ctx) return AVERROR(ENOSYS);
    AVHWFramesContext* frames = (AVHWFramesContext*)input->hw_frames_ctx->data;
    AVD3D11VADeviceContext* device = (AVD3D11VADeviceContext*)frames->device_ctx->hwctx;
    ID3D11Texture2D* texture = (ID3D11Texture2D*)input->data[0];
    D3D11_TEXTURE2D_DESC desc;
    if (!texture || !device || !device->device_context) return AVERROR(EINVAL);
    ID3D11Texture2D_GetDesc(texture, &desc);
    // Only the tested semiplanar decode layouts use this path. FFmpeg owns
    // other formats, including opaque decoder surfaces.
    if ((frames->sw_format != AV_PIX_FMT_NV12 && frames->sw_format != AV_PIX_FMT_P010LE) ||
        desc.Width > INT_MAX || desc.Height > INT_MAX || input->width > (int)desc.Width ||
        input->height > (int)desc.Height) return AVERROR(ENOSYS);
    if (c->staging_frames && (c->staging_frames->data != input->hw_frames_ctx->data ||
        c->transfer_width != input->width || c->transfer_height != input->height)) fpx_transfer_clear(c);
    if (!c->staging) {
        int size = av_image_get_buffer_size(frames->sw_format, input->width, input->height, 64);
        if (size < 1 || size > INT_MAX - 64) return AVERROR(EINVAL);
        D3D11_TEXTURE2D_DESC staging = desc;
        staging.ArraySize = 1; staging.MipLevels = 1;
        staging.Usage = D3D11_USAGE_STAGING; staging.BindFlags = 0;
        staging.CPUAccessFlags = D3D11_CPU_ACCESS_READ; staging.MiscFlags = 0;
        if (FAILED(ID3D11Device_CreateTexture2D(device->device, &staging, NULL, &c->staging))) return AVERROR(EIO);
        c->staging_frames = av_buffer_ref(input->hw_frames_ctx);
        c->transfer_pool = av_buffer_pool_init(size + 64, NULL);
        if (!c->staging_frames || !c->transfer_pool) { fpx_transfer_clear(c); return AVERROR(ENOMEM); }
        c->transfer_width = input->width; c->transfer_height = input->height;
    }
    if (device->lock) device->lock(device->lock_ctx);
    ID3D11DeviceContext_CopySubresourceRegion(device->device_context, (ID3D11Resource*)c->staging,
        0, 0, 0, 0, (ID3D11Resource*)texture, (UINT)(uintptr_t)input->data[1], NULL);
    if (device->unlock) device->unlock(device->lock_ctx);
    return 0;
}

static int fpx_d3d11_transfer(FpxCtx* c) {
    int prepared = fpx_d3d11_prepare(c);
    if (prepared < 0) return prepared;
    AVFrame* input = c->frame;
    AVHWFramesContext* frames = (AVHWFramesContext*)input->hw_frames_ctx->data;
    AVD3D11VADeviceContext* device = (AVD3D11VADeviceContext*)frames->device_ctx->hwctx;
    D3D11_TEXTURE2D_DESC desc;
    ID3D11Texture2D_GetDesc(c->staging, &desc);
    AVFrame* output = c->hw_transfer;
    av_frame_unref(output);
    output->format = frames->sw_format; output->width = input->width; output->height = input->height;
    output->buf[0] = av_buffer_pool_get(c->transfer_pool);
    if (!output->buf[0]) return AVERROR(ENOMEM);
    uint8_t* aligned = (uint8_t*)(((uintptr_t)output->buf[0]->data + 63) & ~(uintptr_t)63);
    if (av_image_fill_arrays(output->data, output->linesize, aligned, frames->sw_format,
        input->width, input->height, 64) < 0) return AVERROR(EINVAL);
    D3D11_MAPPED_SUBRESOURCE map;
    int result = 0;
    int64_t started = av_gettime_relative();
    if (device->lock) device->lock(device->lock_ctx);
    HRESULT mapped = ID3D11DeviceContext_Map(device->device_context, (ID3D11Resource*)c->staging,
        0, D3D11_MAP_READ, 0, &map);
    int64_t ready = av_gettime_relative();
    if (FAILED(mapped)) result = AVERROR(EIO);
    else {
        uint8_t* source[4] = {0};
        int pitch[4] = {(int)map.RowPitch, (int)map.RowPitch, (int)map.RowPitch, (int)map.RowPitch};
        // The chroma plane starts after the texture's padded height, rather
        // than the visible picture height (e.g. 1088 versus 1080).
        int minimum_pitch[4];
        result = av_image_fill_linesizes(minimum_pitch, frames->sw_format, input->width);
        if (result >= 0 && (map.RowPitch > INT_MAX || (int)map.RowPitch < minimum_pitch[0] ||
            (int)map.RowPitch < minimum_pitch[1])) result = AVERROR(EINVAL);
        if (result >= 0) result = av_image_fill_pointers(source, frames->sw_format, desc.Height, map.pData, pitch);
        if (result >= 0) {
            ptrdiff_t dst_pitch[4], src_pitch[4];
            for (int i=0; i<4; ++i) {dst_pitch[i]=output->linesize[i]; src_pitch[i]=pitch[i];}
            av_image_copy_uc_from(output->data, dst_pitch, (const uint8_t* const*)source, src_pitch,
                frames->sw_format, input->width, input->height);
            result = 0;
        }
        ID3D11DeviceContext_Unmap(device->device_context, (ID3D11Resource*)c->staging, 0);
    }
    if (device->unlock) device->unlock(device->lock_ctx);
    if (getenv("GENESIS_MEDIA_PROFILE")) fprintf(stderr, "[gcompose] staging wait_us=%lld copy_us=%lld\n",
        (long long)(ready-started), (long long)(av_gettime_relative()-ready));
    if (result < 0) return result;
    return av_frame_copy_props(output, input);
}
#endif

static enum AVPixelFormat fpx_hw_format(AVCodecContext* dec, const enum AVPixelFormat* formats) {
    FpxCtx* c = (FpxCtx*)dec->opaque;
    for (const enum AVPixelFormat* p = formats; *p != AV_PIX_FMT_NONE; ++p)
        if (c && *p == c->hw_format) return *p;
    for (const enum AVPixelFormat* p = formats; *p != AV_PIX_FMT_NONE; ++p) {
        const AVPixFmtDescriptor* desc = av_pix_fmt_desc_get(*p);
        if (desc && !(desc->flags & AV_PIX_FMT_FLAG_HWACCEL)) return *p;
    }
    return AV_PIX_FMT_NONE;
}

// Inspect native timestamps before transferring pixels. The letterbox/float
// path drops pictures before the requested time while they are still on the GPU.
// Preserve stream color metadata for the selected picture's float color path.
static int fpx_pull(FpxCtx* c, AVFrame* frame) {
    int result = avcodec_receive_frame(c->dec, frame);
    if (result < 0) return result;
    const AVCodecParameters* metadata = c->fmt->streams[c->vindex]->codecpar;
    if (frame->color_primaries == AVCOL_PRI_UNSPECIFIED) frame->color_primaries = metadata->color_primaries;
    if (frame->color_trc == AVCOL_TRC_UNSPECIFIED) frame->color_trc = metadata->color_trc;
    if (frame->colorspace == AVCOL_SPC_UNSPECIFIED) frame->colorspace = metadata->color_space;
    if (frame->color_range == AVCOL_RANGE_UNSPECIFIED) frame->color_range = metadata->color_range;
    return 0;
}
static int fpx_cpu_frame(FpxCtx* c) {
    int64_t started = av_gettime_relative();
    int result = 0;
    const AVPixFmtDescriptor* format = av_pix_fmt_desc_get(c->frame->format);
    if (format && (format->flags & AV_PIX_FMT_FLAG_HWACCEL)) {
        if (!c->hw_transfer) c->hw_transfer = av_frame_alloc();
        if (!c->hw_transfer) return AVERROR(ENOMEM);
        int fast = 0;
#ifdef _WIN32
        if (c->frame->format == AV_PIX_FMT_D3D11 && !c->transfer_failed && !getenv("GENESIS_DEFAULT_TRANSFER")) {
            result = fpx_d3d11_transfer(c);
            if (result >= 0) fast = 1;
            else { c->transfer_failed = 1; fpx_transfer_clear(c);
                fprintf(stderr, "[GA_VIDEO_TRANSFER] Fast D3D11 read failed (%d), using the default transfer\n", result); }
        }
#endif
        if (!fast) {
            av_frame_unref(c->hw_transfer);
            result = av_hwframe_transfer_data(c->hw_transfer, c->frame, 0);
            if (result >= 0) result = av_frame_copy_props(c->hw_transfer, c->frame);
        }
        if (result < 0) return result;
        av_frame_unref(c->frame);
        av_frame_move_ref(c->frame, c->hw_transfer);
    }
    if (getenv("GENESIS_MEDIA_PROFILE")) fprintf(stderr, "[gcompose] decode transfer_us=%lld\n",
        (long long)(av_gettime_relative()-started));
    if (c->cpu_format != c->frame->format) {
        c->cpu_format = c->frame->format;
        if (c->sws) sws_freeContext(c->sws);
        c->sws = sws_getContext(c->width, c->height, c->cpu_format,
            c->width, c->height, AV_PIX_FMT_RGBA, SWS_BICUBIC, NULL, NULL, NULL);
        if (c->sws2) sws_freeContext(c->sws2);
        c->sws2 = c->sw > 0 && c->sh > 0 ? sws_getContext(c->width, c->height,
            c->cpu_format, c->sw, c->sh, AV_PIX_FMT_RGBA, SWS_BICUBIC, NULL, NULL, NULL) : NULL;
        if (c->sws_lb) sws_freeContext(c->sws_lb);
        c->sws_lb = NULL;
    }
    return 0;
}

static int fpx_receive(FpxCtx* c) {
    int result = fpx_pull(c, c->frame);
    return result < 0 ? result : fpx_cpu_frame(c);
}

void* fpx_open(const char* path) {
    FpxCtx* c = (FpxCtx*)calloc(1, sizeof(FpxCtx));
    if (!c) return NULL;
    if (avformat_open_input(&c->fmt, path, NULL, NULL) < 0) { free(c); return NULL; }
    if (avformat_find_stream_info(c->fmt, NULL) < 0) { avformat_close_input(&c->fmt); free(c); return NULL; }
    const AVCodec* codec = NULL;
    int idx = av_find_best_stream(c->fmt, AVMEDIA_TYPE_VIDEO, -1, -1, &codec, 0);
    if (idx < 0 || !codec) { avformat_close_input(&c->fmt); free(c); return NULL; }
    c->vindex = idx;
    AVStream* st = c->fmt->streams[idx];
    c->dec = avcodec_alloc_context3(codec);
    if (!c->dec) { avformat_close_input(&c->fmt); free(c); return NULL; }
    avcodec_parameters_to_context(c->dec, st->codecpar);
#ifdef _WIN32
    // FFmpeg's native AV1 decoder exposes D3D11; libdav1d is the software fallback.
    const AVCodec* hardware = codec->id == AV_CODEC_ID_AV1 ? avcodec_find_decoder_by_name("av1") : codec;
    const char* requested_backend = getenv("GENESIS_VIDEO_BACKEND");
    if (requested_backend && strcmp(requested_backend, "auto") && strcmp(requested_backend, "d3d11") &&
        strcmp(requested_backend, "vulkan") && strcmp(requested_backend, "software")) {
        fprintf(stderr, "[GA_VIDEO_BACKEND] Unknown backend; use auto, d3d11, vulkan or software\n");
        avcodec_free_context(&c->dec); avformat_close_input(&c->fmt); free(c); return NULL;
    }
    if (!getenv("GENESIS_SOFTWARE_DECODE") && (!requested_backend || strcmp(requested_backend, "software")) && hardware) {
        for (int i = 0; ; ++i) {
            const AVCodecHWConfig* config = avcodec_get_hw_config(hardware, i);
            if (!config) break;
            enum AVHWDeviceType backend = requested_backend && !strcmp(requested_backend, "vulkan") ? AV_HWDEVICE_TYPE_VULKAN : AV_HWDEVICE_TYPE_D3D11VA;
            if (config->device_type != backend ||
                !(config->methods & AV_CODEC_HW_CONFIG_METHOD_HW_DEVICE_CTX)) continue;
            AVBufferRef* device = NULL;
            int device_result = av_hwdevice_ctx_create(&device, backend, NULL, NULL, 0);
            if (device_result >= 0) {
                avcodec_free_context(&c->dec);
                c->dec = avcodec_alloc_context3(hardware);
                if (!c->dec) { av_buffer_unref(&device); avformat_close_input(&c->fmt); free(c); return NULL; }
                avcodec_parameters_to_context(c->dec, st->codecpar);
                c->hw_format = backend == AV_HWDEVICE_TYPE_VULKAN ? AV_PIX_FMT_VULKAN : AV_PIX_FMT_D3D11;
                c->dec->opaque = c;
                c->dec->hw_device_ctx = device;
                c->dec->get_format = fpx_hw_format;
                if (avcodec_open2(c->dec, hardware, NULL) >= 0) {
                    fprintf(stderr, "[gcompose] Native %s decode: %s\n", backend == AV_HWDEVICE_TYPE_VULKAN ? "Vulkan" : "D3D11", hardware->name);
                    goto decoder_open;
                }
                avcodec_free_context(&c->dec);
                c->dec = avcodec_alloc_context3(codec);
                if (!c->dec) { avformat_close_input(&c->fmt); free(c); return NULL; }
                avcodec_parameters_to_context(c->dec, st->codecpar);
            }
            break;
        }
    }
#endif
    if (avcodec_open2(c->dec, codec, NULL) < 0) { avcodec_free_context(&c->dec); avformat_close_input(&c->fmt); free(c); return NULL; }
decoder_open:
    c->cpu_format = AV_PIX_FMT_NONE;
    c->width = c->dec->width;
    c->height = c->dec->height;
    c->time_base = st->time_base;
    c->frame_rate = av_guess_frame_rate(c->fmt, st, NULL);
    // SWS_BICUBIC like FramePFX; at native size this is pure pixel-format conversion (YUV->RGBA).
    c->sws = NULL;
    c->pkt = av_packet_alloc();
    c->frame = av_frame_alloc();
    return c;
}

int fpx_width(void* h)  { return h ? ((FpxCtx*)h)->width  : 0; }
int fpx_height(void* h) { return h ? ((FpxCtx*)h)->height : 0; }

// Frame-accurate seek + decode of frame `frame_index` -> RGBA8 into out (width*height*4 bytes).
// Returns 0 on success, negative on error.
int fpx_decode_frame_rgba(void* h, int frame_index, unsigned char* out, int out_size) {
    if (!h || !out) return -1;
    FpxCtx* c = (FpxCtx*)h;
    if (out_size < c->width * c->height * 4) return -2;

    // target PTS in stream time_base = frame_index * (1/frame_rate) / time_base
    int64_t target = av_rescale_q(frame_index, av_inv_q(c->frame_rate), c->time_base);
    // seek to keyframe at or before target, then decode forward (scrubbing path)
    if (av_seek_frame(c->fmt, c->vindex, target, AVSEEK_FLAG_BACKWARD) < 0) return -3;
    avcodec_flush_buffers(c->dec);
    c->have_pos = 0; // sibling seek invalidates the _letterbox forward-decode position

    int got = -1;
    while (got != 0 && av_read_frame(c->fmt, c->pkt) >= 0) {
        if (c->pkt->stream_index == c->vindex) {
            if (avcodec_send_packet(c->dec, c->pkt) == 0) {
                while (fpx_receive(c) == 0) {
                    int64_t pts = c->frame->best_effort_timestamp;
                    if (pts == AV_NOPTS_VALUE || pts >= target) {
                        uint8_t* dst[4] = { out, NULL, NULL, NULL };
                        int dstln[4] = { c->width * 4, 0, 0, 0 };
                        sws_scale(c->sws, (const uint8_t* const*)c->frame->data, c->frame->linesize,
                                  0, c->height, dst, dstln);
                        got = 0;
                        break;
                    }
                }
            }
        }
        av_packet_unref(c->pkt);
        if (got == 0) break;
    }
    // EOF with the target still buffered: codecs with reorder delay (H.264 B-frames) hold the final
    // frames of a stream until a flush, so the loop above (which stops at av_read_frame EOF) never
    // drains them and the clip's last ~GOP decodes BLACK. Send a NULL packet to flush, then drain the
    // remaining frames and take the first at/after target. Mirrors ffmpeg's end-of-stream drain.
    if (got != 0) {
        avcodec_send_packet(c->dec, NULL);
        while (fpx_receive(c) == 0) {
            int64_t pts = c->frame->best_effort_timestamp;
            if (pts == AV_NOPTS_VALUE || pts >= target) {
                uint8_t* dst[4] = { out, NULL, NULL, NULL };
                int dstln[4] = { c->width * 4, 0, 0, 0 };
                sws_scale(c->sws, (const uint8_t* const*)c->frame->data, c->frame->linesize,
                          0, c->height, dst, dstln);
                got = 0;
                break;
            }
        }
    }
    return got;
}

// Like fpx_decode_frame_rgba but SCALES the frame to ow x oh RGBA8 (editor preview /
// fixed processing resolution; lets clips of any native size load into one buffer).
int fpx_decode_frame_scaled(void* h, int frame_index, unsigned char* out, int ow, int oh) {
    if (!h || !out || ow <= 0 || oh <= 0) return -1;
    FpxCtx* c = (FpxCtx*)h;
    if (!c->sws2 || c->sw != ow || c->sh != oh) {
        if (c->sws2) sws_freeContext(c->sws2);
        c->sws2 = sws_getContext(c->width, c->height, c->cpu_format,
                                 ow, oh, AV_PIX_FMT_RGBA, SWS_BICUBIC, NULL, NULL, NULL);
        c->sw = ow; c->sh = oh;
    }
    if (!c->sws2) return -4;
    int64_t target = av_rescale_q(frame_index, av_inv_q(c->frame_rate), c->time_base);
    if (av_seek_frame(c->fmt, c->vindex, target, AVSEEK_FLAG_BACKWARD) < 0) return -3;
    avcodec_flush_buffers(c->dec);
    c->have_pos = 0; // sibling seek invalidates the _letterbox forward-decode position
    int got = -1;
    while (got != 0 && av_read_frame(c->fmt, c->pkt) >= 0) {
        if (c->pkt->stream_index == c->vindex) {
            if (avcodec_send_packet(c->dec, c->pkt) == 0) {
                while (fpx_receive(c) == 0) {
                    int64_t pts = c->frame->best_effort_timestamp;
                    if (pts == AV_NOPTS_VALUE || pts >= target) {
                        uint8_t* dst[4] = { out, NULL, NULL, NULL };
                        int dstln[4] = { ow * 4, 0, 0, 0 };
                        sws_scale(c->sws2, (const uint8_t* const*)c->frame->data, c->frame->linesize,
                                  0, c->height, dst, dstln);
                        got = 0; break;
                    }
                }
            }
        }
        av_packet_unref(c->pkt);
        if (got == 0) break;
    }
    // EOF flush-drain (see fpx_decode_frame_rgba): drain the decoder's buffered tail frames so the
    // last ~GOP of a clip decodes instead of returning black.
    if (got != 0) {
        avcodec_send_packet(c->dec, NULL);
        while (fpx_receive(c) == 0) {
            int64_t pts = c->frame->best_effort_timestamp;
            if (pts == AV_NOPTS_VALUE || pts >= target) {
                uint8_t* dst[4] = { out, NULL, NULL, NULL };
                int dstln[4] = { ow * 4, 0, 0, 0 };
                sws_scale(c->sws2, (const uint8_t* const*)c->frame->data, c->frame->linesize,
                          0, c->height, dst, dstln);
                got = 0; break;
            }
        }
    }
    return got;
}

// Decode the NEXT frame in sequence (no seek) scaled to ow x oh RGBA8 — for playback.
// Returns 0 on success, negative at end-of-stream (caller should seek back to 0).
int fpx_decode_next_scaled(void* h, unsigned char* out, int ow, int oh) {
    if (!h || !out || ow <= 0 || oh <= 0) return -1;
    FpxCtx* c = (FpxCtx*)h;
    if (!c->sws2 || c->sw != ow || c->sh != oh) {
        if (c->sws2) sws_freeContext(c->sws2);
        c->sws2 = sws_getContext(c->width, c->height, c->cpu_format,
                                 ow, oh, AV_PIX_FMT_RGBA, SWS_BICUBIC, NULL, NULL, NULL);
        c->sw = ow; c->sh = oh;
    }
    if (!c->sws2) return -4;
    int got = -1;
    while (got != 0 && av_read_frame(c->fmt, c->pkt) >= 0) {
        if (c->pkt->stream_index == c->vindex) {
            if (avcodec_send_packet(c->dec, c->pkt) == 0) {
                while (fpx_receive(c) == 0) {
                    uint8_t* dst[4] = { out, NULL, NULL, NULL };
                    int dstln[4] = { ow * 4, 0, 0, 0 };
                    sws_scale(c->sws2, (const uint8_t* const*)c->frame->data, c->frame->linesize,
                              0, c->height, dst, dstln);
                    got = 0; break;
                }
            }
        }
        av_packet_unref(c->pkt);
        if (got == 0) break;
    }
    return got;
}

// Scale the current decoded c->frame into `out` (ow*oh RGBA8) PRESERVING ASPECT: the source
// is fit (by width or height) into ow x oh and centered, with opaque-black bars filling the
// rest. This is how a portrait/mobile clip lands in the fixed editor buffer without stretching.
static int fpx_lb_blit(FpxCtx* c, unsigned char* out, int ow, int oh) {
    int dw, dh;
    if ((long)c->width * oh >= (long)ow * c->height) {        // source wider than target -> fit width
        dw = ow; dh = (int)((long)ow * c->height / c->width);
    } else {                                                  // taller -> fit height
        dh = oh; dw = (int)((long)oh * c->width / c->height);
    }
    if (dw < 2) dw = 2;
    if (dh < 2) dh = 2;
    dw &= ~1; dh &= ~1;
    int ox = (ow - dw) / 2, oy = (oh - dh) / 2;
    if (!c->sws_lb || c->lb_dw != dw || c->lb_dh != dh) {
        if (c->sws_lb) sws_freeContext(c->sws_lb);
        c->sws_lb = sws_getContext(c->width, c->height, c->cpu_format,
                                   dw, dh, AV_PIX_FMT_RGBA, SWS_BICUBIC, NULL, NULL, NULL);
        c->lb_dw = dw; c->lb_dh = dh;
    }
    if (!c->sws_lb) return -4;
    for (long i = 0; i < (long)ow * oh; i++) {                // opaque-black background
        out[i*4] = 0; out[i*4+1] = 0; out[i*4+2] = 0; out[i*4+3] = 255;
    }
    uint8_t* dst[4] = { out + ((long)oy * ow + ox) * 4, NULL, NULL, NULL };
    int dstln[4] = { ow * 4, 0, 0, 0 };
    sws_scale(c->sws_lb, (const uint8_t* const*)c->frame->data, c->frame->linesize,
              0, c->height, dst, dstln);
    return 0;
}

// Normalize HDR and SDR sources into the chosen output-referred working space.
// The display worker uses Rec.709 SDR; explicit HDR export workers use BT.2020 PQ.
// zscale and tonemap run through linear FP32 before the final 16-bit RGB conversion.
static AVFrame* fpx_color_frame(FpxCtx* c, int dw, int dh) {
    AVFrame* frame = c->frame;
    int transfer = frame->color_trc;
    if (transfer == AVCOL_TRC_UNSPECIFIED) transfer = c->dec->color_trc;
    int hdr = transfer == AVCOL_TRC_SMPTE2084 || transfer == AVCOL_TRC_ARIB_STD_B67;
    if ((!working_hdr && !hdr) || (working_hdr && transfer == AVCOL_TRC_SMPTE2084 &&
        frame->color_primaries == AVCOL_PRI_BT2020)) return frame;
    if (c->color_graph && (c->color_width != dw || c->color_height != dh)) {
        av_frame_free(&c->color_frame); avfilter_graph_free(&c->color_graph);
    }
    if (!c->color_graph) {
        AVFilterGraph* graph = avfilter_graph_alloc();
        if (!graph) return NULL;
        // HDR downsampling transforms the native source through linear light.
        // Bound the graph's parallel work without underusing larger CPUs or
        // creating more color workers than the machine can run.
        int cpus = av_cpu_count();
        graph->nb_threads = cpus < 1 ? 1 : cpus > 8 ? 8 : cpus;
        if (getenv("GENESIS_MEDIA_PROFILE")) fprintf(stderr,
            "[gcompose] color graph_threads=%d logical_cpus=%d\n", graph->nb_threads, cpus);
        char args[256];
        snprintf(args, sizeof(args), "video_size=%dx%d:pix_fmt=%d:time_base=%d/%d:pixel_aspect=1/1:colorspace=%d:range=%d",
            frame->width, frame->height, frame->format, c->time_base.num, c->time_base.den, frame->colorspace, frame->color_range);
        AVFilterContext *source = NULL, *sink = NULL;
        if (avfilter_graph_create_filter(&source, avfilter_get_by_name("buffer"), "in", args, NULL, graph) < 0 ||
            avfilter_graph_create_filter(&sink, avfilter_get_by_name("buffersink"), "out", NULL, NULL, graph) < 0) {
            avfilter_graph_free(&graph); return NULL;
        }
        const char* chain;
        char sdr_chain[512];
        if (!working_hdr) {
            // Preview resolves HDR at the requested picture size. Native-size exports
            // still process native dimensions, while a monitor avoids 4K FP32 intermediates.
            snprintf(sdr_chain, sizeof(sdr_chain), "zscale=w=%d:h=%d:transfer=linear:npl=100,format=gbrpf32le,zscale=primaries=bt709,tonemap=tonemap=hable:desat=2,zscale=transfer=bt709:matrix=gbr:range=full,format=gbrp16le", dw, dh);
            chain = sdr_chain;
        }
        else if (hdr) chain = "zscale=transfer=linear:npl=100,format=gbrpf32le,zscale=primaries=bt2020:transfer=smpte2084:matrix=gbr:range=full,format=gbrp16le";
        else {
            snprintf(sdr_chain, sizeof(sdr_chain), "format=gbrp16le,zscale=pin=bt709:tin=bt709:min=gbr:rin=full:p=bt709:t=linear:m=gbr:r=full:npl=100,format=gbrpf32le,zscale=pin=bt709:tin=linear:min=gbr:rin=full:p=bt2020:t=smpte2084:m=gbr:r=full:npl=100,format=gbrp16le");
            chain = sdr_chain;
        }
        AVFilterInOut *outputs = avfilter_inout_alloc(), *inputs = avfilter_inout_alloc();
        if (!outputs || !inputs) { avfilter_inout_free(&outputs); avfilter_inout_free(&inputs); avfilter_graph_free(&graph); return NULL; }
        outputs->name = av_strdup("in"); outputs->filter_ctx = source; outputs->pad_idx = 0;
        inputs->name = av_strdup("out"); inputs->filter_ctx = sink; inputs->pad_idx = 0;
        int result = avfilter_graph_parse_ptr(graph, chain, &inputs, &outputs, NULL);
        avfilter_inout_free(&inputs); avfilter_inout_free(&outputs);
        if (result < 0 || avfilter_graph_config(graph, NULL) < 0) { avfilter_graph_free(&graph); return NULL; }
        c->color_graph = graph; c->color_src = source; c->color_sink = sink;
        c->color_width = dw; c->color_height = dh;
        c->color_frame = av_frame_alloc();
        if (!c->color_frame) return NULL;
    }
    av_frame_unref(c->color_frame);
    if (av_buffersrc_add_frame_flags(c->color_src, frame, AV_BUFFERSRC_FLAG_KEEP_REF) < 0 ||
        av_buffersink_get_frame(c->color_sink, c->color_frame) < 0) return NULL;
    return c->color_frame;
}

// The media path retains 16-bit source precision, then uploads normalized FP32 to OpenCL.
static int fpx_hi_blit(FpxCtx* c, float* out, int ow, int oh) {
    int64_t started = av_gettime_relative();
    int dw, dh;
    if ((int64_t)c->width * oh >= (int64_t)ow * c->height) {
        dw = ow; dh = (int)((int64_t)ow * c->height / c->width);
    } else { dh = oh; dw = (int)((int64_t)oh * c->width / c->height); }
    if (dw < 2) dw = 2; if (dh < 2) dh = 2;
    dw &= ~1; dh &= ~1;
    int ox = (ow - dw) / 2, oy = (oh - dh) / 2;
#ifdef _WIN32
    const char* gpu_preview = getenv("GENESIS_GPU_PREVIEW");
    if (preview_enabled && (!gpu_preview || strcmp(gpu_preview,"0")) && !c->gpu_preview_failed && !working_hdr &&
        c->frame->format == AV_PIX_FMT_D3D11 && c->frame->hw_frames_ctx &&
        c->frame->color_trc == AVCOL_TRC_SMPTE2084 && c->frame->color_primaries == AVCOL_PRI_BT2020 &&
        c->frame->colorspace == AVCOL_SPC_BT2020_NCL && c->frame->color_range == AVCOL_RANGE_MPEG &&
        c->frame->chroma_location <= AVCHROMA_LOC_LEFT &&
        ((AVHWFramesContext*)c->frame->hw_frames_ctx->data)->sw_format == AV_PIX_FMT_P010LE &&
        dw >= 2 && dh >= 2 && dw <= ow && dh <= oh && dw < c->width && dh < c->height &&
        c->width <= dw*32 && c->height <= dh*32) {
        if (genesis_preview_frame(&c->gpu_preview, c->frame, out, ow, oh, dw, dh) == 0) return 0;
        fprintf(stderr,"[GA_GPU_COLOR] Native HDR preview unavailable; using the reference color graph\n");
        c->gpu_preview_failed = 1;
        genesis_preview_close(&c->gpu_preview);
    }
#endif
    const AVPixFmtDescriptor* input_format = av_pix_fmt_desc_get(c->frame->format);
    if (input_format && (input_format->flags & AV_PIX_FMT_FLAG_HWACCEL) && fpx_cpu_frame(c) < 0) return -4;
    AVFrame* frame = fpx_color_frame(c, dw, dh);
    if (!frame) { fprintf(stderr, "[GA_COLOR_CONVERSION] HDR/SDR transform failed fmt=%d transfer=%d primaries=%d matrix=%d range=%d\n", c->frame->format, c->frame->color_trc, c->frame->color_primaries, c->frame->colorspace, c->frame->color_range); return -6; }
    int64_t converted = av_gettime_relative();
    if (!c->sws_hi || c->hi_dw != dw || c->hi_dh != dh) {
        if (c->sws_hi) sws_freeContext(c->sws_hi);
        c->sws_hi = sws_getContext(frame->width, frame->height, frame->format,
            dw, dh, AV_PIX_FMT_RGBA64LE, SWS_BICUBIC | SWS_ACCURATE_RND, NULL, NULL, NULL);
        c->hi_dw = dw; c->hi_dh = dh;
    }
    if (!c->sws_hi) return -4;
    int matrix = frame->colorspace;
    if (matrix == AVCOL_SPC_UNSPECIFIED) matrix = c->dec->colorspace;
    if (matrix == AVCOL_SPC_UNSPECIFIED || matrix == AVCOL_SPC_RGB) matrix = SWS_CS_DEFAULT;
    const int* coefficients = sws_getCoefficients(matrix);
    sws_setColorspaceDetails(c->sws_hi, coefficients,
        frame->color_range == AVCOL_RANGE_JPEG, coefficients, 1, 0, 1 << 16, 1 << 16);
    size_t required = (size_t)dw * dh * 8;
    if (c->hi_capacity < required) {
        void* resized = av_realloc(c->hi_rgba, required);
        if (!resized) return -5;
        c->hi_rgba = (uint16_t*)resized;
        c->hi_capacity = required;
    }
    uint16_t* rgba = c->hi_rgba;
    uint8_t* dst[4] = {(uint8_t*)rgba, NULL, NULL, NULL};
    int lines[4] = {dw * 8, 0, 0, 0};
    int rows = sws_scale(c->sws_hi, (const uint8_t* const*)frame->data,
        frame->linesize, 0, frame->height, dst, lines);
    if (rows != dh) return -4;
    if (dw == ow && dh == oh) {
        // A fitted full-canvas picture needs no black clear. SSE2 is part of the
        // x64 baseline; convert eight 16-bit channels per iteration without
        // changing the retained precision or requiring a newer CPU instruction set.
        size_t count = (size_t)ow * oh * 4, i = 0;
#if defined(_M_X64) || defined(__SSE2__)
        const __m128 factor = _mm_set1_ps(1.0f / 65535.0f);
        const __m128i zero = _mm_setzero_si128();
        for (; i + 8 <= count; i += 8) {
            __m128i values = _mm_loadu_si128((const __m128i*)(rgba + i));
            _mm_storeu_ps(out + i, _mm_mul_ps(_mm_cvtepi32_ps(_mm_unpacklo_epi16(values, zero)), factor));
            _mm_storeu_ps(out + i + 4, _mm_mul_ps(_mm_cvtepi32_ps(_mm_unpackhi_epi16(values, zero)), factor));
        }
#endif
        for (; i < count; ++i) out[i] = rgba[i] * (1.0f / 65535.0f);
    } else {
        for (size_t i = 0; i < (size_t)ow * oh; ++i) {
            out[i*4] = out[i*4+1] = out[i*4+2] = 0.0f; out[i*4+3] = 1.0f;
        }
        for (int y = 0; y < dh; ++y) for (int x = 0; x < dw; ++x) {
            size_t src = ((size_t)y * dw + x) * 4;
            size_t target = ((size_t)(y + oy) * ow + x + ox) * 4;
            for (int ch = 0; ch < 4; ++ch) out[target+ch] = rgba[src+ch] * (1.0f / 65535.0f);
        }
    }
    if (getenv("GENESIS_MEDIA_PROFILE")) fprintf(stderr, "[gcompose] frame color_us=%lld rgb_us=%lld\n", (long long)(converted-started), (long long)(av_gettime_relative()-converted));
    return 0;
}

// AIR's text raster supplies SDR RGB and alpha coverage. In an HDR master its
// white is 100 nits, rather than an untagged PQ code value of 1 (10,000 nits).
int fpx_hdr_raster(const unsigned char* rgba8, float* out, int w, int h) {
    FpxCtx c = {0}; AVCodecContext dec = {0};
    c.dec = &dec; c.width = w; c.height = h; c.time_base = (AVRational){1,30};
    c.frame = av_frame_alloc();
    if (!c.frame) return -1;
    c.frame->format = AV_PIX_FMT_RGBA; c.frame->width = w; c.frame->height = h;
    c.frame->color_primaries = AVCOL_PRI_BT709; c.frame->color_trc = AVCOL_TRC_BT709;
    c.frame->colorspace = AVCOL_SPC_RGB; c.frame->color_range = AVCOL_RANGE_JPEG;
    int result = -1;
    if (av_frame_get_buffer(c.frame, 32) >= 0) {
        for (int y=0; y<h; ++y) memcpy(c.frame->data[0]+y*c.frame->linesize[0], rgba8+(size_t)y*w*4, (size_t)w*4);
        result = fpx_hi_blit(&c, out, w, h);
        // The RGB color graph has no alpha plane; retain the original glyph coverage.
        if (result >= 0) for (size_t i=0; i<(size_t)w*h; ++i) out[i*4+3] = rgba8[i*4+3]/255.0f;
    }
    av_free(c.hi_rgba);
    if (c.sws_hi) sws_freeContext(c.sws_hi);
    if (c.color_graph) avfilter_graph_free(&c.color_graph);
    if (c.color_frame) av_frame_free(&c.color_frame);
    av_frame_free(&c.frame);
    return result;
}

// Like fpx_decode_frame_scaled but ASPECT-PRESERVING (letterbox/pillarbox into ow x oh).
// Forward-decode window (frames): a request this many frames AHEAD of the current decoder position
// (or fewer) decodes forward WITHOUT seeking — the sequential playback/render case. A larger forward
// jump (or any backward jump) seeks to the nearest keyframe instead, which is cheaper than decoding
// across multiple GOPs. Correctness is independent of this value (the pts>=target check below always
// returns the exact frame); it only trades a seek for a forward decode. ~1 GOP is the sweet spot.
#define FPX_SEQ_FWD_WINDOW 300

static int fpx_decode_letterbox(void* h, int frame_index, void* out, int ow, int oh, int high) {
    if (!h || !out || ow <= 0 || oh <= 0) return -1;
    FpxCtx* c = (FpxCtx*)h;
    const int profile = getenv("GENESIS_MEDIA_PROFILE") != NULL;
    const int64_t profile_begin = profile ? av_gettime_relative() : 0;
    int64_t seek_us = 0, receive_us = 0, read_us = 0, send_us = 0;
    int skipped = 0;
    int64_t target = av_rescale_q(frame_index, av_inv_q(c->frame_rate), c->time_base);

    // Decide seek vs forward-decode. We can decode FORWARD from the current position (no seek) only
    // when the position is known AND the target is strictly ahead of it AND within FPX_SEQ_FWD_WINDOW
    // frames. Everything else (first decode, backward, far-forward) seeks to a keyframe. This is the
    // whole optimization: sequential access no longer re-seeks + re-decodes from a keyframe per frame
    // (which was O(GOP^2) over a GOP — ~345ms/frame at 1440p — vs O(GOP) decoding forward once).
    int64_t window_pts = av_rescale_q(FPX_SEQ_FWD_WINDOW, av_inv_q(c->frame_rate), c->time_base);
    int forward = c->have_pos && target > c->cur_pts && (target - c->cur_pts) <= window_pts;
    if (!forward) {
        const int64_t seek_begin = profile ? av_gettime_relative() : 0;
        if (av_seek_frame(c->fmt, c->vindex, target, AVSEEK_FLAG_BACKWARD) < 0) return -3;
        avcodec_flush_buffers(c->dec);
        c->have_pos = 0; // position reset by the flush; the loop re-establishes it on the next frame
        if (profile) seek_us = av_gettime_relative()-seek_begin;
    }

    // Canonical DRAIN-FIRST decode loop: pull any already-buffered frame first (this is what makes a
    // no-seek forward decode CORRECT — after a prior call broke out mid-GOP, the decoder may hold
    // reordered frames that must be received before feeding new packets), feed a packet only when the
    // decoder asks (EAGAIN), and at end-of-packets flush (send NULL) to drain the tail GOP so a
    // clip's last frames decode instead of returning black (preserves the b223433 EOF-drain fix).
    // Return the FIRST frame with pts >= target (frame-accurate; identical selection to before).
    int eof_sent = 0;
    for (;;) {
        const int64_t receive_begin = profile ? av_gettime_relative() : 0;
        int r = fpx_pull(c, c->frame);
        if (profile) receive_us += av_gettime_relative()-receive_begin;
        if (r == 0) {
            int64_t pts = c->frame->best_effort_timestamp;
            if (pts != AV_NOPTS_VALUE) { c->cur_pts = pts; c->have_pos = 1; }
            if (pts == AV_NOPTS_VALUE || pts >= target) {
                if (pts == AV_NOPTS_VALUE) c->have_pos = 0; // can't track an unknown-pts position
                // Unused source frames never cross the GPU/CPU boundary.
                const int64_t blit_begin = profile ? av_gettime_relative() : 0;
                if (!high && fpx_cpu_frame(c) < 0) { c->have_pos = 0; return -4; }
                if ((high ? fpx_hi_blit(c, (float*)out, ow, oh) : fpx_lb_blit(c, (unsigned char*)out, ow, oh)) < 0) { c->have_pos = 0; return -4; }
                if (profile) fprintf(stderr,
                    "[gcompose] video_frame=%d forward=%d seek_us=%lld receive_us=%lld read_us=%lld send_us=%lld blit_us=%lld skipped=%d total_us=%lld\n",
                    frame_index,forward,(long long)seek_us,(long long)receive_us,
                    (long long)read_us,(long long)send_us,(long long)(av_gettime_relative()-blit_begin),
                    skipped,(long long)(av_gettime_relative()-profile_begin));
                return 0;
            }
            ++skipped;
            continue; // frame is before target: drop it and keep receiving
        }
        if (r == AVERROR_EOF) { c->have_pos = 0; return -3; } // drained, target past end
        // r == AVERROR(EAGAIN): the decoder needs more input.
        if (eof_sent) { c->have_pos = 0; return -3; } // already flushing and still nothing → done
        int sent = 0;
        for (;;) {
            const int64_t read_begin = profile ? av_gettime_relative() : 0;
            const int packet_result = av_read_frame(c->fmt, c->pkt);
            if (profile) read_us += av_gettime_relative()-read_begin;
            if (packet_result < 0) break;
            if (c->pkt->stream_index == c->vindex) {
                const int64_t send_begin = profile ? av_gettime_relative() : 0;
                avcodec_send_packet(c->dec, c->pkt);
                if (profile) send_us += av_gettime_relative()-send_begin;
                av_packet_unref(c->pkt);
                sent = 1;
                break;
            }
            av_packet_unref(c->pkt);
        }
        if (!sent) {
            avcodec_send_packet(c->dec, NULL); // end of packets → enter draining mode
            eof_sent = 1;
        }
    }
}

int fpx_decode_frame_letterbox(void* h, int index, unsigned char* out, int w, int ht) {
    return fpx_decode_letterbox(h, index, out, w, ht, 0);
}
int fpx_decode_frame_f32(void* h, int index, float* out, int w, int ht) {
    return fpx_decode_letterbox(h, index, out, w, ht, 1);
}

// Aspect-preserving sequential decode (no seek) — for playback.
int fpx_decode_next_letterbox(void* h, unsigned char* out, int ow, int oh) {
    if (!h || !out || ow <= 0 || oh <= 0) return -1;
    FpxCtx* c = (FpxCtx*)h;
    int got = -1;
    while (got != 0 && av_read_frame(c->fmt, c->pkt) >= 0) {
        if (c->pkt->stream_index == c->vindex) {
            if (avcodec_send_packet(c->dec, c->pkt) == 0) {
                while (fpx_receive(c) == 0) {
                    if (fpx_lb_blit(c, out, ow, oh) < 0) { av_packet_unref(c->pkt); return -4; }
                    got = 0; break;
                }
            }
        }
        av_packet_unref(c->pkt);
        if (got == 0) break;
    }
    return got;
}

// Decode the NEXT frame in sequence (no seek) at NATIVE resolution -> RGBA8 (w*h*4).
// Fast sequential export after one fpx_decode_frame_rgba seek. Negative at EOS.
int fpx_decode_next_rgba(void* h, unsigned char* out, int out_size) {
    if (!h || !out) return -1;
    FpxCtx* c = (FpxCtx*)h;
    if (out_size < c->width * c->height * 4) return -2;
    int got = -1;
    while (got != 0 && av_read_frame(c->fmt, c->pkt) >= 0) {
        if (c->pkt->stream_index == c->vindex) {
            if (avcodec_send_packet(c->dec, c->pkt) == 0) {
                while (fpx_receive(c) == 0) {
                    uint8_t* dst[4] = { out, NULL, NULL, NULL };
                    int dstln[4] = { c->width * 4, 0, 0, 0 };
                    sws_scale(c->sws, (const uint8_t* const*)c->frame->data, c->frame->linesize,
                              0, c->height, dst, dstln);
                    got = 0; break;
                }
            }
        }
        av_packet_unref(c->pkt);
        if (got == 0) break;
    }
    return got;
}

// Video stream frame rate as num/den (e.g. 30000/1001 or 30/1).
int fpx_fps_num(void* h) { return h ? ((FpxCtx*)h)->frame_rate.num : 0; }
int fpx_fps_den(void* h) { return h ? ((FpxCtx*)h)->frame_rate.den : 1; }

// Total frame count of the video stream (nb_frames, or estimated from duration*fps).
int fpx_nframes(void* h) {
    if (!h) return 0;
    FpxCtx* c = (FpxCtx*)h;
    AVStream* st = c->fmt->streams[c->vindex];
    if (st->nb_frames > 0) return (int)st->nb_frames;
    if (c->fmt->duration > 0 && c->frame_rate.num > 0) {
        double secs = (double)c->fmt->duration / AV_TIME_BASE;
        return (int)(secs * av_q2d(c->frame_rate) + 0.5);
    }
    return 0;
}

void fpx_close(void* h) {
    if (!h) return;
    FpxCtx* c = (FpxCtx*)h;
    av_free(c->hi_rgba);
    if (c->sws2) sws_freeContext(c->sws2);
    if (c->sws) sws_freeContext(c->sws);
    if (c->color_frame) av_frame_free(&c->color_frame);
    if (c->color_graph) avfilter_graph_free(&c->color_graph);
    if (c->sws_hi) sws_freeContext(c->sws_hi);
    if (c->sws_lb) sws_freeContext(c->sws_lb);   // letterbox scaler (fpx_lb_blit) — was leaked on close
    if (c->hw_transfer) av_frame_free(&c->hw_transfer);
    if (c->frame) av_frame_free(&c->frame);
#ifdef _WIN32
    fpx_transfer_clear(c);
    genesis_preview_close(&c->gpu_preview);
#endif
    if (c->pkt) av_packet_free(&c->pkt);
    if (c->dec) avcodec_free_context(&c->dec);
    if (c->fmt) avformat_close_input(&c->fmt);
    free(c);
}

#ifdef FPX_TEST
#include <stdio.h>
// usage: fpxtest <file> <frame_index> <out.raw>
int main(int argc, char** argv) {
    if (argc < 4) { fprintf(stderr, "usage: %s file frame out.raw\n", argv[0]); return 2; }
    void* h = fpx_open(argv[1]);
    if (!h) { fprintf(stderr, "open failed\n"); return 1; }
    int w = fpx_width(h), ht = fpx_height(h);
    int sz = w * ht * 4;
    unsigned char* buf = (unsigned char*)malloc(sz);
    int r = fpx_decode_frame_rgba(h, atoi(argv[2]), buf, sz);
    if (r != 0) { fprintf(stderr, "decode failed %d\n", r); return 1; }
    FILE* f = fopen(argv[3], "wb"); fwrite(buf, 1, sz, f); fclose(f);
    fprintf(stderr, "ok %dx%d -> %s (%d bytes)\n", w, ht, argv[3], sz);
    free(buf); fpx_close(h);
    return 0;
}
#endif
