Keyed audio fade source and numeric acceptance.
Baseline7200 PCM error retained as a curated fact; raw private-path error logs excluded.
Curve oracle isolates source decoding with unkeyed processing; temporal refusal recovery has a primed authored reference.
No media, executables, private paths or new sustained performance claim.
