"""Independent native-worker sum oracle. This deliberately asserts the known defect."""
import argparse
from array import array
import hashlib
import itertools
import json
import math
from pathlib import Path
import struct
import subprocess
import wave

FRAMES = 9600
SR = 48000


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def wire(path):
    return str(path).replace("%", "%25").replace(" ", "%20").replace("\t", "%09").replace("\n", "%0A").replace("\r", "%0D")


def mono_float(path, sample):
    # IEEE float WAV: independently generated constant +0.8 or -0.8, no lossy
    # encoder, normalization, or external process in fixture construction.
    payload = struct.pack("<f", sample) * FRAMES
    fmt = struct.pack("<HHIIHH", 3, 1, SR, SR*4, 4, 32)
    path.write_bytes(b"RIFF" + struct.pack("<I", 36+len(payload)) + b"WAVEfmt " +
                     struct.pack("<I", len(fmt)) + fmt + b"data" + struct.pack("<I", len(payload)) + payload)


def read_pcm(path):
    with wave.open(str(path), "rb") as audio:
        assert (audio.getnchannels(), audio.getframerate(), audio.getsampwidth(), audio.getnframes()) == (2, SR, 2, FRAMES)
        samples = array("h", audio.readframes(FRAMES))
    return samples


def summary(path):
    samples = read_pcm(path)
    return dict(min_pcm=min(samples), max_pcm=max(samples), mean_pcm=sum(samples)/len(samples),
                mean_normalized=sum(samples)/len(samples)/32767, sha256=sha(path))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--worker", type=Path, required=True)
    args = parser.parse_args()
    root = Path(__file__).resolve().parent
    worker = args.worker.resolve()
    names = ("plus_a", "plus_b", "minus")
    for name, value in zip(names, (.8, .8, -.8)):
        mono_float(root/(name+".wav"), value)
    original_hashes = {name: sha(root/(name+".wav")) for name in names}
    # The native decoder requests stereo before its FX chain; FFmpeg's standard
    # mono-to-stereo rematrix applies 1/sqrt(2) to each channel. An explicit gain
    # compensation restores +0.8/+0.8/-0.8 per channel before the mixer.
    chain = "volume=1.4142135623730951"
    commands = []
    orders = list(itertools.permutations(names))
    singles = []
    def lines(order):
        return [f"AUDIO {wire(root/(name+'.wav'))} 0 0.2 0 1 0 0 0.2 0 {chain}" for name in order]
    for name in names:
        out = root/("single_"+name+".wav")
        singles.append(out)
        commands.extend([f"WAVE {wire(out)} 0.2", *lines((name,)), f"WAVECLOSE {wire(out)}"])
    outputs = []
    for index, order in enumerate(orders):
        out = root/f"order_{index}.wav"
        outputs.append(out)
        commands.extend([f"WAVE {wire(out)} 0.2", *lines(order), f"WAVECLOSE {wire(out)}"])
    # LEVELS uses the same accumulator, so the UI/export meter discrepancy is
    # measured independently of WAV quantization.
    for index in (0, 1):
        commands.extend(["MEAS 0.2", *lines(orders[index]), f"LEVELS {wire(root/f'levels_{index}.f32')}"])
    command_text = "\n".join(commands)+"\n"
    (root/"commands.txt").write_text(command_text, encoding="utf-8")
    done = subprocess.run([str(worker), "--serve", "--size", "16", "16"], input=command_text,
                          text=True, encoding="utf-8", errors="replace", stdout=subprocess.PIPE,
                          stderr=subprocess.STDOUT, timeout=30,
                          creationflags=0x08000000 if __import__('os').name == "nt" else 0)
    (root/"worker.log").write_text(done.stdout, encoding="utf-8")
    assert done.returncode == 0 and "ERR" not in done.stdout, done.stdout
    single_results = [summary(path) for path in singles]
    for result, expected in zip(single_results, (.8, .8, -.8)):
        assert result["min_pcm"] == result["max_pcm"]
        assert abs(result["mean_normalized"]-expected) <= 2/32767, result
    # Independent model: sum all authored signed samples with no intermediate
    # clipping, clamp once for PCM16 output and round half away from zero.
    wanted = sum((.8, .8, -.8))
    expected_pcm = math.floor(max(-1, min(1, wanted))*32767+.5)
    results = []
    for order, out in zip(orders, outputs):
        samples = read_pcm(out)
        results.append(dict(order=list(order), **summary(out),
                            wrong_samples=sum(abs(value-expected_pcm)>2 for value in samples),
                            maximum_error_pcm=max(abs(value-expected_pcm) for value in samples)))
    assert results[0]["wrong_samples"] == FRAMES*2, results
    assert abs(results[0]["mean_normalized"]-.2) < 2/32767, results[0]
    assert results[1]["wrong_samples"] == 0 and abs(results[1]["mean_normalized"]-.8) < 2/32767, results[1]
    assert results[0]["sha256"] != results[1]["sha256"], results
    assert original_hashes == {name: sha(root/(name+".wav")) for name in names}
    levels = [struct.unpack("<4f", (root/f"levels_{index}.f32").read_bytes()) for index in (0, 1)]
    receipt = dict(schema="genesis.audio_mix_order.reproduction.v1", defect_reproduced=True,
                   worker_sha256=sha(worker), source_format="IEEE f32 mono 48000 Hz constant samples",
                   reproduction_script_sha256=sha(Path(__file__)),
                   wrong_permutations=sum(result["wrong_samples"] > 0 for result in results),
                   frames_per_source=FRAMES, decoded_stereo_single_sources=single_results,
                   explicit_mono_rematrix_compensation=chain, source_sha256=original_hashes,
                   expected_sum_normalized=wanted, expected_pcm=expected_pcm, permutations=results,
                   levels_peak_L_R_rms_L_R_dbfs=levels,
                   source_evidence=dict(file="gcompose/src/main.rs", function="ProgAudio::mix",
                                        lines=[1387, 1388], expression="self.buf[start+i]=(self.buf[start+i]+samples[i]).clamp(-1.0,1.0)"),
                   maintained_source_modified=False, fixture_sources_unchanged=True)
    receipt["source_evidence"]["source_sha256"] = sha(root.parent/"gcompose-source/gcompose/src/main.rs")
    (root/"receipt.json").write_text(json.dumps(receipt, indent=2)+"\n", encoding="utf-8")
    print(json.dumps(dict(expected_pcm=expected_pcm, first_order=results[0], reordered=results[1], levels_dbfs=levels), indent=2))


if __name__ == "__main__":
    main()
