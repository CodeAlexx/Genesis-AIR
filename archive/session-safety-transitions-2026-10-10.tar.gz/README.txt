Combined Windows acceptance and independent process/pixel receipts.
Known-gap audio reproduction intentionally asserts a defect; it is not a passing production gate.
Sources and numeric evidence only; no media, executables or personal paths.
