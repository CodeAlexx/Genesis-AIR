"""Private CPU acceptance of state-changing edits on a many-clip project.

Every comparison derives from authored JSON rather than a Genesis roundtrip.
Real authored PCM/BMP files are referenced but never decoded in this CPU stage.
"""
import argparse
from array import array
import copy
import hashlib
import json
import os
from pathlib import Path
import struct
import subprocess
import sys
import time
import wave

REPO=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(REPO/'tests'))
from audio_mix_project import document


def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()


def sources(root):
    result=[]
    for n in range(16):
        path=root/f'PCM {n} 日本語 %20.wav'
        with wave.open(str(path),'wb') as out:
            out.setparams((2,2,48000,0,'NONE','PCM'))
            out.writeframes(array('h',[((n+1)*256),-((n+1)*128)]*96000).tobytes())
        result.append(dict(id=100+n,path=str(path),name=path.name,bin=1,frames=60,fps=30,
                           width=0,height=0,has_video=False,has_audio=True,audio_rate=48000,
                           audio_channels=2,online=True))
        path=root/f'Bitmap {n} %20.bmp'
        pixels=bytes([n*13,64+n*7,255-n*11,255])*32*32
        path.write_bytes(struct.pack('<2sIHHI',b'BM',54+len(pixels),0,0,54)+
                         struct.pack('<IIIHHIIIIII',40,32,32,1,32,0,len(pixels),2835,2835,0,0)+pixels)
        result.append(dict(id=116+n,path=str(path),name=path.name,bin=1,frames=3600,fps=30,
                           width=32,height=32,has_video=True,has_audio=False,audio_rate=0,
                           audio_channels=0,online=True))
    return result


def authored(source,leaf_count=1024):
    doc=document([],())
    doc.update(next_id=500000,monitor_source=100)
    doc['sequences'][0].update(name='Long documentary rough cut',width=160,height=90)
    doc['names']=['gain','opacity','level','threshold']
    doc['sources']=source
    def track(ident,owner,kind,name,order):
        return dict(id=ident,owner=owner,kind=kind,name=name,order=order,hidden=False,
                    muted=False,locked=False,solo=False,gain=1,pan=0,height=44)
    doc['tracks']=[track(3,2,0,'Root V1',0),track(4,2,1,'Root A1',1)]
    prototype=dict(group=0,enabled=True,selected=False,fade_in=0,fade_out=0,
                   gain=1,pan=0,speed=1,reverse=False)
    for sequence in range(8):
        owner=10+sequence
        fps=(24,30,60000/1001)[sequence%3]
        doc['sequences'].append(dict(id=owner,name=f'Interview 日本語 {sequence}',fps=fps,
                                     width=64 if sequence%2==0 else 36,height=36 if sequence%2==0 else 64))
        video,audio=200+sequence*2,201+sequence*2
        doc['tracks'] += [track(video,owner,0,f'Child{sequence} V1',0),track(audio,owner,1,f'Child{sequence} A1',1)]
        per_sequence=leaf_count//8
        for k in range(per_sequence):
            ident=1000+sequence*per_sequence+k
            sound=k%2==1
            clip=dict(prototype,id=ident,owner=owner,source=100+k%16 if sound else 116+k%16,
                      nested=0,source_in=0,length=30,start=(k//2)*30,track=audio if sound else video)
            doc['clips'].append(clip)
            effect=100000+sequence*per_sequence+k
            doc['filters'].append(dict(id=effect,clip=ident,kind='compressor' if sound else 'brightness',
                                       enabled=True,order=0))
            doc['filter_params'].append(dict(filter=effect,name='threshold' if sound else 'level',value=-12 if sound else 1.1))
            for frame in (0,4,8,12,16,20,24,29):
                doc['keys'].append(dict(clip=ident,owner=owner,param=1 if sound else 2,
                                        frame=frame,value=.5+(frame%3)*.125,interp=2 if frame!=29 else 4))
        for k in range(8):
            doc['subtitles'].append(dict(id=300000+sequence*8+k,owner=owner,start=k*240,
                                         finish=k*240+120,text=f'Interview {sequence}/{k} 日本語'))
            doc['markers'].append(dict(id=400000+sequence*8+k,owner=owner,frame=k*240,duration=0,
                                       label=f'Keep {sequence}/{k}',color=k%4))
    for n in range(16):
        doc['clips'].append(dict(prototype,id=10000+n,owner=2,source=0,nested=10+n%8,
                                 source_in=0,length=30,start=n*30,track=3))
    return doc


def semantic(doc):
    result=copy.deepcopy(doc)
    # Key storage order is not interpolation order, but ownership/frame/value is.
    result['keys'].sort(key=lambda k:(k['clip'],k['owner'],k['param'],k['frame']))
    return result


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--client',type=Path,required=True)
    parser.add_argument('--out',type=Path,required=True)
    parser.add_argument('--leaf-clips',type=int,choices=(1024,2048),default=1024)
    args=parser.parse_args()
    root=args.out.resolve();root.mkdir(parents=True,exist_ok=False)
    client=args.client.resolve()
    src=sources(root)
    original={Path(s['path']):sha(Path(s['path'])) for s in src}
    initial=authored(src,args.leaf_clips)
    project=root/'authored.air';project.write_text(json.dumps(initial),encoding='utf-8')
    original[project]=sha(project)
    report=dict(schema='genesis.private.large_project.v1',passed=False,
                client_sha256=sha(client),oracle_sha256=sha(Path(__file__)),
                clips=len(initial['clips']),sources=len(src),keys=len(initial['keys']),
                filters=len(initial['filters']),subtitles=len(initial['subtitles']),
                sequences=len(initial['sequences']),authored_bytes=project.stat().st_size,
                scope='Actual commands, CPU-only state/Undo/save/open/refusals; no UI/media/performance claim')
    try:
        began=time.monotonic()
        env=dict(os.environ,GENESIS_FAKE_PROVIDER='1')
        done=subprocess.run([str(client),str(root)],capture_output=True,timeout=120,env=env,
                            creationflags=0x08000000 if os.name=='nt' else 0)
        report.update(native_seconds=time.monotonic()-began,stdout=done.stdout.decode(errors='replace'),
                      stderr=done.stderr.decode(errors='replace'))
        assert done.returncode==0,(done.returncode,report['stdout'],report['stderr'])
        keyed=copy.deepcopy(initial)
        keyed['keys'].append(dict(clip=1001,owner=10,param=1,frame=7,value=.125,interp=4))
        edited=copy.deepcopy(keyed)
        next(c for c in edited['clips'] if c['id']==1001).update(fade_in=2,fade_out=3)
        checks={'opened':initial,'keyed':keyed,'edited':edited,'undo-fades':keyed,'undo-key':initial,
                'redo-key':keyed,'redo-fades':edited,'refused-save':edited,'refused-open':edited,
                'undo-after-refusals':keyed,'reopened':edited,'checkpoint':initial,'edited-checkpoint':edited}
        for name,expected in checks.items():
            actual=json.loads((root/(name+'.air')).read_text(encoding='utf-8'))
            assert semantic(actual)==semantic(expected),(name,'Independent whole graph comparison failed')
        report['independent_whole_document_comparisons']=list(checks)
        assert all(sha(path)==value for path,value in original.items()),'Authored source/project changed'
        for n in range(32):
            assert (root/f'checkpoint.air.genesis-save-{n}.tmp').read_text()=='foreign save reservation'
        operations=[]
        for row in (root/'operations.tsv').read_text().splitlines()[1:]:
            name,okay,dirty,revision,elapsed=row.split('\t')
            assert okay=='true',row
            operations.append(dict(name=name,dirty=dirty=='true',document_revision=int(revision),
                                   elapsed_ms=int(elapsed)/1e6))
        assert len(operations)==13,len(operations)
        report.update(passed=True,operations=operations,immutable_sources_project_reservations=True,
                      owned_worker_started=False)
    except BaseException as problem:
        report['failure']=repr(problem)
        raise
    finally:(root/'receipt.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(dict(passed=report['passed'],comparisons=len(checks),native_seconds=report['native_seconds'])))


if __name__=='__main__':main()
