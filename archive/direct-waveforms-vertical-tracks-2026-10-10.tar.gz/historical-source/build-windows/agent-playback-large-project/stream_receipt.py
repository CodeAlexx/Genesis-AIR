"""Verify private large-document compact receipts independently of native checks."""
import argparse
import hashlib
import json
from pathlib import Path
import statistics


def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--root',type=Path,required=True)
    parser.add_argument('--project',type=Path,required=True)
    parser.add_argument('--client',type=Path,required=True)
    args=parser.parse_args()
    root=args.root.resolve()
    document=json.loads(args.project.read_text(encoding='utf-8'))
    rows=[]
    for row in (root/'stream.tsv').read_text().splitlines()[1:]:
        fields=list(map(int,row.split('\t')))
        assert len(fields)==9
        ident,frame,base,revision,ready,parse,paint,total,size=fields
        assert frame==ident-1 and base==(1 if ident<5 else 5) and revision==(1 if ident<5 else 2)
        assert 0<parse<=ready<=total and 0<paint<=total
        rows.append(dict(id=ident,frame=frame,snapshot=base,document_revision=revision,
                         ready_ms=ready/1e6,parse_ms=parse/1e6,paint_ms=paint/1e6,
                         total_ms=total/1e6,snapshot_file_bytes=size))
    assert [r['id'] for r in rows]==list(range(1,9))
    assert len({r['snapshot_file_bytes'] for r in rows[:4]})==1
    assert len({r['snapshot_file_bytes'] for r in rows[4:]})==1
    raw=(root/'lane/request.air').read_text(encoding='utf-8')
    header,payload=raw.split('\n',1)
    assert header.split('\t')[0]=='5'
    updated=json.loads(payload)
    expected=json.loads(args.project.read_text(encoding='utf-8'))
    expected['program'].update(playing=True,frame=4)
    expected['keys'].append(dict(clip=1001,owner=10,param=1,frame=9,value=.0625,interp=4))
    for item in (updated,expected):item['keys'].sort(key=lambda k:(k['clip'],k['owner'],k['param'],k['frame']))
    assert updated==expected,'Changed child metadata or immutable graph was lost in snapshot publication'
    steady=[r for r in rows if r['id'] not in (1,5)]
    report=dict(schema='genesis.private.large_project_stream.v1',passed=True,
                production_commit='36d41fbbd7cf10e751ce197320eda4ba88480049',
                client_sha256=sha(args.client),fixture_sha256=sha(root.parent/'stream.ai'),
                oracle_sha256=sha(Path(__file__)),project_sha256=sha(args.project),
                raw_tsv_sha256=sha(root/'stream.tsv'),clips=len(document['clips']),
                keys=len(document['keys']),requests=rows,
                steady_total_ms=dict(minimum=min(r['total_ms'] for r in steady),
                                     median=statistics.median(r['total_ms'] for r in steady),
                                     maximum=max(r['total_ms'] for r in steady)),
                actual_changed_child_snapshot_matches_authored_graph=True,
                scope='CPU fake pictures, actual persistent preview task/channel, cache revisions and AIR renderer. Excludes native window, native present, audio, decoding and GPU.')
    (root/'receipt.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(dict(passed=True,clips=report['clips'],steady=report['steady_total_ms'])))


if __name__=='__main__':main()
