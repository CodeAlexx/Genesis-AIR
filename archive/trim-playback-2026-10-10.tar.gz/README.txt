Closed-process numeric profiles and source/acceptance receipts.
Reproduce timing: python source/tests/window_timing.py NAME/window.tsv
Reproduce losses: python source/tests/window_loss.py NAME/window.tsv
The final combined application hash differs from the performance candidate; see application.json.
