from pathlib import Path
import csv,hashlib,json,datetime
root=Path(__file__).resolve().parent.parent
work=root/'build-windows'
run=work/'pro-content-stream-final-ui-433c2ee6078a4bf7b37cbd0b054390a6'
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
launch=json.loads((run/'launch.json').read_text())
assert sha(run/'private-project.air')==launch['project_sha256']==sha(root/'Regular 1080p60.air')
rows=list(csv.DictReader((run/'window.tsv').open(),delimiter='\t'))
shown={int(r['program_shown']) for r in rows}
assert {0,72497,76700}.issubset(shown) and rows[-1]['program_shown']=='0'
session=Path((run/'session-report.txt').read_text().strip())
strip=session/'timeline-strips'
peaks=(strip/'waveforms.tsv').read_text().splitlines()[1].split('\t')[7:]
thumbs=(strip/'thumbnails.tsv').read_text().splitlines()
assert len(peaks)==25567 and len(thumbs)==23
assert thumbs[0].split('\t')[1]=='0' and thumbs[-1].split('\t')[1]=='75174'
assert not list(session.rglob('*.rf64'))
record=dict(passed=True,app_sha256=launch['app_sha256'],worker_sha256=launch['worker_sha256'],
    run=str(run),profile_sha256=sha(run/'window.tsv'),profile_rows=len(rows),
    project_frames=76701,processed_peak_count=len(peaks),fit_bitmap_rows=len(thumbs),
    observed={'whole_timeline_fit':True,'late_seek_frame':72497,'late_seek_timecode':'00:20:08:17',
        'late_picture_marker_and_histogram_parade_luma_changed':True,
        'end_frame':76700,'end_timecode':'00:21:18:20','end_picture_black':True,
        'start_frame_zero_nonblank_and_scopes_restored':True,
        'unchanged_private_project_closed':True},
    no_rf64_intermediate_found=True,original_project_unchanged=True,
    waveform_sha256=sha(strip/'waveforms.tsv'),thumbnail_metadata_sha256=sha(strip/'thumbnails.tsv'),
    functional_check_during_background_suite=True,cadence_acceptance=False,
    complete_professional_editing_acceptance=False,
    recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
with (work/'pro-content-stream-final-full-ui.json').open('x') as f:json.dump(record,f,indent=2)
print(json.dumps(record))
