from pathlib import Path
import csv, hashlib, json, datetime
root=Path(__file__).resolve().parent.parent
run=root/'build-windows/pro-content-stream-final-ui-26b6225d01df4c4dbfc108be26cf5174'
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
launch=json.loads((run/'launch.json').read_text())
rows=list(csv.DictReader((run/'window.tsv').open(),delimiter='\t'))
shown={int(r['program_shown']) for r in rows}
assert {0,1786,3599}.issubset(shown)
active=[r for r in rows if r['playing']=='1' and r['clock_ok']=='1' and int(r['samples_after'])>int(r['samples_before'])]
assert active and any(int(r['program_shown'])>1786 for r in active)
assert rows[-1]['playing']=='0' and rows[-1]['program_shown']=='0'
session=Path((run/'session-report.txt').read_text().strip())
metadata={}
for name in ('timeline-strips/waveforms.tsv','timeline-strips/thumbnails.tsv','preview/request.air','preview/ready.id'):
    p=session/name
    if p.is_file(): metadata[name]={'sha256':sha(p),'bytes':p.stat().st_size}
assert 'timeline-strips/waveforms.tsv' in metadata
record=dict(schema='genesis.content_stream.native_ui.v1',passed=True,
    app_sha256=launch['app_sha256'],worker_sha256=launch['worker_sha256'],
    run=str(run),profile_sha256=sha(run/'window.tsv'),profile_rows=len(rows),
    private_project_initial_sha256=launch['project_sha256'],private_project_saved_sha256=sha(run/'private-project.air'),
    source='regular 1080p60',preview_canvas=[480,270],ordinary_maximized_window=[2560,1316],
    observed={'copy_status':'copied','paste':[2,7199,3599],'undo':[1,3600,3599],
        'redo':[2,7199,3599],'fit_two_clips':True,'mapped_thumbnails_and_fine_waveforms':True,
        'ruler_seek_frame':1786,'ruler_seek_timecode':'00:00:29:46',
        'seek_program_picture_and_histogram_parade_luma_changed':True,
        'embedded_audio_target':'V1','play_live_stereo_meters':True,
        'mute_silent_meters':True,'unmute_live_stereo_meters':True,
        'stop_paused_silent':True,'start_frame_zero_nonblank':True,
        'saved_and_closed_only_disposable_window':True},
    clock_active_rows=len(active),final_profile_frame=0,metadata=metadata,
    cadence_acceptance=False,physical_audio_video_sync_acceptance=False,
    full_professional_editing_acceptance=False,
    recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
with (root/'build-windows/pro-content-stream-final-ui.json').open('x') as f: json.dump(record,f,indent=2)
print(json.dumps({'passed':True,'profile_rows':len(rows),'clock_active_rows':len(active),'metadata':list(metadata)}))
