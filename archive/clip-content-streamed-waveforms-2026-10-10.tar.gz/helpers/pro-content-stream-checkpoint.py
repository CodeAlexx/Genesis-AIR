"""Exact private acceptance and root publication; never controls user windows."""
from pathlib import Path
import datetime, hashlib, io, json, os, re, shutil, subprocess, sys, tarfile, uuid

ROOT=Path(__file__).resolve().parent.parent
WORK=ROOT/'build-windows'
PREFIX=os.environ.get('GENESIS_CHECKPOINT_PREFIX','pro-content-stream')
assert PREFIX in ('pro-content-stream','pro-content-stream-final')
STAGE=WORK/(PREFIX+'-runtime')
BIN=WORK/(PREFIX+'-native/bin/Release')
FROZEN=WORK/(PREFIX+'-frozen.json')
OLD=WORK/'long-timeline-publication.json'
PROTECTED={
    ROOT/'Costa Rica 4K.air':'480d82e310ba6f231fab2c0c0db9945dab193d63073cb63fe053019a13aeb143',
    ROOT/'Regular 1080p60.air':'7d9e045225e1a236237b85c22342f612c1be92e2cfd298e47df58df8014c9ba0',
    Path('<USER>/Downloads/AirFetch/COSTA RICA IN 4K 60fps HDR (ULTRA HD).mp4'):'bff7165e6704e7188fee82b990e5128fe87c3ce9c5ef7eeb85bd1bb0da42c6da',
    Path('<USER>/Downloads/AirFetch/Which is The Best Qwen3.8-27B_.mp4'):'061d76990215c31e6dc58d22f4ecd09ac92d414fdc73061e8dfcb502cee3f11d',
}
def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda:f.read(1048576),b''):h.update(block)
    return h.hexdigest()
def load(path):return json.loads(Path(path).read_text(encoding='utf-8-sig'))
def write(path,value):
    with Path(path).open('x',encoding='utf-8') as f:json.dump(value,f,indent=2)
def protected():
    for p,h in PROTECTED.items():assert sha(p)==h,str(p)
def prepare():
    protected();old=load(OLD)
    assert not STAGE.exists(),'Stage already exists; preserve it'
    STAGE.mkdir()
    for name,h in old['root_binaries'].items():
        assert sha(ROOT/name)==h,name
        shutil.copyfile(ROOT/name,STAGE/name)
    assert sha(ROOT/'genesis-media-runtime.txt')==old['runtime_sha256']
    shutil.copyfile(ROOT/'genesis-media-runtime.txt',STAGE/'genesis-media-runtime.txt')
    worker=WORK/'agent-stream-peaks-native/genesis-gcompose.exe'
    assert sha(worker)=='aa40b96c631c82cfc834d027678e95a00bd8d5f61db54f15e7c7ecefcf74228c'
    shutil.copyfile(worker,STAGE/'genesis-gcompose.exe')
    paths=subprocess.check_output(['git','ls-files'],cwd=ROOT,text=True).splitlines()
    paths+=['tests/clip_clipboard.ai','tests/clip_clipboard_media.ai','tests/clip_clipboard_media.py','tests/direct_waveform_stream.py']
    files=sorted(set(n for n in paths if (ROOT/n).is_file() and
        (n.startswith(('src/','tests/','windows/','patches/')) or n in ('build-windows.ps1','build-linux.sh'))))
    frozen={n:sha(ROOT/n) for n in files}
    sdk=WORK/'AIR-SDK'
    sdk_files={n:sha(sdk/n) for n in ('stdlib/editor.ai','runtime/windows/air_proc_pipe_win32.c','runtime/windows/air_ui_win32.c')}
    for patch in ('air-editor.patch','air-process-wait-windows.patch','air-ui-text-windows.patch'):
        subprocess.run(['git','apply','--reverse','--check',str(ROOT/'patches'/patch)],cwd=sdk,check=True)
    equality=load(WORK/'agent-stream-peaks-source-equality.json')
    assert equality['passed'] and equality['canonical_private_exact']
    for n,h in equality['files'].items():
        for directory in ('gcompose-source','agent-stream-peaks-source'):
            assert sha(WORK/directory/'gcompose'/n)==h,(directory,n)
    subprocess.run(['git','apply','--reverse','--check',str(ROOT/'windows/gcompose-windows.patch')],cwd=WORK/'gcompose-source',check=True)
    write(FROZEN,dict(schema='genesis.content_stream_frozen.v1',
        captured_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),source_sha256=frozen,
        sdk_source_sha256=sdk_files,worker_source_sha256=equality['files'],
        worker_sha256=sha(worker),baseline_payload=old['root_binaries'],runtime_sha256=old['runtime_sha256'],
        worker_pin=old['worker_pin'],sdk_pin=old['sdk_pin'],protected_assets_verified=True))
    print('Frozen shared sources, exact worker and protected inputs; private stage prepared.')
def verify_source():
    receipt=load(FROZEN)
    for n,h in receipt['source_sha256'].items():assert sha(ROOT/n)==h,n
    for n,h in receipt['sdk_source_sha256'].items():assert sha(WORK/'AIR-SDK'/n)==h,n
    for n,h in receipt['worker_source_sha256'].items():assert sha(WORK/'gcompose-source/gcompose'/n)==h,n
    for directory,key in (('AIR-SDK','sdk_pin'),('gcompose-source','worker_pin')):
        assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=WORK/directory,text=True).strip()==receipt[key]
    protected();return receipt
def payload():
    receipt=verify_source()
    hashes={n:sha(STAGE/n) for n in receipt['baseline_payload']}
    assert hashes['genesis-gcompose.exe']==receipt['worker_sha256']
    assert hashes['OpenCL.dll']==receipt['baseline_payload']['OpenCL.dll']
    assert sha(STAGE/'genesis-media-runtime.txt')==receipt['runtime_sha256']
    for n in ('Genesis-AIR.exe','air-native-shell.dll','air-native-dialogs.dll','air-ui-host.dll','genesis-native-audio.dll'):
        assert sha(BIN/n)==hashes[n],n
    for n in ('NotoSansJP.ttf','OFL.txt'):
        assert sha(STAGE/'fonts'/n)==sha(ROOT/'fonts'/n),n
    assert not list(STAGE.glob('av*.dll')) and not list(STAGE.glob('sw*.dll')) and not list(STAGE.glob('ff*.exe'))
    return hashes
def launch(installed=False,short=False):
    hashes=payload();folder=ROOT if installed else STAGE
    if installed:
        for n,h in hashes.items():assert sha(ROOT/n)==h,n
    run=WORK/(PREFIX+'-'+('root-' if installed else 'ui-')+uuid.uuid4().hex)
    run.mkdir()
    source=ROOT/'Regular 1080p60.air'
    if short:source=WORK/'regular-1080p60-60sec.air'
    assert source.is_file(),source
    project=ROOT/'Regular 1080p60.air' if installed else run/'private-project.air'
    if not installed:shutil.copyfile(source,project)
    env=dict(os.environ,GENESIS_GCOMPOSE=str(folder/'genesis-gcompose.exe'),
        GENESIS_SCRATCH=str(run/'scratch'),GENESIS_SESSION_REPORT=str(run/'session-report.txt'),
        GENESIS_WINDOW_PROFILE=str(run/'window.tsv'))
    env.pop('GENESIS_FAKE_PROVIDER',None)
    child=subprocess.Popen([str(folder/'Genesis-AIR.exe'),'open',str(project)],cwd=ROOT,
        env=env,creationflags=subprocess.CREATE_NO_WINDOW)
    receipt=dict(pid=child.pid,app_sha256=hashes['Genesis-AIR.exe'],worker_sha256=hashes['genesis-gcompose.exe'],
        project=str(project),project_sha256=sha(project),scratch=str(run/'scratch'),
        window_profile=str(run/'window.tsv'),session_report=str(run/'session-report.txt'),
        shell_window=False,launched_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
    write(run/'launch.json',receipt);print(json.dumps(dict(run=str(run),**receipt)))
def gate():
    frozen=verify_source();hashes=payload()
    assert (WORK/(PREFIX+'-build.exit')).read_text().strip()=='0'
    assert (WORK/(PREFIX+'-windows.exit')).read_text().strip()=='0'
    log=WORK/(PREFIX+'-windows.log')
    body=log.read_text(encoding='utf-8-sig')
    assert 'Real Windows media/Unicode paths, source/program preview and failure exit codes passed.' in body
    assert 'Controls: 757 clicks reported an outcome' in body
    assert 'exceeded the test deadline' not in body
    graph=load(WORK/'clip-clipboard-tests.json')['payload']
    assert graph['status']=='pass' and graph['cases']['passed']==11 and graph['checks']==59
    reports={}
    for name,client in [('clip-clipboard-media.json','genesis-clip-clipboard-media.exe'),
                        ('direct-waveforms.json','genesis-direct-waveforms.exe'),
                        ('nested-waveforms.json','genesis-nested-waveforms.exe')]:
        record=load(WORK/name)
        assert record['passed'] and record['worker_sha256']==hashes['genesis-gcompose.exe'],name
        assert record['client_sha256']==sha(BIN/client),name
        if name=='clip-clipboard-media.json':
            assert record['app_sha256']==hashes['Genesis-AIR.exe']
            assert len(record['cases'])==5 and all(c['passed'] for c in record['cases'])
        reports[name]=sha(WORK/name)
    stream=load(WORK/'direct-waveform-stream.json')
    assert stream['passed'] and stream['worker_sha256']==hashes['genesis-gcompose.exe']
    assert len(stream['cases'])==16 and len(stream['refusals'])==11
    ui=load(WORK/(PREFIX+'-ui.json'))
    assert ui['passed'] and ui['app_sha256']==hashes['Genesis-AIR.exe']
    assert ui['worker_sha256']==hashes['genesis-gcompose.exe']
    full_ui=load(WORK/(PREFIX+'-full-ui.json'))
    assert full_ui['passed'] and full_ui['app_sha256']==hashes['Genesis-AIR.exe']
    assert full_ui['worker_sha256']==hashes['genesis-gcompose.exe']
    write(WORK/(PREFIX+'-gate.json'),dict(passed=True,source=frozen,root_payload=hashes,
        build_log_sha256=sha(WORK/(PREFIX+'-build.log')),full_windows_exit=0,
        full_windows_log_sha256=sha(log),native_ui_sha256=sha(WORK/(PREFIX+'-ui.json')),
        full_native_ui_sha256=sha(WORK/(PREFIX+'-full-ui.json')),
        reports_sha256=reports,stream_report_sha256=sha(WORK/'direct-waveform-stream.json'),
        complete_professional_editing_acceptance=False))
    print('Exact combined Windows suite, numerical media and native UI verified.')
def publish():
    g=load(WORK/(PREFIX+'-gate.json'));assert g['passed']
    assert sha(WORK/(PREFIX+'-windows.log'))==g['full_windows_log_sha256']
    assert sha(WORK/(PREFIX+'-ui.json'))==g['native_ui_sha256']
    assert sha(WORK/(PREFIX+'-full-ui.json'))==g['full_native_ui_sha256']
    assert verify_source()==g['source'] and payload()==g['root_payload']
    old=load(OLD)
    for n,h in old['root_binaries'].items():assert sha(ROOT/n)==h,n
    backup=WORK/'runtime-backups'/(PREFIX+'-'+uuid.uuid4().hex);backup.mkdir()
    moved={}
    for n,h in g['root_payload'].items():
        target=ROOT/n
        if sha(target)==h:continue
        shutil.copyfile(target,backup/n)
        try:shutil.copyfile(STAGE/n,target)
        except PermissionError:
            preserved=backup/('loaded-'+n)
            assert preserved.resolve().is_relative_to((WORK/'runtime-backups').resolve())
            target.rename(preserved);moved[n]=str(preserved)
            shutil.copyfile(STAGE/n,target)
        assert sha(target)==h,n
    protected()
    assert sha(ROOT/'genesis-media-runtime.txt')==old['runtime_sha256']
    write(WORK/(PREFIX+'-publication.json'),dict(published=True,root_binaries=g['root_payload'],
        runtime_sha256=old['runtime_sha256'],worker_pin=old['worker_pin'],sdk_pin=old['sdk_pin'],
        backup=str(backup),preserved_loaded_images=moved,no_user_process_terminated=True,
        protected_assets_unchanged=True,shared_mm_air_runtime=True,no_separate_ffmpeg_bundle=True,
        full_windows_gate_exit=0,gate_sha256=sha(WORK/(PREFIX+'-gate.json')),
        complete_professional_editing_acceptance=False))
    print('Verified root payload published; protected media and loaded user images preserved.')
def archive():
    g=load(WORK/(PREFIX+'-gate.json'));p=load(WORK/(PREFIX+'-publication.json'))
    assert g['passed'] and p['published'];verify_source();protected()
    for n,h in p['root_binaries'].items():assert sha(ROOT/n)==h,n
    source=sorted(set(g['source']['source_sha256'])|{'README.md','docs/AIR_GAPS.md',
        'docs/CONTROL_COVERAGE.md','docs/FFMPEG_GPU_PREVIEW.md'})
    reports=[PREFIX+suffix for suffix in ('-frozen.json','-gate.json','-publication.json','-ui.json',
        '-full-ui.json','-root-ready.json','-build.log','-build.exit','-windows.log','-windows.exit')]
    reports+=['clip-clipboard-tests.json','clip-clipboard-media.json','direct-waveform-stream.json',
        'direct-waveforms.json','nested-waveforms.json','native-audio-clock.json',
        'agent-stream-peaks-provenance.json','agent-stream-peaks-roundtrip.json',
        'agent-stream-peaks-source-equality.json','agent-stream-peaks-direct.json',
        'agent-stream-peaks-nested.json','agent-stream-peaks-protocol-final.json',
        'agent-editing-clip-content-generated/freeze-identity.json',
        'agent-editing-clip-content-identity-windows/clip-clipboard-tests.json',
        'agent-editing-clip-content-identity-linux/clip-clipboard-tests.json',
        'agent-clipboard-media-five-baseline.json','agent-clipboard-media-five-candidate.json',
        'agent-clipboard-media-single-grade-failure-2.json',
        'agent-base-grade-provenance.json','agent-base-grade-no-copy/receipt.json',
        'agent-base-grade-filter-order.json','agent-base-grade-nested-picture.json']
    def sanitize(data):
        value=data.decode('utf-8-sig')
        for spelling in (str(ROOT).replace('\\','\\\\'),str(ROOT),ROOT.as_posix(),'/mnt/c'+ROOT.as_posix()[2:]):
            value=re.sub(re.escape(spelling),'<REPO>',value,flags=re.I)
        return re.sub(r'c:[\\/]+users[\\/]+alexn','<USER>',value,flags=re.I).encode()
    entries={'source/'+n:sanitize((ROOT/n).read_bytes()) for n in source}
    for n in reports:entries['evidence/'+n]=sanitize((WORK/n).read_bytes())
    entries['helpers/pro-content-stream-checkpoint.py']=sanitize(Path(__file__).read_bytes())
    for helper in ('record-content-stream-ui.py','record-content-stream-full-ui.py','record-content-stream-root.py'):
        entries['helpers/'+helper]=sanitize((WORK/helper).read_bytes())
    for kind in ('ui','full-ui'):
        ui=load(WORK/(PREFIX+'-'+kind+'.json'))
        run=Path(ui['run'])
        session=Path((run/'session-report.txt').read_text().strip())
        for name in ('launch.json','window.tsv'):
            entries['evidence/native-'+kind+'/'+name]=sanitize((run/name).read_bytes())
        for name in ('waveforms.tsv','thumbnails.tsv'):
            entries['evidence/native-'+kind+'/'+name]=sanitize((session/'timeline-strips'/name).read_bytes())
    ready=load(WORK/(PREFIX+'-root-ready.json'))
    assert ready['passed'] and ready['app_sha256']==p['root_binaries']['Genesis-AIR.exe']
    root_run=Path(ready['run'])
    for name,h in ready['snapshots_sha256'].items():
        assert sha(root_run/name)==h,name
        entries['evidence/root-ready/'+name]=sanitize((root_run/name).read_bytes())
    baseline=WORK/'pro-4k-baseline-63c70aee031646f2b1d4f6783fe12e73'
    for n in ('launch.json','analysis.json','window-final.tsv'):
        entries['evidence/ordinary-4k-failing-baseline/'+n]=sanitize((baseline/n).read_bytes())
    indexed={}
    for n in source:
        body=subprocess.check_output(['git','show',':'+n],cwd=ROOT)
        blob=subprocess.check_output(['git','hash-object','--stdin'],input=body,cwd=ROOT).strip()
        filtered=subprocess.check_output(['git','hash-object','--path='+n,'--stdin'],
            input=(ROOT/n).read_bytes(),cwd=ROOT).strip()
        assert blob==filtered,('Index differs from frozen worktree after declared Git filters',n)
        indexed[n]=hashlib.sha256(body).hexdigest()
    entries['manifest.json']=json.dumps(dict(schema='genesis.content_stream.archive.v1',
        root_payload=p['root_binaries'],members_sha256={n:hashlib.sha256(v).hexdigest() for n,v in entries.items()},
        worktree_source_sha256={n:sha(ROOT/n) for n in source},
        indexed_source_sha256=indexed,index_matches_worktree_after_git_filters=True,
        excluded='Media, private projects, images, binaries and codec runtimes'),indent=2).encode()
    destination=ROOT/'archive/clip-content-streamed-waveforms-2026-10-10.tar.gz'
    assert not destination.exists(),'Archive exists; preserve it'
    with tarfile.open(destination,'w:gz') as tar:
        for n,data in entries.items():
            member=tarfile.TarInfo(n);member.size=len(data);member.mode=0o644
            tar.addfile(member,io.BytesIO(data))
    with tarfile.open(destination,'r:gz') as tar:
        assert set(tar.getnames())==set(entries)
        for n,data in entries.items():assert tar.extractfile(n).read()==data,n
    write(WORK/(PREFIX+'-archive.json'),dict(path=str(destination),sha256=sha(destination),members=len(entries),readback_verified=True))
    print(json.dumps(dict(archive=str(destination),sha256=sha(destination),members=len(entries))))
if __name__=='__main__':
    if sys.argv[1]=='prepare':prepare()
    elif sys.argv[1]=='verify':verify_source();print('Frozen source and protected inputs verified.')
    elif sys.argv[1]=='launch':launch(short='--short' in sys.argv)
    elif sys.argv[1]=='launch-root':launch(installed=True)
    elif sys.argv[1]=='gate':gate()
    elif sys.argv[1]=='publish':publish()
    elif sys.argv[1]=='archive':archive()
    else:raise SystemExit('Unknown operation')
