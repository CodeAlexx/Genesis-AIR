from pathlib import Path
import hashlib,json,csv,datetime
root=Path(__file__).resolve().parent.parent
work=root/'build-windows'
run=work/'pro-content-stream-final-root-f6ec9347c23f431596ec007b25edcee7'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
launch=json.loads((run/'launch.json').read_text())
assert sha(root/'Genesis-AIR.exe')==launch['app_sha256']
assert sha(root/'genesis-gcompose.exe')==launch['worker_sha256']
assert sha(root/'Regular 1080p60.air')==launch['project_sha256']
session=Path((run/'session-report.txt').read_text().strip())
strip=session/'timeline-strips'
wave=(strip/'waveforms.tsv').read_bytes()
thumb=(strip/'thumbnails.tsv').read_bytes()
assert len(wave.decode().splitlines()[1].split('\t')[7:])==25567
assert len(thumb.decode().splitlines())==23
profile=(run/'window.tsv').read_bytes()
rows=list(csv.DictReader(profile.decode().splitlines(),delimiter='\t'))
assert rows[-1]['program_shown']=='0' and rows[-1]['playing']=='0'
for name,data in [('window-ready.tsv',profile),('waveforms-ready.tsv',wave),('thumbnails-ready.tsv',thumb)]:
    with (run/name).open('xb') as f:f.write(data)
record=dict(passed=True,app_sha256=launch['app_sha256'],worker_sha256=launch['worker_sha256'],
    run=str(run),pid=launch['pid'],window=6753622,project_sha256=launch['project_sha256'],
    original_project_unchanged=True,shell_window=False,source_and_program_nonblank_frame_zero=True,
    playing=False,whole_project_fit=True,frames=76701,processed_peak_cells=25567,mapped_bitmaps=23,
    scopes_histogram_parade_luma_populated=True,
    snapshots_sha256={n:sha(run/n) for n in ('window-ready.tsv','waveforms-ready.tsv','thumbnails-ready.tsv')},
    observed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    complete_professional_editing_acceptance=False)
with (work/'pro-content-stream-final-root-ready.json').open('x') as f:json.dump(record,f,indent=2)
print(json.dumps(record))
