import argparse, subprocess
from pathlib import Path
import numpy as np
p=argparse.ArgumentParser(); p.add_argument('--source',required=True); a=p.parse_args()
root=Path(__file__).resolve().parent
prefix=[r'C:\MM-Air\ffmpeg.exe','-nostdin','-hide_banner','-loglevel','warning','-y']
arrays=[]
for gpu in (False,True):
    argv=list(prefix)
    if gpu: argv+=['-init_hw_device','vulkan=vk:0','-filter_hw_device','vk','-hwaccel','vulkan','-hwaccel_output_format','vulkan']
    chain='libplacebo=w=1280:h=720:format=gbrpf32le:colorspace=gbr:color_primaries=bt709:color_trc=linear:range=full:peak_detect=0:contrast_recovery=0:dithering=none:downscaler=bilinear:extra_opts=color_map=no,hwdownload,format=gbrpf32le' if gpu else 'zscale=w=1280:h=720:transfer=linear:npl=100,format=gbrpf32le,zscale=primaries=bt709'
    output=root/('gpu.linear' if gpu else 'cpu.linear')
    done=subprocess.run(argv+['-i',a.source,'-vf',chain,'-an','-frames:v','1','-f','rawvideo',str(output)],capture_output=True,creationflags=subprocess.CREATE_NO_WINDOW,timeout=30)
    assert done.returncode==0,done.stderr.decode(errors='replace')
    x=np.fromfile(output,dtype='<f4').reshape(3,720,1280).astype(np.float64)
    arrays.append(x)
    print(gpu,'means',x.mean(axis=(1,2)),'max',x.max(axis=(1,2)),'min',x.min(axis=(1,2)),flush=True)
for scale in (1,2.03,100/203,203/100):
    diff=abs(arrays[0]-arrays[1]*scale)
    print('scale',scale,'mean',diff.mean(),'p99',np.percentile(diff,99),'max',diff.max())
