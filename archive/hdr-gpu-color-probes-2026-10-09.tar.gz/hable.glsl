//!HOOK OUTPUT
//!BIND HOOKED
//!DESC Genesis Hable reference probe

float genesis_hable(float x) {
    return (x * (x * 0.15 + 0.05) + 0.004) / (x * (x * 0.15 + 0.50) + 0.06) - 0.02 / 0.30;
}
vec4 hook() {
    vec4 color = HOOKED_texOff(0);
    vec3 rgb = linearize(color).rgb * 2.03;
    rgb = mat3(1.6604910021, -0.1245504745, -0.0181507634,
              -0.5876411388, 1.1328998971, -0.1005788980,
              -0.0728498633, -0.0083494226, 1.1187296614) * rgb;
    float luma = rgb.r + rgb.g + rgb.b;
    float overbright = max(luma - 2.0, 1e-6) / max(luma, 1e-6);
    rgb = mix(rgb, vec3(luma), overbright);
    float signal = max(max(rgb.r, max(rgb.g, rgb.b)), 1e-6);
    rgb *= genesis_hable(signal) / (genesis_hable(10.0) * signal);
    rgb = max(rgb, vec3(0.0));
    vec3 encoded = pow(rgb, vec3(1.0 / 2.4));
    return vec4(clamp(encoded, 0.0, 1.0), color.a);
}
