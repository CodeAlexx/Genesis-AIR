# HDR GPU color probes (2026-10-03; archived 2026-10-09)

Rejected libplacebo OUTPUT hook: first twelve supplied 4K AV1/PQ frames,
1280x720, custom Hable/Rec1886 vs existing zscale/tonemap. Encoded-domain
resampling mean0.9887, p99 11.1556, max102.1051 in 8-bit channel units.
Linear-domain variant mean1.0556,p9914.6498,max133.0467. Neither is enabled.
Native D3D compute results at640x360 include seventeen exact selected frames;
uniform patch precision/overflow gates are maintained in tests/hdr_preview.py.
The native comparison contains spatial resampling differences and is not a
bit-identical preview/master result. Timings include startup and seeks.

Extract this archive into build-windows/gpu-color-probe from repository root.
Use Python with numpy and the MM-AIR existing FFmpeg tool:
python build-windows/gpu-color-probe/compare.py --source LOCAL_CLIP.mp4 --frames 12
python build-windows/gpu-color-probe/native.py --source LOCAL_CLIP.mp4 --worker WORKER.exe
python build-windows/gpu-color-probe/linear.py --source LOCAL_CLIP.mp4
The native source fixture is18808frames,3840x2160,AV1,PQ,59.94fps.
For other inputs edit its selected indices to valid positions.

Sources examined: FFmpeg commit361174e5ea6bd65e34554afa1d098dda2a9bcbba
libavfilter/vf_tonemap.c and vf_zscale.c; libplacebo v7.351.0 shaders
colorspace.c/renderer.c via its official haasn/libplacebo mirror; zimg
colorspace/gamma.cpp. External source blobs, raw pixels, binaries, caches
and local installation paths are omitted. See docs/FFMPEG_GPU_PREVIEW.md.
