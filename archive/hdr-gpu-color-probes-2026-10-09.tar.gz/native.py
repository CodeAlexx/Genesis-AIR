import argparse, json, os, sys, subprocess, time
from pathlib import Path
import numpy as np
from queue import Queue
from threading import Thread
sys.path.insert(0,str(Path(__file__).resolve().parents[2]/'tests'))
from video_transfer import neutral
from preview_fit import wire
p=argparse.ArgumentParser(); p.add_argument('--source',required=True); p.add_argument('--worker',required=True); a=p.parse_args()
root=Path(__file__).resolve().parent
frames=list(range(12))+[100,500,1000,18807,0]
results={}; reference=[]
for gpu in (False,True):
    env=dict(os.environ,GENESIS_MEDIA_PROFILE='1')
    env.pop('GENESIS_GPU_PREVIEW',None)
    if gpu: env['GENESIS_GPU_PREVIEW']='1'
    worker=Path(a.worker).resolve()
    proc=subprocess.Popen([str(worker),'--serve','--size','640','360'],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,encoding='utf-8',env=env,creationflags=subprocess.CREATE_NO_WINDOW)
    replies=Queue(); errors=[]
    def read():
        for line in proc.stdout: replies.put(line.strip())
    def diagnostic(): errors.extend(proc.stderr)
    thread=Thread(target=read); thread.start(); logger=Thread(target=diagnostic); logger.start()
    fields=neutral(); fields[0]=wire(a.source)
    timings=[]; differences=[]
    try:
        for i,frame in enumerate(frames):
            fields[2]=str(frame); output=root/('native-gpu.f32' if gpu else 'native-cpu.f32')
            started=time.perf_counter()
            proc.stdin.write('FLOAT '+' '.join(fields)+' '+wire(output)+'\n'); proc.stdin.flush()
            reply=replies.get(timeout=30)
            assert reply=='DONE '+str(output), (reply, errors[-10:])
            timings.append((time.perf_counter()-started)*1000)
            rgb=np.fromfile(output,dtype='<f4').reshape(360,640,4)[:,:,:3]
            if not gpu: reference.append(rgb)
            else:
                delta=np.abs(reference[i]-rgb)*255
                differences.append({'frame':frame,'mean':float(delta.mean()),'p99':float(np.percentile(delta,99)),'max':float(delta.max())})
    finally:
        proc.stdin.close(); proc.wait(timeout=15); thread.join(); logger.join()
    log=''.join(errors); (root/('native-gpu.log' if gpu else 'native-cpu.log')).write_text(log)
    results[str(gpu)]={'timings_ms':timings,'differences':differences,'gpu_color':log.count('gpu_color_us='),'fallbacks':log.count('GA_GPU_COLOR')}
    print(gpu,results[str(gpu)],flush=True)
(root/'native.json').write_text(json.dumps(results,indent=2))
