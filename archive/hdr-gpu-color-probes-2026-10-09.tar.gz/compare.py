import argparse, json, subprocess, time
from pathlib import Path
import numpy as np

p = argparse.ArgumentParser()
p.add_argument('--source', required=True)
p.add_argument('--tool', default=r'C:\MM-Air\ffmpeg.exe')
p.add_argument('--frames', type=int, default=24)
a = p.parse_args()
root = Path(__file__).resolve().parent
reference = 'zscale=w=1280:h=720:transfer=linear:npl=100,format=gbrpf32le,zscale=primaries=bt709,tonemap=tonemap=hable:desat=2,zscale=transfer=bt709:matrix=gbr:range=full,format=gbrp16le,format=rgba64le'
tail = 'zscale=transfer=linear:npl=100,format=gbrpf32le,zscale=primaries=bt709,tonemap=tonemap=hable:desat=2,zscale=transfer=bt709:matrix=gbr:range=full,format=gbrp16le,format=rgba64le'
chains = {'cpu': (False, reference)}
for linear in (False, True):
    chains[f'shader-{linear}'] = (True, f'libplacebo=w=1280:h=720:format=gbrpf32le:colorspace=gbr:color_primaries=bt2020:color_trc=smpte2084:range=full:peak_detect=0:contrast_recovery=0:dithering=none:upscaler=bilinear:downscaler=triangle:disable_linear={int(not linear)}:extra_opts=color_map=no:custom_shader_path=build-windows/gpu-color-probe/hable.glsl,hwdownload,format=gbrpf32le,format=rgba64le')
results = {}
base = None
for name, (gpu, chain) in chains.items():
    output = root / (name + '.rgba64')
    argv = [a.tool, '-nostdin', '-hide_banner', '-loglevel', 'warning', '-y']
    if gpu:
        argv += ['-init_hw_device', 'vulkan=vk:0', '-filter_hw_device', 'vk', '-hwaccel', 'vulkan', '-hwaccel_output_format', 'vulkan']
    argv += ['-i', a.source, '-vf', chain, '-an', '-frames:v', str(a.frames), '-f', 'rawvideo', str(output)]
    started = time.perf_counter()
    done = subprocess.run(argv, capture_output=True, timeout=90, creationflags=subprocess.CREATE_NO_WINDOW)
    (root / (name + '.log')).write_bytes(done.stderr)
    if done.returncode:
        results[name] = {'error': done.stderr[-1200:].decode(errors='replace')}
    else:
        pixels = np.fromfile(output, dtype='<u2').reshape(-1, 4)[:, :3].astype(np.int32)
        if base is None: base = pixels
        delta = np.abs(pixels - base) * (255 / 65535)
        results[name] = {'seconds': time.perf_counter()-started, 'mean': float(delta.mean()), 'p99': float(np.percentile(delta, 99)), 'max': float(delta.max()), 'channels': pixels.mean(axis=0).tolist()}
    print(name, results[name], flush=True)
(root / 'compare.json').write_text(json.dumps(results, indent=2))
