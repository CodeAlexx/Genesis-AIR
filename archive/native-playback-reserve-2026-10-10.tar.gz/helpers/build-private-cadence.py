"""Fresh private AIR sources with the frozen native runtime and Windows manifest."""
from pathlib import Path
import hashlib,json,re,shutil,subprocess,sys
root=Path(__file__).resolve().parent.parent;work=root/'build-windows'
prefix=sys.argv[1];assert re.fullmatch(r'cadence-[a-z0-9-]+',prefix)
out=work/(prefix+'-generated');out.mkdir()
stage=work/(prefix+'-runtime');stage.mkdir()
old=json.loads((work/'cadence-lock-frozen.json').read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
changed={'src/main.ai','src/picture_queue.ai','tests/picture_queue.ai','tests/picture_clock.ai'}
for n,h in old['source_sha256'].items():
    if n not in changed:assert sha(root/n)==h,n
for n,h in old['sdk_source_sha256'].items():assert sha(work/'AIR-SDK'/n)==h,n
for n,h in old['baseline_payload'].items():assert sha(root/n)==h,n
frozen=dict(old);frozen['source_sha256']={n:sha(root/n) for n in old['source_sha256']}
frozen['reused_runtime_sha256']=sha(work/'cadence-lock-native/runtime/Release/air_rt.lib')
frozen['manifest_sha256']=sha(work/'AIR-SDK/cmake/windows-app.manifest')
with (work/(prefix+'-frozen.json')).open('x') as f:json.dump(frozen,f,indent=2)
for n in changed:
    dest=out/'source'/n;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(root/n,dest)
for p in (work/'cadence-lock-runtime').iterdir():
    if p.is_file():shutil.copyfile(p,stage/p.name)
shutil.copytree(work/'cadence-lock-runtime/fonts',stage/'fonts')
def linux(p):return '/mnt/c/'+str(p.resolve()).replace('\\','/')[3:]
for name,source in [('main','src/main.ai'),('picture-queue','tests/picture_queue.ai'),('picture-clock','tests/picture_clock.ai')]:
    subprocess.run(['wsl.exe','-d','Ubuntu','-u','root','--','env',
      'AIR_STDLIB='+linux(work/'AIR-SDK/stdlib'),'/root/Genesis-AIR-compiler/bin/airc','build',linux(root/source),
      '-o',linux(out/(name+'.c.bootstrap')),'--mode','release','--provider','hash.sha256=portable','--keep-c',linux(out/(name+'.c'))],check=True)
cmake='C:/Program Files (x86)/Microsoft Visual Studio/2022/BuildTools/Common7/IDE/CommonExtensions/Microsoft/CMake/CMake/bin/cmake.exe'
project=work/(prefix+'-project');project.mkdir()
text='''cmake_minimum_required(VERSION 3.24)
project(cadence_experiment LANGUAGES C)
set(CMAKE_MSVC_RUNTIME_LIBRARY MultiThreaded)
set(repo "REPO")
add_library(accepted_air_runtime STATIC IMPORTED)
set_target_properties(accepted_air_runtime PROPERTIES IMPORTED_LOCATION "${repo}/build-windows/cadence-lock-native/runtime/Release/air_rt.lib")
foreach(name main picture-queue picture-clock)
  add_executable(genesis-${name} "${repo}/build-windows/PREFIX-generated/${name}.c")
  target_include_directories(genesis-${name} PRIVATE "${repo}/build-windows/AIR-SDK/runtime")
  target_compile_features(genesis-${name} PRIVATE c_std_11)
  target_compile_options(genesis-${name} PRIVATE /W3 /bigobj)
  target_link_libraries(genesis-${name} PRIVATE accepted_air_runtime user32 gdi32 d2d1 ole32 uiautomationcore shell32 ws2_32 bcrypt advapi32 secur32 crypt32 mf mfplat mfuuid evr strmiids)
endforeach()
target_link_options(genesis-main PRIVATE /SUBSYSTEM:WINDOWS /ENTRY:mainCRTStartup "/MANIFESTINPUT:${repo}/build-windows/AIR-SDK/cmake/windows-app.manifest")
'''.replace('REPO',root.as_posix()).replace('PREFIX',prefix)
(project/'CMakeLists.txt').write_text(text)
native=work/(prefix+'-native')
subprocess.run([cmake,'-S',str(project),'-B',str(native),'-G','Visual Studio 17 2022','-A','x64'],check=True)
subprocess.run([cmake,'--build',str(native),'--config','Release','--','/m'],check=True)
for name in ('picture-queue','picture-clock'):
    subprocess.run([str(native/'Release'/('genesis-'+name+'.exe')),str(work/(prefix+'-'+name+'-tests.json'))],check=True)
shutil.copyfile(native/'Release/genesis-main.exe',stage/'Genesis-AIR.exe')
for n,h in frozen['source_sha256'].items():assert sha(root/n)==h,n
with (work/(prefix+'-build-receipt.json')).open('x') as f:
    json.dump(dict(app_sha256=sha(stage/'Genesis-AIR.exe'),worker_sha256=sha(stage/'genesis-gcompose.exe'),
      generated_sha256={p.name:sha(p) for p in out.glob('*.c')},
      reused_payload_sha256={p.name:sha(p) for p in stage.iterdir() if p.is_file() and p.name!='Genesis-AIR.exe'},
      sources_sha256=frozen['source_sha256'],experimental_private_build=True,
      native_runtime_sha256=frozen['reused_runtime_sha256'],manifest_sha256=frozen['manifest_sha256']),f,indent=2)
(work/(prefix+'-build.exit')).write_text('0')
print('Private build and focused fixtures passed; native performance remains unmeasured.')
