"""Retain the observed failure sequence without inferring its initiating cause."""
from pathlib import Path
import csv, hashlib, json
work=Path(__file__).resolve().parent
failure=json.loads((work/'cadence-reserve-profile-ui-failure.json').read_text())
run=Path(failure['run'])
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
profile=Path(failure['profile'])
assert sha(profile)==failure['profile_sha256']
rows=list(csv.DictReader(profile.open(newline=''),delimiter='\t'))
accepted_index=next(i for i,r in enumerate(rows) if r['window_first_id']=='848')
accepted=rows[accepted_index]
assert accepted['window_last_id']=='849' and accepted['snapshot_generation']=='848'
assert accepted['document_revision']=='2' and accepted['playing']=='1'
paused_index=next(i for i in range(accepted_index+1,len(rows)) if rows[i]['playing']=='0')
paused=rows[paused_index]
events_path=run/'scratch/errors.jsonl'
events=[json.loads(line)['payload'] for line in events_path.read_text().splitlines() if line.strip()]
assert events[0]['attributes']['message']=='[GA_PREVIEW_CHANNEL] Preview task ended unexpectedly'
assert events[1]['attributes']['message']=='[GA_PREVIEW_REQUEST] Cannot publish the preview window'
assert events[1]['timestamp_ms']>events[0]['timestamp_ms']
record=dict(schema='genesis.preview_failure_sequence.v1', app_sha256=failure['app_sha256'],
    worker_sha256=failure['worker_sha256'], profile=str(profile), profile_sha256=sha(profile),
    accepted=dict(zero_based_row=accepted_index, first_id=848,last_id=849,
        snapshot=848,document_revision=2,audio_origin=int(accepted['audio_origin']),
        completed_packets=int(accepted['completed_packets'])),
    first_paused=dict(zero_based_row=paused_index,
        elapsed_seconds=(int(paused['loop_begin_ns'])-int(accepted['loop_begin_ns']))/1e9,
        completed_packets=int(paused['completed_packets'])),
    events_sha256=sha(events_path), events=events, initiating_exit_reason_known=False,
    conclusions=['New gain request was accepted before producer closure',
                 'Generic retry error replaced the earlier producer-closure message'],
    transport_timeout_hypothesis_proven=False,published=False)
with (work/'cadence-reserve-profile-diagnosis.json').open('x') as f: json.dump(record,f,indent=2)
print(json.dumps({k:record[k] for k in ('accepted','first_paused','initiating_exit_reason_known')}))
