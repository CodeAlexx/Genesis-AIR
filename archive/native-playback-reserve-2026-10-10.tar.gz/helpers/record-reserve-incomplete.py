from pathlib import Path
import hashlib,json
work=Path(__file__).resolve().parent
run=work/'cadence-reserve-4k-f628eba6cd754cf9ba7ccec51bd94f9f'
profile=(run/'window-final.tsv').read_bytes()
record=dict(schema='genesis.native.incomplete_measurement.v1',app_sha256=json.loads((run/'launch.json').read_text())['app_sha256'],
    profile_sha256=hashlib.sha256(profile).hexdigest(),profile_rows=len(profile.splitlines())-1,
    qualified=False,reason='Fixed50000rowlimit reached before observed Stop boundary; unchanged analyzer refuses',
    observed_ui=['Stop3:47:34 silent output','Start0 nonblank','Ownedprivatewindow closed'],
    limitations=['No qualifiedcadence claim; repeat same frozenbinary with earlierStop required'])
with (run/'incomplete.json').open('x') as f:json.dump(record,f,indent=2)
print('Incomplete measurement retained without a passing timing receipt')
