"""Freeze the current published payload identity and launch a private 4K baseline."""
from pathlib import Path
import hashlib,json,os,shutil,subprocess,uuid,datetime
root=Path(__file__).resolve().parent.parent
work=root/'build-windows'
def sha(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(1048576),b''):h.update(b)
    return h.hexdigest()
publication=json.loads((work/'pro-content-stream-final-publication.json').read_text())
for n,h in publication['root_binaries'].items():assert sha(root/n)==h,n
original=root/'Costa Rica 4K.air'
assert sha(original)=='480d82e310ba6f231fab2c0c0db9945dab193d63073cb63fe053019a13aeb143'
source=Path(json.loads(original.read_text())['sources'][0]['path'])
assert sha(source)=='bff7165e6704e7188fee82b990e5128fe87c3ce9c5ef7eeb85bd1bb0da42c6da'
run=work/('pro-4k-current-baseline-'+uuid.uuid4().hex);run.mkdir()
project=run/'private-costa.air';shutil.copyfile(original,project)
env=dict(os.environ,GENESIS_GCOMPOSE=str(root/'genesis-gcompose.exe'),GENESIS_SCRATCH=str(run/'scratch'),
    GENESIS_SESSION_REPORT=str(run/'session-report.txt'),GENESIS_WINDOW_PROFILE=str(run/'window.tsv'),GENESIS_TAB='audio')
env.pop('GENESIS_FAKE_PROVIDER',None)
child=subprocess.Popen([str(root/'Genesis-AIR.exe'),'open',str(project)],cwd=root,env=env,creationflags=subprocess.CREATE_NO_WINDOW)
receipt=dict(pid=child.pid,app=str(root/'Genesis-AIR.exe'),worker=str(root/'genesis-gcompose.exe'),
    app_sha256=publication['root_binaries']['Genesis-AIR.exe'],worker_sha256=publication['root_binaries']['genesis-gcompose.exe'],
    source_sha256=sha(source),project_sha256=sha(project),original_project_sha256=sha(original),
    project=str(project),source=str(source),original_project=str(original),scratch=str(run/'scratch'),
    authored_duration_seconds=18808/(60000/1001),authored_video_frames=18808,
    launched_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    scope='Published C6D2/AA40 private ordinary editor; fitted 480x270 AV1 PQ 59.94fps; no fullscreen4K')
with (run/'launch.json').open('x') as f:json.dump(receipt,f,indent=2)
print(json.dumps(dict(run=str(run),**receipt)))
