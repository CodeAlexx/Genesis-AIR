"""Prepare a coherent full build only after the exact private native cadence gate."""
from pathlib import Path
import hashlib,json,shutil,sys
root=Path(__file__).resolve().parent.parent;work=root/'build-windows'
run=Path(sys.argv[1]);prefix='cadence-primed-final'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
analysis=json.loads((run/'analysis.json').read_text())
private=json.loads((work/'cadence-primed-build-receipt.json').read_text())
frozen=json.loads((work/'cadence-primed-frozen.json').read_text())
assert analysis['passed_clock_queue_invariants'] and not analysis['errors']
assert analysis['app_sha256']==private['app_sha256']
assert analysis['worker_sha256']==private['worker_sha256']
assert analysis['raw_profile_sha256']==sha(run/'window-final.tsv')
assert analysis['launch_sha256']==sha(run/'launch.json')
for n,h in frozen['source_sha256'].items():assert sha(root/n)==h,n
for n,h in frozen['sdk_source_sha256'].items():assert sha(work/'AIR-SDK'/n)==h,n
for n,h in frozen['baseline_payload'].items():assert sha(root/n)==h,n
stage=work/(prefix+'-runtime');stage.mkdir()
for p in (work/'cadence-primed-runtime').iterdir():
    if p.is_file():shutil.copyfile(p,stage/p.name)
shutil.copytree(work/'cadence-primed-runtime/fonts',stage/'fonts')
frozen['qualified_private_cadence']=dict(run=str(run),analysis_sha256=sha(run/'analysis.json'),
    app_sha256=analysis['app_sha256'],worker_sha256=analysis['worker_sha256'])
with (work/(prefix+'-frozen.json')).open('x') as f:json.dump(frozen,f,indent=2)
print('Full build stage prepared; no root payload modified.')
