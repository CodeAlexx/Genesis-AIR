"""Launch only an exact fresh private candidate, leaving user projects untouched."""
from pathlib import Path
import hashlib,json,os,shutil,subprocess,uuid,datetime,sys
root=Path(__file__).resolve().parent.parent
work=root/'build-windows'
stage=work/'cadence-primed-runtime'
native=work/'cadence-primed-native/Release'
def sha(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(1048576),b''):h.update(b)
    return h.hexdigest()
frozen=json.loads((work/'cadence-primed-frozen.json').read_text())
for n,h in frozen['source_sha256'].items():assert sha(root/n)==h,n
for n,h in frozen['baseline_payload'].items():assert sha(root/n)==h,('Published root changed',n)
assert sha(stage/'Genesis-AIR.exe')==sha(native/'genesis-main.exe')
for n in ('air-native-shell.dll','air-native-dialogs.dll','air-ui-host.dll','genesis-native-audio.dll'):
    assert sha(stage/n)==sha(work/'cadence-lock-runtime'/n),n
assert sha(stage/'genesis-gcompose.exe')==frozen['baseline_payload']['genesis-gcompose.exe']
assert sha(stage/'genesis-media-runtime.txt')==frozen['runtime_sha256']
assert (work/'cadence-primed-build.exit').read_text().strip()=='0'
mode=sys.argv[1] if len(sys.argv)>1 else '4k'
assert mode in ('4k','editing')
if mode=='4k':
    original=root/'Costa Rica 4K.air'
    expected='480d82e310ba6f231fab2c0c0db9945dab193d63073cb63fe053019a13aeb143'
else:
    original=work/'pro-content-stream-final-ui-26b6225d01df4c4dbfc108be26cf5174/private-project.air'
    expected=json.loads((work/'pro-content-stream-final-ui.json').read_text())['private_project_saved_sha256']
assert sha(original)==expected
source=Path(json.loads(original.read_text())['sources'][0]['path'])
source_hash=sha(source)
assert source_hash==('bff7165e6704e7188fee82b990e5128fe87c3ce9c5ef7eeb85bd1bb0da42c6da' if mode=='4k' else
    '061d76990215c31e6dc58d22f4ecd09ac92d414fdc73061e8dfcb502cee3f11d')
run=work/('cadence-primed-'+mode+'-'+uuid.uuid4().hex);run.mkdir()
project=run/'private-project.air';shutil.copyfile(original,project)
env=dict(os.environ,GENESIS_GCOMPOSE=str(stage/'genesis-gcompose.exe'),GENESIS_SCRATCH=str(run/'scratch'),
    GENESIS_SESSION_REPORT=str(run/'session-report.txt'),GENESIS_WINDOW_PROFILE=str(run/'window.tsv'),GENESIS_TAB='audio')
env.pop('GENESIS_FAKE_PROVIDER',None)
child=subprocess.Popen([str(stage/'Genesis-AIR.exe'),'open',str(project)],cwd=root,env=env,creationflags=subprocess.CREATE_NO_WINDOW)
receipt=dict(pid=child.pid,app=str(stage/'Genesis-AIR.exe'),worker=str(stage/'genesis-gcompose.exe'),
    app_sha256=sha(stage/'Genesis-AIR.exe'),worker_sha256=sha(stage/'genesis-gcompose.exe'),
    source_sha256=source_hash,project_sha256=sha(project),original_project_sha256=expected,
    project=str(project),source=str(source),original_project=str(original),scratch=str(run/'scratch'),
    launched_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    scope='Private cadence/locked-track candidate, ordinary editor; fitted480x270 monitors; no fullscreen4K')
with (run/'launch.json').open('x') as f:json.dump(receipt,f,indent=2)
print(json.dumps(dict(run=str(run),**receipt)))

