"""Verify fixed window/queue bounds separately from the unchanged cadence gate."""
from pathlib import Path
import csv,hashlib,json,sys
run=Path(sys.argv[1]);raw=(run/'window-final.tsv').read_bytes()
rows=list(csv.DictReader(raw.decode('utf-8-sig').splitlines(),delimiter='\t'))
assert all(all(v not in ('',None) for v in r.values()) for r in rows)
windows=[r for r in rows if int(r['window_count'])]
errors=[]
for i,r in enumerate(rows):
    owned=int(r['owned_picture_credit']);reserved=int(r['reserved_picture_credit'])
    if owned<0 or reserved<0 or owned+reserved>8:errors.append([i,'Total credit exceeds eight'])
    count=int(r['window_count'])
    if count:
        if count not in (1,2):errors.append([i,'Producer count exceeds two'])
        if int(r['window_last_id'])-int(r['window_first_id'])+1!=count:errors.append([i,'ID window mismatch'])
        if int(r['window_last_frame'])-int(r['window_first_frame'])+1!=count:errors.append([i,'Position window mismatch'])
    if int(r['overwritten_packets']):errors.append([i,'Validated completion overwritten'])
record=dict(schema='genesis.native.window_credit.v1',profile_sha256=hashlib.sha256(raw).hexdigest(),
    launch_sha256=hashlib.sha256((run/'launch.json').read_bytes()).hexdigest(),
    rows=len(rows),windows=len(windows),count_one=sum(int(r['window_count'])==1 for r in windows),
    count_two=sum(int(r['window_count'])==2 for r in windows),
    max_owned=max(int(r['owned_picture_credit']) for r in rows),
    max_reserved=max(int(r['reserved_picture_credit']) for r in rows),
    max_total=max(int(r['owned_picture_credit'])+int(r['reserved_picture_credit']) for r in rows),
    owned_six_reserved_two_rows=sum(int(r["owned_picture_credit"])==6 and int(r["reserved_picture_credit"])==2 for r in rows),
    owned_one_reserved_two_rows=sum(int(r['owned_picture_credit'])==1 and int(r['reserved_picture_credit'])==2 for r in rows),
    errors=errors,passed=not errors,
    limitations=['Credit/packet invariants do not establish smooth playback; separate unchanged cadence gate required'])
with (run/'window-credit.json').open('x') as f:json.dump(record,f,indent=2)
print(json.dumps(record,indent=2))
