from pathlib import Path
import hashlib,json,os,subprocess,datetime
root=Path(__file__).resolve().parent.parent
work=root/'build-windows'
run=work/'cadence-reserve-gain-export-5349bb724c324fe1b57ff418922378a4'
stage=work/'cadence-reserve-gain-runtime'
assert (work/'cadence-reserve-gain-windows.exit').read_text().strip()=='0'
assert not (run/'launch.json').exists()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
app=stage/'Genesis-AIR.exe';worker=stage/'genesis-gcompose.exe';project=run/'cancel-range.air'
assert sha(app)=='1a49b8af32b9a9169dfcdebb78d4f523bf742c4c34a006f90551c2b8251eb4b6'
assert sha(worker)=='aa40b96c631c82cfc834d027678e95a00bd8d5f61db54f15e7c7ecefcf74228c'
fixture=json.loads((run/'fixture.json').read_text())
assert sha(Path(fixture['original']))==fixture['original_sha256']
for name,v in fixture['copies'].items():assert sha(run/name)==v['sha256']
env=dict(os.environ,GENESIS_GCOMPOSE=str(worker),GENESIS_SCRATCH=str(run/'scratch'),GENESIS_SESSION_REPORT=str(run/'session-report.txt'),GENESIS_WINDOW_PROFILE=str(run/'window.tsv'),GENESIS_TAB='properties')
env.pop('GENESIS_FAKE_PROVIDER',None)
child=subprocess.Popen([str(app),'open',str(project)],cwd=root,env=env,creationflags=subprocess.CREATE_NO_WINDOW)
record=dict(pid=child.pid,app=str(app),worker=str(worker),app_sha256=sha(app),worker_sha256=sha(worker),project=str(project),project_sha256=sha(project),fixture_sha256=sha(run/'fixture.json'),scratch=str(run/'scratch'),session_report=str(run/'session-report.txt'),window_profile=str(run/'window.tsv'),launched_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),shell_window=False,scope='Owned large authored graph, native cancel240/retry12 workflow; no cadence claim')
with (run/'launch.json').open('x') as f:json.dump(record,f,indent=2)
print(json.dumps(dict(run=str(run),**record)))
