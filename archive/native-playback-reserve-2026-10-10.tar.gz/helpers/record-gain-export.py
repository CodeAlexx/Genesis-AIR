from pathlib import Path
import hashlib,json,shutil
root=Path(__file__).resolve().parent.parent;work=root/'build-windows';run=work/'cadence-reserve-gain-export-5349bb724c324fe1b57ff418922378a4'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
launch=json.loads((run/'launch.json').read_text());fixture=json.loads((run/'fixture.json').read_text());oracle=json.loads((run/'audible-export-oracle.json').read_text())
assert oracle['passed'] and (run/'audible-export-oracle.exit').read_text().strip()=='0'
assert sha(Path(fixture['original']))==fixture['original_sha256']
assert sha(run/'cancel-range.air')==fixture['copies']['cancel-range.air']['sha256']
saved=run/'audible-retry.air';assert sha(saved)==fixture['original_sha256']
assert json.loads(saved.read_text())==json.loads(Path(fixture['original']).read_text())
assert sha(run/'retry-audible.mp4')==oracle['hashes_after']['movie']
assert not list(run.glob('cancel-attempt*')) and not list(run.rglob('*genesis-air-part*'))
assert not [p for p in (run/'scratch').rglob('*') if p.is_file() and ('cancel' in p.name or 'export' in p.name)]
children=json.loads((run/'cancel-children.json').read_text(encoding='utf-8-sig'))
assert [c['ProcessId'] for c in children]==[8356] and all(c['ProcessId']!=42856 for c in children)
errors=run/'scratch/errors.jsonl';assert not errors.exists() or not errors.read_text().strip()
assert all(not p.read_text().strip() for p in (run/'scratch').rglob('producer-failure.tsv'))
trace=run/'window-final.tsv';assert not trace.exists();shutil.copyfile(run/'window.tsv',trace)
record=dict(schema='genesis.cadence_reserve.native_export.v1',passed=True,run=str(run),pid=33544,window=6294816,app_sha256=launch['app_sha256'],worker_sha256=launch['worker_sha256'],launch_sha256=sha(run/'launch.json'),fixture_sha256=sha(run/'fixture.json'),profile_sha256=sha(trace),observed=dict(cancel_exclusive_range=[0,240],observed_progress_percent=29,cancel_acknowledged=True,cancel_completed=True,encoder_pid=42856,encoder_exited=True,preview_pid_retained=8356,no_final_partial_or_signals=True,retry_exclusive_range=[0,12],native_retry_completed=True,native_save_and_reopen=True,reopened_preview_title='PRIVATE EDIT CONFIRMED',reopened_source_and_program_nonblank=True),authored_graph_exactly_preserved=True,saved_project_sha256=sha(saved),original_unchanged=True,oracle_sha256=sha(run/'audible-export-oracle.json'),movie_sha256=sha(run/'retry-audible.mp4'),independent_video_frames=12,audio=oracle['audio'],limitations=['Bounded 240-frame cancel and 12-frame retry, not whole-project export performance','Independent title interior and background scalar checks retain fixed thresholds','No full professional editing acceptance or physical timing claim'])
with (work/'cadence-reserve-gain-export.json').open('x') as f:json.dump(record,f,indent=2)
print(json.dumps({'passed':True,'graph_preserved':True,'aac_correlation':record['audio']['zero_sample_shift_correlation']}))
