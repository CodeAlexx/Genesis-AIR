from pathlib import Path
import hashlib,json,shutil,subprocess
root=Path(__file__).resolve().parent.parent;work=root/'build-windows';prefix='cadence-reversal'
stage=work/(prefix+'-runtime');native=work/(prefix+'-native/Release');out=work/(prefix+'-generated')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
frozen=json.loads((work/(prefix+'-frozen.json')).read_text())
for n,h in frozen['source_sha256'].items():assert sha(root/n)==h,n
for n,h in frozen['sdk_source_sha256'].items():assert sha(work/'AIR-SDK'/n)==h,n
assert sha(work/'cadence-lock-native/runtime/Release/air_rt.lib')==frozen['reuse_native_runtime_sha256']
subprocess.run([str(native/'genesis-picture-queue.exe'),str(work/(prefix+'-picture-queue-tests.json'))],check=True)
shutil.copyfile(native/'genesis-main.exe',stage/'Genesis-AIR.exe')
with (work/(prefix+'-build-receipt.json')).open('x') as f:
    json.dump(dict(app_sha256=sha(stage/'Genesis-AIR.exe'),worker_sha256=sha(stage/'genesis-gcompose.exe'),
      generated_sha256={p.name:sha(p) for p in out.glob('*.c')},
      reused_payload_sha256={p.name:sha(p) for p in stage.iterdir() if p.is_file() and p.name!='Genesis-AIR.exe'},
      sources_sha256=frozen['source_sha256'],experimental_private_build=True,
      initial_attempt_failed_missing_c11=True,rebuild_log_sha256=sha(work/(prefix+'-build-attempt2.log'))),f,indent=2)
(work/(prefix+'-build.exit')).write_text('0')
print('Private reversal app and queue fixture passed; failed build attempt preserved.')
