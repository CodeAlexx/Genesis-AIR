from pathlib import Path
import json,hashlib
root=Path(__file__).resolve().parent.parent;work=root/'build-windows'
run=work/'cadence-reserve-gain-4k-26e2f631424046ddb7d5defae801c431'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
a=json.loads((run/'analysis.json').read_text());c=json.loads((run/'window-credit.json').read_text());l=json.loads((run/'launch.json').read_text())
assert a['epoch']['wall_seconds']>=110 and a['passed_clock_queue_invariants'] and c['passed']
b=a['steady_manual_stop_body'];assert b['skipped_frame_positions']==b['backwards_picture_jumps']==b['early_picture_presentations']==b['clock_queue_zero_all_selected_rows']==b['overwritten_packet_delta']==0
assert b['maximum_frame_jump']==1 and b['program_lag_after_present_frames']['maximum']<=2
assert sha(Path(l['original_project']))==l['original_project_sha256']==sha(run/'private-project.air')
assert sha(Path(l['source']))==l['source_sha256']
assert all(not p.read_text().strip() for p in (run/'scratch').rglob('producer-failure.tsv'))
errors=run/'scratch/errors.jsonl';assert not errors.exists() or not errors.read_text().strip()
record=dict(schema='genesis.cadence_reserve.final.v1',run=str(run),analysis_sha256=sha(run/'analysis.json'),credit_sha256=sha(run/'window-credit.json'),observed=dict(window=28380498,pid=l['pid'],fit_timeline=True,play_stereo_at=['00:00:53:14','00:01:45:12','00:02:09:48'],stop='00:02:13:32 paused, silent meters, nonblank held frame',start='00:00:00:00 both monitors nonblank',owned_window_closed_verified=True,original_project_unchanged=True,no_fullscreen=True))
with (work/'cadence-reserve-gain-cadence.json').open('x') as f:json.dump(record,f,indent=2)
print(json.dumps({'passed':True,'steady_pictures_per_second':b['pictures_per_second'],'steady_seconds':b['changed_picture_interval_seconds'],'raw_seconds':a['epoch']['wall_seconds']}))
