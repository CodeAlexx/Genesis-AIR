from pathlib import Path
import hashlib,json,shutil,subprocess,datetime
root=Path(__file__).resolve().parent.parent
work=root/'build-windows'
stage=work/'cadence-lock-runtime'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
publication=json.loads((work/'pro-content-stream-final-publication.json').read_text())
assert not stage.exists(),'Keep existing candidate intact'
for n,h in publication['root_binaries'].items():assert sha(root/n)==h,n
assert sha(root/'genesis-media-runtime.txt')==publication['runtime_sha256']
expected={'src/main.ai':'c96606cc746fe3a69a09ad0c0b3a3086d227bba5d42c6a2fdc01605cdd24c41c',
    'src/picture_queue.ai':'ea73ef32a7f09e8806f08b0fa6067e1178e7cce22647d5bdfaf64c1c98009f20',
    'tests/picture_clock.ai':'40e05dd2ba3e64857816bc25e438ab0dbeb830ba50e1446f2d02f8ef0b01bbf8',
    'tests/picture_queue.ai':'b739beeb882c8ad9d4001bcccc6e800a4b7b10b898068c2a26a732b11ac362b4',
    'patches/air-editor.patch':'befc9cc150d82dcc69e07627e2167b1e20c2f8913ee250210a4caf ecc9fc80ac'.replace(' ',''),
    'src/commands.ai':'0aadd9453af89a3f7c763c867b46bc92f0663770085c01b46f15ab01f79fc7c5',
    'tests/editing_safety.ai':'c9fd690ff8db1f1ab0de337077d621551bc6953545f27963b695c97ef9a2e031'}
for n,h in expected.items():assert sha(root/n)==h,n
sdk=work/'AIR-SDK'
for n in ('air-editor.patch','air-process-wait-windows.patch','air-ui-text-windows.patch'):
    subprocess.run(['git','apply','--reverse','--check',str(root/'patches'/n)],cwd=sdk,check=True)
for folder,key in ((sdk,'sdk_pin'),(work/'gcompose-source','worker_pin')):
    assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=folder,text=True).strip()==publication[key]
old=json.loads((work/'pro-content-stream-final-frozen.json').read_text())
for n,h in old['worker_source_sha256'].items():assert sha(work/'gcompose-source/gcompose'/n)==h,n
for n,h in old['sdk_source_sha256'].items():
    if n!='stdlib/editor.ai':assert sha(sdk/n)==h,n
stage.mkdir()
for n in publication['root_binaries']:shutil.copyfile(root/n,stage/n)
shutil.copyfile(root/'genesis-media-runtime.txt',stage/'genesis-media-runtime.txt')
names=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard'],cwd=root,text=True).splitlines()
source={n:sha(root/n) for n in sorted(set(names)) if (root/n).is_file() and
    (n.startswith(('src/','tests/','windows/','patches/')) or n in ('build-windows.ps1','build-linux.sh'))}
record=dict(schema='genesis.cadence_lock.frozen.v1',source_sha256=source,
    sdk_source_sha256={n:sha(sdk/n) for n in old['sdk_source_sha256']},
    worker_source_sha256=old['worker_source_sha256'],baseline_payload=publication['root_binaries'],
    runtime_sha256=publication['runtime_sha256'],sdk_pin=publication['sdk_pin'],worker_pin=publication['worker_pin'],
    captured_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
with (work/'cadence-lock-frozen.json').open('x') as f:json.dump(record,f,indent=2)
print('Exact agent freezes, maintained code, SDK overlays and unchanged worker frozen; private candidate prepared.')
