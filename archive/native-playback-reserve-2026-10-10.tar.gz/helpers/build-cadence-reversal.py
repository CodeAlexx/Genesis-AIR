"""Private one-variable AIR/MSVC timing experiment; preserve earlier attempts."""
from pathlib import Path
import hashlib,json,shutil,subprocess
root=Path(__file__).resolve().parent.parent
work=root/'build-windows'
prefix='cadence-reversal'
out=work/(prefix+'-generated');out.mkdir()
stage=work/(prefix+'-runtime');stage.mkdir()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
old=json.loads((work/'cadence-lock-frozen.json').read_text())
for n,h in old['source_sha256'].items():
    if n not in ('src/picture_queue.ai','tests/picture_queue.ai'):assert sha(root/n)==h,n
assert sha(root/'src/picture_queue.ai')=='69df44019a52aa1265eff4f63705f1832f1963a9bbff4c586ce029059b137d3b'
assert sha(root/'tests/picture_queue.ai')=='877e8f8ded7a46e2f8cfff21a07dee753506d2d13e693de17ea365d574a13074'
for n,h in old['sdk_source_sha256'].items():assert sha(work/'AIR-SDK'/n)==h,n
frozen=dict(old)
frozen['source_sha256']={n:sha(root/n) for n in old['source_sha256']}
frozen['reuse_native_runtime_sha256']=sha(work/'cadence-lock-native/runtime/Release/air_rt.lib')
frozen['experiment']='Only picture_queue request policy and its fixture differ from DF78; main/SDK/worker/native DLLs unchanged'
with (work/(prefix+'-frozen.json')).open('x') as f:json.dump(frozen,f,indent=2)
for p in (work/'cadence-lock-runtime').iterdir():
    if p.is_file():shutil.copyfile(p,stage/p.name)
shutil.copytree(work/'cadence-lock-runtime/fonts',stage/'fonts')
def linux(p):return '/mnt/c/'+str(p.resolve()).replace('\\','/')[3:]
for name,source in [('main','src/main.ai'),('picture-queue','tests/picture_queue.ai')]:
    subprocess.run(['wsl.exe','-d','Ubuntu','-u','root','--','env',
      'AIR_STDLIB='+linux(work/'AIR-SDK/stdlib'),'/root/Genesis-AIR-compiler/bin/airc','build',linux(root/source),
      '-o',linux(out/(name+'.c.bootstrap')),'--mode','release','--provider','hash.sha256=portable','--keep-c',linux(out/(name+'.c'))],check=True)
cmake='C:/Program Files (x86)/Microsoft Visual Studio/2022/BuildTools/Common7/IDE/CommonExtensions/Microsoft/CMake/CMake/bin/cmake.exe'
project=work/(prefix+'-project');project.mkdir()
text='''cmake_minimum_required(VERSION 3.24)
project(cadence_reversal LANGUAGES C)
set(CMAKE_MSVC_RUNTIME_LIBRARY MultiThreaded)
set(repo "REPO")
add_library(accepted_air_runtime STATIC IMPORTED)
set_target_properties(accepted_air_runtime PROPERTIES IMPORTED_LOCATION "${repo}/build-windows/cadence-lock-native/runtime/Release/air_rt.lib")
foreach(name main picture-queue)
  add_executable(genesis-${name} "${repo}/build-windows/cadence-reversal-generated/${name}.c")
  target_include_directories(genesis-${name} PRIVATE "${repo}/build-windows/AIR-SDK/runtime")
  target_compile_options(genesis-${name} PRIVATE /O2 /bigobj)
  target_link_libraries(genesis-${name} PRIVATE accepted_air_runtime user32 gdi32 d2d1 ole32 uiautomationcore shell32 ws2_32 bcrypt advapi32 secur32 crypt32 mf mfplat mfuuid evr strmiids)
endforeach()
'''.replace('REPO',root.as_posix())
(project/'CMakeLists.txt').write_text(text)
native=work/(prefix+'-native')
subprocess.run([cmake,'-S',str(project),'-B',str(native),'-G','Visual Studio 17 2022','-A','x64'],check=True)
subprocess.run([cmake,'--build',str(native),'--config','Release','--','/m'],check=True)
subprocess.run([str(native/'Release/genesis-picture-queue.exe'),str(work/(prefix+'-picture-queue-tests.json'))],check=True)
shutil.copyfile(native/'Release/genesis-main.exe',stage/'Genesis-AIR.exe')
for n,h in frozen['source_sha256'].items():assert sha(root/n)==h,n
with (work/(prefix+'-build-receipt.json')).open('x') as f:
    json.dump(dict(app_sha256=sha(stage/'Genesis-AIR.exe'),worker_sha256=sha(stage/'genesis-gcompose.exe'),
      generated_sha256={p.name:sha(p) for p in out.glob('*.c')},
      reused_payload_sha256={p.name:sha(p) for p in stage.iterdir() if p.is_file() and p.name!='Genesis-AIR.exe'},
      sources_sha256=frozen['source_sha256'],experimental_private_build=True),f,indent=2)
(work/(prefix+'-build.exit')).write_text('0')
print('Private reversal build and queue fixture passed; native performance remains unmeasured.')
