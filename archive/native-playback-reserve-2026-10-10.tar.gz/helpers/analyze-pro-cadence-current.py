"""Unchanged first-epoch measurement and fixed device-time exclusions."""
from pathlib import Path
import csv,hashlib,importlib.util,json,sys
root=Path(__file__).resolve().parent.parent
helper=root/'build-windows/agent-playback-viewport-hdr-handoff/analyze-native-firstepoch.py'
spec=importlib.util.spec_from_file_location('native_measure',helper)
native=importlib.util.module_from_spec(spec);spec.loader.exec_module(native)
run=Path(sys.argv[1]);launch=json.loads((run/'launch.json').read_text())
raw=(run/'window-final.tsv').read_bytes()
rows=[];incomplete=0
for values in csv.DictReader(raw.decode('utf-8-sig').splitlines(),delimiter='\t'):
    if any(v in (None,'') for v in values.values()):incomplete+=1;continue
    rows.append({k:float(v) if k=='fps' else int(v) for k,v in values.items()})
start=next(i for i,r in enumerate(rows) if r['playing']);end=start
while end<len(rows) and rows[end]['playing']:end+=1
assert end<len(rows),'No observed terminal playback boundary'
epoch=rows[start:end]
stop=max(r['samples_after'] for r in epoch if r['clock_ok']);cutoff=stop-24000
steady=[r for r in epoch if r['clock_ok'] and r['samples_before']>=48000 and r['samples_after']<cutoff]
full=native.measure(epoch);body=native.measure(steady)
body.update(exclusion='Device first1.0s and final0.5s before observed manualStop excluded; full raw epoch retained',
    exact_selection=f'clock_ok and samples_before >= 48000 and samples_after < {cutoff}',
    manual_stop_device_seconds=stop/48000,
    clock_queue_zero_all_selected_rows=sum(r['queued_before']==0 or r['queued_after']==0 for r in steady))
errors=[]
if full['backwards_picture_jumps']:errors.append('Backwards presented frame')
if body['early_picture_presentations']:errors.append('Steady early picture')
if body['stale_picture_presentations_over_two_frames']:errors.append('Steady lag exceeds twoframes')
if body['clock_queue_zero_all_selected_rows']:errors.append('Steady device queue drain')
record=dict(schema='genesis.pro.native_cadence.v2',
    app_sha256=launch['app_sha256'],worker_sha256=launch['worker_sha256'],
    source_sha256=launch['source_sha256'],project_sha256=launch['project_sha256'],scope=launch['scope'],
    launch_sha256=hashlib.sha256((run/'launch.json').read_bytes()).hexdigest(),
    raw_profile_sha256=hashlib.sha256(raw).hexdigest(),profile_rows=len(rows),incomplete_rows=incomplete,
    epoch=dict(first_row=start,end_row_exclusive=end,wall_seconds=(epoch[-1]['loop_end_ns']-epoch[0]['loop_begin_ns'])/1e9,
        values={k:sorted({r[k] for r in epoch}) for k in
            ('audio_origin','fps','source_mode','document_revision','media_revision','width','height','snapshot_generation')},
        audio_cache_rebuild_delta=epoch[-1]['audio_cache_rebuilds']-epoch[0]['audio_cache_rebuilds'],
        strip_request_delta=epoch[-1]['strip_requests']-epoch[0]['strip_requests']),
    raw_full_first_epoch=full,steady_manual_stop_body=body,errors=errors,passed_clock_queue_invariants=not errors,
    limitations=['ManualStop is not authoredEOF or whole5minute playback',
        'No compound4K60 or fullprofessional editing acceptance',
        'Frame positions are app metadata, not an independent pixel oracle for each delivered picture',
        'EndDraw/audio observations do not prove physical speaker/photon synchronization',
        'Raw skips remain retained; steady exclusions do not establish zero-drop playback'],
    analyzer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    shared_measure_helper_sha256=hashlib.sha256(helper.read_bytes()).hexdigest())
with (run/'analysis.json').open('x') as out:json.dump(record,out,indent=2)
print(json.dumps({'epoch':record['epoch'],'steady':body,'errors':errors},indent=2))
