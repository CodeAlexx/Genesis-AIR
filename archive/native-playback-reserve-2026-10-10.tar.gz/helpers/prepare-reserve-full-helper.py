"""Create a full-build guard without weakening the unchanged private timing gate."""
from pathlib import Path
work=Path(__file__).resolve().parent
source=(work/'prepare-cadence-full.py').read_text().replace('cadence-primed','cadence-reserve')
with (work/'prepare-reserve-full.py').open('x') as f:f.write(source)
print('Full-build helper prepared; private native timing PASS remains required')
