"""Exclusive larger actual-reserve experiment; retain the three-credit failure."""
from pathlib import Path
work=Path(__file__).resolve().parent
launch=(work/'launch-cadence-window.py').read_text().replace('cadence-window','cadence-reserve')
with (work/'launch-cadence-reserve.py').open('x') as f:f.write(launch)
credit=(work/'analyze-window-credit.py').read_text().replace('owned+reserved>3','owned+reserved>8').replace('Total credit exceeds three','Total credit exceeds eight')
credit=credit.replace('owned_one_reserved_two_rows=', 'owned_six_reserved_two_rows=sum(int(r["owned_picture_credit"])==6 and int(r["reserved_picture_credit"])==2 for r in rows),\n    owned_one_reserved_two_rows=')
with (work/'analyze-reserve-credit.py').open('x') as f:f.write(credit)
print('Exclusive reserve launcher and credit measurement prepared')
