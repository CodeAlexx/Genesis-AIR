"""Freeze gain-edit recovery separately; retain the previous failed native run."""
from pathlib import Path
import hashlib, json, shutil
root = Path(__file__).resolve().parent.parent
work = root / 'build-windows'
prefix = 'cadence-reserve-gain'
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
old = json.loads((work / 'cadence-reserve-profile-frozen.json').read_text())
allowed = {'src/main.ai', 'src/preview.ai', 'src/preview_link.ai', 'tests/preview_batch.ai'}
for n,h in old['source_sha256'].items():
    if n not in allowed: assert sha(root/n) == h, n
for n,h in old['sdk_source_sha256'].items(): assert sha(work/'AIR-SDK'/n) == h, n
for n,h in old['baseline_payload'].items(): assert sha(root/n) == h, n
assert (work/'cadence-reserve-profile-build.exit').read_text().strip() == '0'
assert (work/'cadence-reserve-profile-windows.exit').read_text().strip() == '0'
failed = json.loads((work/'cadence-reserve-profile-ui-failure.json').read_text())
assert not failed['passed'] and not failed['published']
assert sha(Path(failed['profile'])) == failed['profile_sha256']
frozen = dict(old)
frozen['source_sha256'] = {n:sha(root/n) for n in set(old['source_sha256'])|allowed}
frozen['retained_prior_native_failure'] = dict(
    receipt='build-windows/cadence-reserve-profile-ui-failure.json',
    receipt_sha256=sha(work/'cadence-reserve-profile-ui-failure.json'),
    profile=failed['profile'], profile_sha256=failed['profile_sha256'],
    full_windows_exit=0, app_sha256=failed['app_sha256'], published=False)
stage = work/(prefix+'-runtime'); stage.mkdir()
for n in frozen['baseline_payload']: shutil.copyfile(root/n,stage/n)
shutil.copyfile(root/'genesis-media-runtime.txt',stage/'genesis-media-runtime.txt')
shutil.copytree(root/'fonts',stage/'fonts')
snapshot = work/(prefix+'-source'); snapshot.mkdir()
for n in frozen['source_sha256']:
    p = snapshot/n; p.parent.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(root/n,p)
with (work/(prefix+'-frozen.json')).open('x') as f: json.dump(frozen,f,indent=2)
print('Gain-recovery source frozen separately; failed native evidence and root payload retained.')
