from pathlib import Path
import hashlib, json, shutil
root=Path(__file__).resolve().parent.parent; work=root/'build-windows'
run=work/'cadence-reserve-profile-editing-3faba8c1399a4eccb599af7affd68e08'
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
launch=json.loads((run/'launch.json').read_text())
trace=run/'window-failure.tsv'
assert not trace.exists()
shutil.copyfile(run/'window.tsv',trace)
assert sha(Path(launch['original_project'])) == launch['original_project_sha256']
assert sha(run/'private-project.air') == launch['project_sha256']
assert (work/'cadence-reserve-profile-windows.exit').read_text().strip()=='0'
record=dict(schema='genesis.cadence_reserve.native_ui_failure.v1',passed=False,
    app_sha256=launch['app_sha256'],worker_sha256=launch['worker_sha256'],run=str(run),
    pid=launch['pid'],window=69076790,launch_sha256=sha(run/'launch.json'),
    profile=str(trace),profile_sha256=sha(trace),
    observed=dict(fit_two_clips_with_mapped_bitmaps_and_waveforms=True,
        paused_seek_time='00:00:29:37',program_picture_and_histogram_rgb_luma_updated=True,
        playback_time='00:00:36:39',stereo_meters_active=True,
        track_gain_edit_time='00:00:43:40',track_gain_before=1.0,track_gain_after=1.05,
        resulting_paused_time='00:00:43:41',
        error='[GA_PREVIEW_REQUEST] Cannot publish the preview window'),
    full_windows_gate_exit=0,fitted_4k_cadence_passed_separately=True,
    original_project_unchanged=True,private_project_not_saved=True,
    modal_recovery_acceptance=False,native_edit_recovery_acceptance=False,published=False,
    cause_confirmed=False)
with (work/'cadence-reserve-profile-ui-failure.json').open('x') as f:json.dump(record,f,indent=2)
print('Failed exact-binary native gain-edit check preserved; no publication or acceptance claimed')
