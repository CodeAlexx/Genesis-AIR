# Minimal modal and PCM retirement proposal (read-only preparation)

Maintained source is frozen. This document proposes changes only; no GUI, media, build, or test job was run while preparing it.

## Failure evidence in current shared source

- `src/main.ai:1265` calls synchronous `choose_file`. No preview retirement or audio stop precedes it.
- `src/preview_link.ai:216-238` bounds a stalled window pixel part to two seconds, using `request.id` as its cancellation marker.
- `src/preview.ai:615-619` propagates an unsuccessful pixel send; `src/preview.ai:1053-1055` exits the production task on that error. Its only spawn is `src/main.ai:428`. Consequently a picker held over two seconds during a credit-blocked frame can permanently close preview.
- `src/main.ai:339-345` removes PCM only while first-PCM ownership is waiting/ready. After initial queue, those flags are false. Stop at 579-590 clears a later chunk's pending flag before receipt polling at 621. A successful completed later chunk can remain at the session-owned `playback-chunk.wav` path.

## Proposed modal boundary

Immediately before synchronous `choose_file`, perform one explicit retirement boundary. This pauses both transports; Cancel leaves them paused. It does not seek either transport, restart a device, change authored clips, relax the credit timeout, or launch another producer.

1. Guard request/generation increments against unsigned maximum. On refusal, report a coded retirement error and skip the picker.
2. Pause both document transports (`pause_transport(state,true/false)`).
3. Stop waveOut when its library exists. Set `audio_active=false`, `audio_preparing=false`.
4. Increment `audio_generation` and `audio_request`, publish `audio_playback.discard(root,new_request,new_generation)`, then wake its existing producer. Check publication success. Do not clear pending/ownership before arranging cancellation.
5. Remove the caller-owned current PCM output path regardless of first-PCM flags, then call first-PCM release/reset. Set `audio_pending=false`. This path is exclusively owned by the current window's per-session media namespace, not a user output.
6. Increment `preview_requested`. Add a narrow public `preview.retire_request(root,link,id)->bool effects {alloc,fs.write}`. It atomically writes only `request.id`, using existing `publish_checked`; only on success does it call `link.retire_window` and invalidate `link.snapshot_generation`/snapshot_key. It sends no render command or wake and never writes `stop`.
7. On any marker failure, report a coded error and skip the synchronous picker. The consumer then keeps servicing the event loop rather than blocking an uncancelled producer.
8. Mark paint dirty and invoke the picker. On return, existing next-loop mode/key/epoch configuration clears the queue and publishes the paused current-frame request with a fresh snapshot. A later Play follows the existing native-origin/eight-future first-PCM priming path.

The retired preview ID is a cancellation-only gap, not a frame request. The producer's pre/post-decode checks and every credit retry observe the authoritative newer marker and abandon old work within the existing 50ms retry bound. Idle `next` timeouts may inspect the cancellation-only ID, but the old snapshot header cannot match it, so they do no decode. The next real request has a greater ID and a real snapshot. Never call `preview.stop`, close the link, or replace its task for this boundary.

## Source ownership corner that must be covered

A complete Source packet can have been sent successfully by the producer but not committed through `Link.finish_pixels` before retirement. Producer `held_source` may already contain that Source key while receiver `source_generation` is still zero (or owns the previous Source). A later paused request at the same Source time must not rely on that unreceived packet.

Minimal conservative companion: clear the producer's `held_source` key when installing a NEW immutable snapshot in `preview.run`, immediately after replacing its document. The modal retirement forces a fresh snapshot. Moving windows continue reusing the old snapshot and retain normal held-Source optimization; no new command grammar/credit is needed. This also fixes the analogous snapshot-replacement race outside modal use. Decode the Source once on a new snapshot rather than accepting uncertain bytes. Do not merely relabel existing Source cache with the new request.

An alternative is a dedicated acknowledgement/Source-refresh protocol, but it expands scope. Draining once before retirement does not prove no later completion is queued and is insufficient by itself.

## Normal PCM cleanup race and exact ordering

The fixed output path is `provider.media_root(state.provider)/playback-chunk.wav`, exclusive to this window session. Only the serial `audio_playback.run` owner writes it; native `queue` copies it before returning. No next request is published by the main loop until retirement cleanup completes.

Use a small owned-output release helper at Stop, restart, modal retirement, and final joined shutdown: remove that nonempty session-owned output path independent of first-PCM flags; reset first-PCM flags afterwards. At Stop/modal, publish the superseding discard ID BEFORE removal.

Cases:

- Old render succeeded and checked the old ID before retirement: unconditional removal deletes its complete file. Its late completion notification is rejected by request/epoch eligibility.
- Old render completes after retirement/removal: `execute_playback_audio:3255-3267` rechecks the newer marker, closes its old session and removes the late file.
- Old render is still writing at removal on Windows: removal can fail while the file is open, but after closure the producer observes supersession and performs the removal. Do not silently call this synchronous physical deletion guaranteed; require producer acknowledgement/join for final acceptance.
- New request reuses the same output: serial producer completes old cleanup BEFORE reading/executing the new request. Main performs retirement removal BEFORE publishing the new request. This prevents old cleanup from deleting new-generation output.
- Final window close: stop marker + producer join precede unconditional final removal. Treat a join timeout/cleanup error explicitly rather than claiming cleanup passed.

Do not unconditionally remove arbitrary user export files or introduce deletion inside the generic FFmpeg/native engine. Keep PCM output cleanup at its explicit caller/producer ownership boundary.

## Required focused proofs after approval

Extend actual production-loop fixture `tests/preview_batch.ai` (or a separate fixture using `preview.run`, not a custom sender):

1. Start production persistent fake provider, real channel, 1280x720 two-frame window. Do not pump the consumer for 150-200ms: the payload exceeds bounded wire credit and cannot complete. Publish cancellation-only retire marker and retire Link without a render wake. Hold the consumer for 2300ms, beyond unchanged two-second credit deadline. Then issue a fresh paused request; assert same producer/link remains open, no retired frame completed/published, exact frame-coded Source/Program pixels and current media stamp, no credit error, bounded Stop/join.
2. Complete-but-unreceived Source case: use tiny pictures and consume packet header/body via actual channel while withholding completion from Link; observe real completion and subsequent frame header to prove producer advanced, with Link Source cache still uncommitted. Retire; issue fresh same Source time/new snapshot; assert it sends real Source bytes and exact restore pixels. This must fail without the new-snapshot held-Source reset, with no threshold relaxation.
3. Model/file helper: first-PCM flags false, pending later chunk's completed file exists; Stop-owned release removes it and is safe when empty/nonexistent. Preserve existing first-PCM idempotent release tests separately.
4. Actual serial `audio_playback.run` fixture: finish a later PCM chunk, observe its completion marker/message without main receipt, publish discard then invoke owned release; await discard acknowledgement, assert no file. Repeat with render in flight; old supersession cleanup must remove late output before a new queued request produces independently correct PCM at the reused path.
5. Existing picture_clock, preview_fifo, preview_batch, audio continuity/cancellation gates, then root's native picker >2sec while playing, Cancel/seek/Play/rewind and actual cadence run. No prediction, extra buffer, relaxed gate, or private codec bundle.

## Scope and ownership

Proposed maintained changes: main modal/owned-PCM retirement helper/calls; preview public cancellation-only marker helper + new-snapshot Source reset; focused lifecycle tests. `preview_link` transport format, capacity, cancellation checks and two-second guard stay unchanged. SDK/native DLL/worker/audio DSP source remain unchanged. Root may split ownership across current agents after reviewing this proposal.
