from pathlib import Path
import json,hashlib,shutil,csv,datetime
root=Path(__file__).resolve().parent.parent;work=root/'build-windows';run=work/'cadence-reserve-gain-root-4ab076f8cfcc4511b4bc07e6b5bcdc11'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
l=json.loads((run/'launch.json').read_text());p=json.loads((work/'cadence-reserve-gain-publication.json').read_text())
assert p['published'] and all(sha(root/n)==h for n,h in p['root_binaries'].items())
assert l['app_sha256']==p['root_binaries']['Genesis-AIR.exe'] and l['worker_sha256']==p['root_binaries']['genesis-gcompose.exe']
assert sha(Path(l['project']))==l['project_sha256'] and sha(Path(l['source']))==l['source_sha256']
session=Path((run/'session-report.txt').read_text().strip())
copies={}
for name,src in [('window-ready.tsv',run/'window.tsv'),('waveforms-ready.tsv',session/'timeline-strips/waveforms.tsv'),('thumbnails-ready.tsv',session/'timeline-strips/thumbnails.tsv')]:
    dst=run/name;assert not dst.exists();shutil.copyfile(src,dst);copies[name]=sha(dst)
rows=list(csv.DictReader((run/'window-ready.tsv').open(),delimiter='\t'));last=rows[-1]
assert last['program_shown']==last['source_shown']==last['playing']=='0'
waves=(run/'waveforms-ready.tsv').read_text().splitlines();thumbs=(run/'thumbnails-ready.tsv').read_text().splitlines()
assert len(waves)==2 and len(waves[1].split('\t'))-7==25567
assert len(thumbs)==23 and all(int(t.split('\t')[3])==7 for t in thumbs)
assert all(not x.read_text().strip() for x in (run/'scratch').rglob('producer-failure.tsv'))
errors=run/'scratch/errors.jsonl';assert not errors.exists() or not errors.read_text().strip()
record=dict(passed=True,app_sha256=l['app_sha256'],worker_sha256=l['worker_sha256'],run=str(run),pid=l['pid'],window=6556960,launch_sha256=sha(run/'launch.json'),project_sha256=l['project_sha256'],original_project_unchanged=True,shell_window=False,source_and_program_nonblank_frame_zero=True,playing=False,whole_project_fit=True,frames=76701,processed_peak_cells=25567,mapped_bitmaps=23,scopes_histogram_parade_luma_populated=True,snapshots_sha256=copies,observed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),complete_professional_editing_acceptance=False)
with (work/'cadence-reserve-gain-root-ready.json').open('x') as f:json.dump(record,f,indent=2)
print(json.dumps({'passed':True,'window':6556960,'peaks':25567,'bitmaps':23}))
