"""Record observed native inputs and bind them to the closed private run."""
from pathlib import Path
import hashlib,json
root=Path(__file__).resolve().parent.parent
work=root/'build-windows'
run=work/'cadence-lock-editing-1c17811dbdb1474694b65e592f7da2ee'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
launch=json.loads((run/'launch.json').read_text())
doc=json.loads((run/'private-project.air').read_text())
assert len(doc['clips'])==2 and [(c['start'],c['length'],c['source_in']) for c in doc['clips']]==[(0,3599,0),(3599,3600,0)]
assert not next(t for t in doc['tracks'] if t['name']=='V1')['locked']
assert not next(t for t in doc['tracks'] if t['name']=='V1')['muted']
assert not doc['program']['playing'] and doc['program']['frame']==0
assert sha(Path(launch['original_project']))==launch['original_project_sha256']
assert sha(root/'Regular 1080p60.air')=='7d9e045225e1a236237b85c22342f612c1be92e2cfd298e47df58df8014c9ba0'
assert sha(root/'Costa Rica 4K.air')=='480d82e310ba6f231fab2c0c0db9945dab193d63073cb63fe053019a13aeb143'
record=dict(schema='genesis.cadence_lock.functional_ui.v1',app_sha256=launch['app_sha256'],
  worker_sha256=launch['worker_sha256'],source_sha256=launch['source_sha256'],
  launch_sha256=sha(run/'launch.json'),profile_sha256=sha(run/'window-final.tsv'),
  saved_private_project_sha256=sha(run/'private-project.air'),
  observed_actions=[
    'Native maximized editor opened private 1080p two-clip project; Fit mapped both waveform/bitmap strips',
    'Locked V1; Delete and ShiftDelete refused GA_EDIT_LOCKED retaining2clips7199frames',
    'Painted Lift, Ripple and laneX refused GA_EDIT_LOCKED retaining2clips7199frames',
    'Unlocked Lift produced1clip7199frames with authored hole; oneUndo restored2clips7199',
    'Unlocked Ripple produced1clip3600frames at0; oneUndo restored2clips7199',
    'Ruler seek00:00:29:37 produced matching program picture/time, histogram RGBparade and luma waveform',
    'Embedded V1 Play produced changing pictures and activeL/R meters; Mute silenced meters whiletimeadvanced; Unmute restoredL/R',
    'Stop00:01:04:41 silenced meters; Start0 restorednonnullinitialpicture',
    'Saved and closed only ownedprivateproject; finalprojectunlocked/unmuted2clips7199framespaused0'],
  functional_observations_passed=True,native_cadence_passed=False,
  limitations=['This DF78 timing candidate failed4Kcadence and is notrootpublished',
    'Controls visually observed; numerical document/history contracts supplied by separate7case29checkfixture',
    'No independent speaker/photon observation; no fullscreen4K'],
  original_projects_unchanged=True)
with (work/'cadence-lock-ui.json').open('x') as f:json.dump(record,f,indent=2)
print('Functional UI receipt recorded separately from failed timing acceptance.')
