"""Bind observed private native actions separately from the failed cadence gate."""
from pathlib import Path
import hashlib,json
root=Path(__file__).resolve().parent.parent;work=root/'build-windows'
run=work/'cadence-primed-editing-d760a4dbe73245febcbd0e54c993c341'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
launch=json.loads((run/'launch.json').read_text());doc=json.loads((run/'private-project.air').read_text())
assert sha(run/'private-project.air')==launch['original_project_sha256']
assert sha(Path(launch['original_project']))==launch['original_project_sha256']
assert len(doc['clips'])==2 and [(c['start'],c['length'],c['source_in']) for c in doc['clips']]==[(0,3599,0),(3599,3600,0)]
assert not doc['program']['playing'] and doc['program']['frame']==0
assert not next(t for t in doc['tracks'] if t['name']=='V1')['muted']
record=dict(schema='genesis.preroll.functional_ui.v1',app_sha256=launch['app_sha256'],
    worker_sha256=launch['worker_sha256'],source_sha256=launch['source_sha256'],
    launch_sha256=sha(run/'launch.json'),profile_sha256=sha(run/'window-final.tsv'),
    saved_private_project_sha256=sha(run/'private-project.air'),
    observed_actions=[
        'Fit both1080p clips, mapped thumbnails and processed waveforms',
        'Ruler seek29:37 updates Program picture/time and histogram RGBparade luma waveform',
        'Play29:37 advances pictures and activeL/R; Mute42:28 silences meters while time advances49:32',
        'Unmute53:56 restoresL/R, observed74:25 after clipboundary',
        'AuthoredEOF119:58 pauses with silent output; paused seek29:37 restores matchingpicture',
        'SourcePlay0 advances4:10 withactiveL/R whileProgram stays29:37',
        'SourceStop10:17 silences output; SourceStart0 and ProgramStart0 restore nonblankpictures',
        'Saved unchanged disposableproject; closedonly ownedprivatewindow'],
    functional_observations_passed=True,native_4k_cadence_passed=False,
    limitations=['AF337 remains private because its separate4K timing gate failed',
        'Native meters/device metadata observed; no independent physicalspeaker/photon check',
        'No fullscreen4K or fullprofessional acceptance'],original_project_unchanged=True)
with (work/'cadence-primed-ui.json').open('x') as f:json.dump(record,f,indent=2)
print('Private1080p functional receipt recorded independently of failed4K timing.')
