from pathlib import Path
import hashlib, json, uuid
root = Path(__file__).resolve().parent.parent
work = root/'build-windows'
original = work/'native-paste-large-1080p-1b1c1c5f86904ddabf5dff4bef07b814/audible-retry.air'
raw = original.read_bytes()
doc = json.loads(raw)
assert len(doc['clips']) == 1032 and len(doc['keys']) == 8192
assert doc['program']['mark_in'] == 0 and doc['program']['mark_out'] == 12
assert not doc['program']['playing'] and doc['program']['frame'] == 0
run = work/('cadence-reserve-gain-export-'+uuid.uuid4().hex)
run.mkdir()
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
copies = {}
for name, end in [('cancel-range.air',240),('audible-retry.air',12)]:
    copied = json.loads(raw)
    copied['program']['mark_out'] = end
    p = run/name
    with p.open('x',encoding='utf-8') as f: json.dump(copied,f,indent=2)
    copies[name] = dict(sha256=sha(p),exclusive_range=[0,end],only_allowed_change='/program/mark_out')
assert original.read_bytes() == raw
rec = dict(schema='genesis.native_export.fixture.v1',run=str(run),original=str(original),original_sha256=sha(original),copies=copies)
with (run/'fixture.json').open('x') as f: json.dump(rec,f,indent=2)
print(json.dumps(rec))
