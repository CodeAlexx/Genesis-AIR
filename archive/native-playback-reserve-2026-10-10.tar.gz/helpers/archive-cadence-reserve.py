"""Archive the staged playback-reserve checkpoint after explicit final gates.

Authoring this helper creates no archive. Invoke only after root stages maintained
source and supplies final gate, publication, root-ready, cadence and UI receipts.
--list-inputs lists the contract without launching applications or media jobs.
"""
import argparse
import gzip
import hashlib
import io
import json
import os
from pathlib import Path
import re
import subprocess
import tarfile

ROOT = Path(__file__).resolve().parent.parent
WORK = ROOT / "build-windows"
NAME = "native-playback-reserve-2026-10-10.tar.gz"
TEXT = {".ai", ".py", ".ps1", ".md", ".txt", ".log", ".json", ".cmake",
        ".patch", ".conf", ".c", ".h", ".cpp", ".hlsl", ".def", ".rs",
        ".copying", ".sh", ".tsv", ".exit", ".toml", ".lock"}
HISTORICAL_RUNS = {
    "published-c6d2-failed": "pro-4k-current-baseline-e9b40e9f4fa541f5a777013ddd7a559c",
    "df78-failed": "cadence-lock-4k-9bc5f2e8d97d4c43af4e285e344edbc0",
    "13258-failed": "cadence-reversal-4k-1d0c085d26c44387ba53ccc83e4893ce",
    "af337-failed": "cadence-primed-4k-8a9302f160ea43269d6141dd2d69fac1",
    "9676-failed": "cadence-window-4k-51ccb7b71cca4e2380b610ec952a79d0",
    "8892-incomplete": "cadence-reserve-4k-f628eba6cd754cf9ba7ccec51bd94f9f",
    "8892-private-pass": "cadence-reserve-4k-fa92a46f94c949a08ac599a1d71fa5de",
    "bdf3-cadence-pass-ui-failed": "cadence-reserve-profile-4k-24af528ed73e458ab439336e6710dd59",
}
HELPERS = [
    "analyze-pro-cadence-current.py", "analyze-reserve-credit.py",
    "agent-playback-viewport-hdr-handoff/analyze-native-firstepoch.py",
    "build-private-cadence.py", "build-cadence-reversal.py", "finish-cadence-reversal.py",
    "prepare-cadence-lock.py", "prepare-cadence-full.py", "prepare-reserve-full.py",
    "prepare-reserve-helpers.py", "prepare-reserve-full-helper.py",
    "launch-pro-cadence-current.py", "launch-cadence-lock.py", "launch-cadence-reversal.py",
    "launch-cadence-primed.py", "launch-cadence-window.py", "launch-cadence-reserve.py",
    "record-cadence-lock-ui.py", "record-cadence-primed-ui.py", "record-cadence-window-ui.py",
    "record-reserve-incomplete.py", "cadence-reserve-checkpoint.py",
    "prepare-cadence-modal-full.py", "prepare-cadence-profile-full.py", "record-modal-build.py", "record-profile-ui-failure.py", "audit-modal-recovery-proposal.md",
    "prepare-cadence-gain-full.py",
    "record-profile-diagnosis.py",
    "record-gain-ui.py", "record-gain-cadence.py", "record-gain-export.py",
    "record-gain-root-ready.py", "prepare-gain-native-export.py", "launch-gain-native-export.py",
    "large-native-final-verification/check_export_audible.py",
    "agent-editing-editing-safety/freeze_receipt.py",
]
PROOF_DIRS = [
    "agent-editing-editing-safety", "agent-editing-window-credit",
    "agent-editing-reserve-eight", "agent-pcm-preroll", "agent-preview-fifo",
    "agent-playback-batch",
    "agent-modal-preview", "agent-editing-pcm-owner", "cadence-reserve-modal-clock", "cadence-reserve-profile-linux-cache",
    "agent-gain-producer-diagnostic",
]
PROOF_GLOBS = [
    "agent-editing-editing-safety-*/**/*-tests.json",
    "agent-preview-fifo/cases-*/*-tests.json",
    "agent-playback-batch/check-*/*-tests.json",
    "cadence-*-preview-batch-cases/*-tests.json",
    "cadence-*-preview-fifo-cases/*-tests.json",
    "cadence-lock-focused/**/*-tests.json",
    "*-frontend-results/**/*-tests.json",
    "cadence-reserve-modal-source/tests/window_cache.ai",
    "cadence-reserve-profile-linux-cache/*.tsv",
    "cadence-reserve-profile-editing-3faba8c1399a4eccb599af7affd68e08/window-failure.tsv",
]
PREFIXES = ("cadence-lock-", "cadence-reversal-", "cadence-primed-",
            "cadence-window-", "cadence-reserve-")
REQUIRED_SOURCE = ("src/main.ai", "src/picture_queue.ai", "src/preview.ai",
    "src/preview_link.ai", "src/window_profile.ai", "src/commands.ai",
    "patches/air-editor.patch", "tests/picture_queue.ai", "tests/picture_clock.ai",
    "tests/preview_batch.ai", "tests/preview_fifo.ai", "tests/editing_safety.ai")


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def digest(path):
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1048576), b""):
            h.update(block)
    return h.hexdigest()


def local(value):
    p = Path(str(value).replace("\\", "/"))
    p = p.resolve() if p.is_absolute() else (ROOT / p).resolve()
    if not p.is_relative_to(ROOT):
        raise ValueError("Evidence must reside within this repository")
    return p


def load(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def clean(raw):
    text = raw.decode("utf-8-sig")
    # Longest spellings first: literal Windows paths, JSON-escaped paths and WSL.
    spellings = {str(ROOT), ROOT.as_posix(), "/mnt/c" + ROOT.as_posix()[2:]}
    for item in sorted(spellings, key=len, reverse=True):
        for variant in (json.dumps(item)[1:-1], item):
            text = re.sub(re.escape(variant), "<ROOT>", text, flags=re.I)
    # Also redact unrelated paths under the Windows user profile, including
    # doubled/further escaped JSON separators. Repository prefix is already gone.
    text = re.sub(r"(?i)c:[/\\]+users[/\\]+[^/\\\"\s]+", "<USER>", text)
    wsl_profile = "/mnt/c/" + "users/"
    text = re.sub(r"(?i)" + re.escape(wsl_profile) + r"[^/\"\s]+", "<USER>", text)
    if re.search(r"(?i)c:[/\\]+users[/\\]+|" + re.escape(wsl_profile), text):
        raise ValueError("Unredacted user path")
    return text.encode("utf-8")


def eligible(path):
    # Never archive private projects, pixels, binaries, SDK copies or caches.
    rel = path.relative_to(ROOT)
    parts = [part.lower() for part in rel.parts]
    if any(part in {"air-sdk", "gcompose-source", "fonts", "__pycache__"} for part in parts):
        return False
    return path.is_file() and (path.suffix.lower() in TEXT or path.name in {".gitignore", ".gitattributes"})


def staged_source():
    paths = subprocess.check_output(["git", "ls-files", "-z"], cwd=ROOT).decode().split("\0")
    selected = []
    for name in paths:
        if not name:
            continue
        p = local(name)
        if (name.startswith(("src/", "tests/", "windows/", "patches/", "docs/"))
            or "/" not in name) and eligible(p) and name != "genesis-media-runtime.txt":
            selected.append(name)
    for name in REQUIRED_SOURCE + ("README.md", "docs/CONTROL_COVERAGE.md",
                "docs/WINDOWS_PLAYBACK_VALIDATION_2026-10-10.md"):
        if name not in selected:
            raise ValueError("Required source/doc must be staged: " + name)
    index_hashes = {}
    for name in sorted(set(selected)):
        # --path applies the same Git clean filters as staging (including CRLF).
        raw = (ROOT / name).read_bytes()
        filtered_id = subprocess.check_output(
            ["git", "hash-object", "--path=" + name, "--stdin"], input=raw, cwd=ROOT).decode().strip()
        indexed_id = subprocess.check_output(["git", "rev-parse", ":" + name], cwd=ROOT).decode().strip()
        if filtered_id != indexed_id:
            raise ValueError("Worktree differs from staged clean-filtered source: " + name)
        indexed_raw = subprocess.check_output(["git", "show", ":" + name], cwd=ROOT)
        index_hashes[name] = {"git_blob": indexed_id, "indexed_sha256": sha(indexed_raw),
                              "worktree_sha256": sha(raw)}
    return index_hashes


def source_map(value):
    for field in ("source_sha256", "source", "frozen_source", "sources_sha256"):
        found = value.get(field)
        if isinstance(found, dict):
            return found
    raise ValueError("Frozen receipt has no source hash map")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--list-inputs", action="store_true")
    parser.add_argument("--prefix", default=os.environ.get("GENESIS_CHECKPOINT_PREFIX", "cadence-reserve-final"))
    preliminary, _ = parser.parse_known_args()
    prefix = preliminary.prefix
    if not re.fullmatch(r"cadence-reserve-[a-z0-9-]+", prefix):
        parser.error("--prefix must match cadence-reserve-[a-z0-9-]+")
    for flag, default in {
        "frozen": prefix + "-frozen.json",
        "gate": prefix + "-gate.json",
        "cadence": prefix + "-cadence.json",
        "ui": prefix + "-ui.json",
        "publication": prefix + "-publication.json",
        "root-ready": prefix + "-root-ready.json",
    }.items():
        parser.add_argument("--" + flag, type=Path, default=WORK / default)
    parser.add_argument("--proof", action="append", default=[], metavar="ROLE=FILE")
    parser.add_argument("--output", type=Path, default=ROOT / "archive" / NAME)
    parser.add_argument("--receipt", type=Path, default=WORK / (prefix + "-bundle-receipt.json"))
    args = parser.parse_args()
    if args.list_inputs:
        print(json.dumps({"schema": "genesis.native_playback_reserve.archive_inputs.v1", "prefix": prefix,
            "required_receipts": {k: str(getattr(args, k.replace("-", "_"))) for k in
               ("frozen", "gate", "cadence", "ui", "publication", "root-ready")},
            "historical_runs": HISTORICAL_RUNS, "helpers": HELPERS,
            "cadence_contract": "genesis.cadence_reserve.final.v1: run, analysis_sha256, credit_sha256",
            "ui_contract": "passed, app_sha256, worker_sha256, run, profile_sha256, observed; optional profile",
            "gate_contract": "passed, source, root_payload, evidence[path->sha], final_cadence",
            "publication_contract": "published, root_binaries, runtime_sha256, gate_sha256",
            "root_ready_contract": "passed or ready, app_sha256; optional worker_sha256",
            "archive": NAME, "not_executed": True}, indent=2))
        return
    frozen_path, gate_path, cadence_path, ui_path, publication_path, ready_path = (
        local(getattr(args, n)) for n in ("frozen", "gate", "cadence", "ui", "publication", "root_ready"))
    frozen, gate, pointer, ui, publication, ready = map(load,
        (frozen_path, gate_path, cadence_path, ui_path, publication_path, ready_path))
    assert gate.get("passed") is True and publication.get("published") is True
    assert gate["full_windows_exit"] == publication["full_windows_gate_exit"] == 0
    assert ready.get("passed") is True or ready.get("ready") is True
    assert ui.get("passed") is True and ui.get("observed"), "Explicit bounded UI proof required"
    payload = publication["root_binaries"]
    assert "Genesis-AIR.exe" in payload and "genesis-gcompose.exe" in payload
    for name, expected in payload.items():
        assert digest(local(name)) == expected.lower(), ("Published root payload changed", name)
    assert publication["gate_sha256"].lower() == digest(gate_path)
    assert digest(ROOT / "genesis-media-runtime.txt") == publication["runtime_sha256"].lower()
    assert ui["app_sha256"].lower() == payload["Genesis-AIR.exe"].lower()
    assert ui["worker_sha256"].lower() == payload["genesis-gcompose.exe"].lower()
    assert ready["app_sha256"].lower() == payload["Genesis-AIR.exe"].lower()
    if "worker_sha256" in ready:
        assert ready["worker_sha256"].lower() == payload["genesis-gcompose.exe"].lower()
    root_run = local(ready["run"])
    assert root_run.is_relative_to(WORK), "Root launch evidence must remain in the workspace"
    root_launch_path = root_run / "launch.json"
    assert digest(root_launch_path) == ready["launch_sha256"].lower()
    root_launch = load(root_launch_path)
    assert root_launch["app_sha256"].lower() == payload["Genesis-AIR.exe"].lower()
    assert root_launch["worker_sha256"].lower() == payload["genesis-gcompose.exe"].lower()
    assert root_launch["project_sha256"].lower() == ready["project_sha256"].lower()
    snapshots = ready["snapshots_sha256"]
    assert set(snapshots) == {"window-ready.tsv", "waveforms-ready.tsv", "thumbnails-ready.tsv"}
    for name, expected in snapshots.items():
        assert digest(root_run / name) == expected.lower(), ("Root-ready snapshot changed", name)
    tested = source_map(frozen)
    for name in REQUIRED_SOURCE:
        assert name in tested, ("Missing tested source", name)
    for name, expected in tested.items():
        assert digest(local(name)) == expected.lower(), ("Frozen worktree changed", name)
    if "source" in gate:
        assert gate["source"] == frozen
    if "root_payload" in gate:
        assert gate["root_payload"] == payload
    evidence = gate.get("evidence")
    assert isinstance(evidence, dict) and evidence, "Full-gate evidence ledger required"
    for name, expected in evidence.items():
        assert digest(local(name)) == expected.lower(), ("Final gate evidence changed", name)
    run = local(pointer["run"])
    assert digest(run / "analysis.json") == pointer["analysis_sha256"].lower()
    assert digest(run / "window-credit.json") == pointer["credit_sha256"].lower()
    analysis, credit = load(run / "analysis.json"), load(run / "window-credit.json")
    assert analysis.get("passed_clock_queue_invariants") is True and not analysis.get("errors")
    assert analysis["incomplete_rows"] == 0 and analysis["epoch"]["wall_seconds"] >= 110
    body = analysis["steady_manual_stop_body"]
    for field in ("skipped_frame_positions",
                  "stale_picture_presentations_over_two_frames", "early_picture_presentations",
                  "clock_queue_zero_all_selected_rows", "overwritten_packet_delta", "backwards_picture_jumps"):
        assert body[field] == 0, field
    assert body["program_lag_after_present_frames"]["maximum"] <= 2
    final_cadence = gate["final_cadence"]
    assert local(final_cadence["run"]) == run
    assert final_cadence["analysis_sha256"].lower() == pointer["analysis_sha256"].lower()
    assert final_cadence["credit_sha256"].lower() == pointer["credit_sha256"].lower()
    assert publication["final_cadence"] == final_cadence
    assert credit.get("passed") is True and not credit.get("errors")
    assert credit["max_total"] <= 8 and credit["max_reserved"] <= 2
    assert credit["profile_sha256"].lower() == analysis["raw_profile_sha256"].lower()
    assert credit["launch_sha256"].lower() == analysis["launch_sha256"].lower()
    assert analysis["app_sha256"].lower() == payload["Genesis-AIR.exe"].lower()
    assert analysis["worker_sha256"].lower() == payload["genesis-gcompose.exe"].lower()
    assert digest(run / "window-final.tsv") == analysis["raw_profile_sha256"].lower()
    assert digest(run / "launch.json") == analysis["launch_sha256"].lower()
    ui_run = local(ui["run"])
    ui_profile = local(ui["profile"]) if "profile" in ui else ui_run / "window.tsv"
    assert digest(ui_profile) == ui["profile_sha256"].lower()
    index = staged_source()
    archive, result_path = local(args.output), local(args.receipt)
    assert archive == ROOT / "archive" / NAME
    assert result_path.is_relative_to(WORK)
    assert not archive.exists() and not result_path.exists(), "Preserve previous archive/results"
    entries, provenance = {}, {}

    def add(name, path, role):
        path = local(path)
        assert eligible(path), ("Text-only evidence boundary", path)
        assert not name.startswith("/") and ".." not in Path(name).parts
        if name in entries:
            assert provenance[name]["original_sha256"] == digest(path)
            return
        raw = path.read_bytes()
        assert len(raw) <= 67108864, ("Bounded text member", name)
        sanitized = clean(raw)
        entries[name] = sanitized
        provenance[name] = {"original_sha256": sha(raw), "sanitized_sha256": sha(sanitized),
                            "original_bytes": len(raw), "sanitized_bytes": len(sanitized), "role": role}

    for name in sorted(index):
        add("source/" + name, ROOT / name, "Current staged maintained source/docs, not historical variants")
    for label, folder in HISTORICAL_RUNS.items():
        historic = WORK / folder
        assert historic.is_dir(), ("Required historical run", folder)
        required = ("window-final.tsv", "launch.json", "incomplete.json" if label.endswith("incomplete") else "analysis.json")
        for name in required:
            assert (historic / name).is_file(), (label, name)
        for name in ("window-final.tsv", "launch.json", "analysis.json", "window-credit.json", "incomplete.json"):
            if (historic / name).is_file():
                add("historical/" + label + "/" + name, historic / name, "Original bounded run; identity/result never relabeled")
    for name in ("window-final.tsv", "launch.json", "analysis.json", "window-credit.json"):
        add("final/cadence/" + name, run / name, "Exact published-binary qualified native cadence")
    add("final/native-ui/profile.tsv", ui_profile, "Exact UI receipt profile; no pixels/private project")
    if (ui_run / "launch.json").is_file():
        add("final/native-ui/launch.json", ui_run / "launch.json", "Native UI launch identity")
    add("final/root-ready/launch.json", root_launch_path, "Exact published root window launch identity")
    for name in sorted(snapshots):
        add("final/root-ready/" + name, root_run / name, "Immutable hash-verified published root window and strip snapshots")
    for name, path in (("frozen", frozen_path), ("gate", gate_path), ("cadence", cadence_path),
                       ("ui", ui_path), ("publication", publication_path), ("root-ready", ready_path)):
        add("final/" + name + ".json", path, "Required final checkpoint receipt")
    for name in sorted(evidence):
        path = local(name)
        assert path.is_relative_to(WORK) or path.is_relative_to(ROOT / "archive")
        if eligible(path):
            add("gate-evidence/" + path.relative_to(ROOT).as_posix(), path, "Exact hash-bound final full gate evidence")
    # Include all text reports named by the maintained Windows gate, not PNGs.
    script = (ROOT / "tests/windows.ps1").read_text(encoding="utf-8")
    report_names = set(re.findall(r"Join-Path \$root '([^'/]+\.(?:json|txt))'", script))
    report_names.update("controls-" + tab + ".txt" for tab in ("properties", "filters", "scopes", "audio"))
    bound_reports = {local(name): expected.lower() for name, expected in evidence.items()}
    for name in sorted(report_names):
        report = WORK / name
        assert report.is_file(), ("Final full-suite report missing", name)
        assert report in bound_reports and digest(report) == bound_reports[report], ("Final report must be hash-bound by gate evidence", name)
        add("full-suite/" + name, report, "Exact hash-bound final Windows report")
    for path in sorted(WORK.iterdir()):
        if path.is_file() and path.name.startswith(PREFIXES) and eligible(path):
            if path.suffix.lower() in {".json", ".log", ".exit"}:
                add("stage-evidence/" + path.name, path, "Original private build/frozen/UI/model evidence")
    for folder in PROOF_DIRS:
        for path in sorted((WORK / folder).glob("*")):
            if path.is_file() and path.suffix.lower() in {".json", ".log", ".py", ".ai", ".md"}:
                add("cpu-proof/" + path.relative_to(WORK).as_posix(), path, "Frozen CPU/component receipt or proof source; not a native media timing claim")
    for pattern in PROOF_GLOBS:
        for path in sorted(WORK.glob(pattern)):
            add("cpu-proof/" + path.relative_to(WORK).as_posix(), path, "Original safety/Linux/interpreter/socket/producer model report")
    for name in HELPERS:
        if (WORK / name).is_file():
            add("helpers/" + name, WORK / name, "Build/analysis/checkpoint helper source; not executed by this archive helper")
    for value in args.proof:
        role, separator, filename = value.partition("=")
        assert separator and re.fullmatch(r"[A-Za-z0-9_-]{1,96}", role)
        path = local(filename)
        add("additional/" + role + path.suffix.lower(), path, "Explicit root-supplied additional proof")
    add("helpers/archive-cadence-reserve.py", Path(__file__), "Exact archive helper")
    manifest = {"schema": "genesis.native_playback_reserve.acceptance.v1",
        "root_binaries": payload, "frozen_worktree_sha256": tested,
        "git_index_filtered_worktree_equality_verified": True, "source_index": index,
        "entries": provenance, "historical_results_preserved": True,
        "qualified_final_cadence_app_sha256": analysis["app_sha256"],
        "qualified_final_cadence_scope": analysis.get("scope"),
        "checkpoint_prefix": prefix,
        "complete_professional_editing_acceptance": False,
        "limitations": ["Manual Stop is not authored EOF/full-duration playback",
            "No compound4K60/fullscreen4K or independent physical speaker/photon proof",
            "Historical failed/incomplete runs keep their original app/source scope",
            "Media, pixels, private projects, binaries, codec DLLs and complete SDK/runtime trees excluded"]}
    entries["manifest.json"] = (json.dumps(manifest, indent=2) + "\n").encode()
    assert sum(map(len, entries.values())) <= 536870912
    archive.parent.mkdir(exist_ok=True)
    with archive.open("xb") as target:
        with gzip.GzipFile(fileobj=target, mode="wb", filename="", mtime=0) as compressed:
            with tarfile.open(fileobj=compressed, mode="w") as bundle:
                for name, raw in sorted(entries.items()):
                    item = tarfile.TarInfo(name)
                    item.size, item.mtime, item.mode = len(raw), 0, 0o644
                    bundle.addfile(item, io.BytesIO(raw))
    with tarfile.open(archive, "r:gz") as bundle:
        assert sorted(bundle.getnames()) == sorted(entries)
        for member in bundle:
            raw = bundle.extractfile(member).read()
            assert raw == entries[member.name], member.name
            if member.name != "manifest.json":
                assert sha(raw) == provenance[member.name]["sanitized_sha256"]
        assert json.loads(bundle.extractfile("manifest.json").read()) == manifest
    # Recheck gate-bound inputs after archive readback to catch concurrent drift.
    assert staged_source() == index
    for name, expected in evidence.items():
        assert digest(local(name)) == expected.lower()
    for name, expected in tested.items():
        assert digest(local(name)) == expected.lower()
    for name, expected in payload.items():
        assert digest(local(name)) == expected.lower()
    result = {"schema": "genesis.native_playback_reserve.archive_receipt.v1", "passed": True,
        "archive": archive.relative_to(ROOT).as_posix(), "sha256": digest(archive),
        "entries": len(entries), "every_member_read_back": True, "sanitized": True,
        "git_index_filtered_equality": True, "published_payload_verified": True,
        "source_receipt_sha256": digest(frozen_path), "gate_sha256": digest(gate_path),
        "complete_professional_editing_acceptance": False}
    with result_path.open("x", encoding="utf-8") as f:
        json.dump(result, f, indent=2)
        f.write("\n")
    print(json.dumps(result))


if __name__ == "__main__":
    main()
