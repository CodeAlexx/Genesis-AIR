from pathlib import Path
import hashlib, json, shutil, csv

root = Path(__file__).resolve().parent.parent
work = root / 'build-windows'
run = work / 'cadence-reserve-gain-editing-4e9b03d5a01a48ff9a1e761f955c9f8f'
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
launch = json.loads((run / 'launch.json').read_text())
assert sha(Path(launch['app'])) == launch['app_sha256']
assert sha(Path(launch['worker'])) == launch['worker_sha256']
assert sha(Path(launch['source'])) == launch['source_sha256']
original = Path(launch['original_project'])
assert sha(original) == launch['original_project_sha256']
saved = run / 'private-project.air'
assert sha(saved) == 'b960196649755e4401329ecd48af5c0c232f89cf123e072181702f9d9dd404ef'
a, b = json.loads(original.read_text()), json.loads(saved.read_text())
authored = ('sources','bins','sequences','tracks','transitions','keys','markers','subtitles','filters','filter_params','filter_text_params','names')
for key in authored: assert a[key] == b[key], key
def clips(doc): return [{k:v for k,v in c.items() if k != 'selected'} for c in doc['clips']]
assert clips(a) == clips(b)
assert len(b['clips']) == 2 and sum(c['length'] for c in b['clips']) == 7199
assert b['program']['frame'] == b['monitor']['frame'] == 0
assert not b['program']['playing'] and not b['monitor']['playing']
session = Path((run / 'session-report.txt').read_text().strip())
failure = session / 'preview-producer' / 'producer-failure.tsv'
failures = list(session.rglob('producer-failure.tsv'))
assert all(not p.read_text().strip() for p in failures), failures
errors_path = run / 'scratch/errors.jsonl'
errors = [json.loads(line) for line in errors_path.read_text().splitlines()] if errors_path.exists() else []
assert all('[GA_EDIT_LOCKED]' in e['payload']['attributes']['message'] for e in errors), errors
copies = {}
for name, source in [('window-final.tsv', run / 'window.tsv'), ('waveforms-final.tsv', session / 'timeline-strips/waveforms.tsv'), ('thumbnails-final.tsv', session / 'timeline-strips/thumbnails.tsv')]:
    target = run / name
    assert not target.exists(), target
    shutil.copyfile(source, target)
    copies[name] = sha(target)
rows = list(csv.DictReader((run / 'window-final.tsv').open(), delimiter='\t'))
last = rows[-1]
assert last['program_shown'] == last['source_shown'] == last['playing'] == '0'
thumbs = (run / 'thumbnails-final.tsv').read_text().splitlines()
waves = (run / 'waveforms-final.tsv').read_text().splitlines()
assert len(thumbs) >= 20 and {int(t.split('\t')[0]) for t in thumbs} == {8,9}
assert len(waves) == 3 and {int(t.split('\t')[0]) for t in waves[1:]} == {8,9}
record = dict(schema='genesis.cadence_reserve.native_ui.v1', passed=True,
    run=str(run), pid=launch['pid'], window=17173910,
    app_sha256=launch['app_sha256'], worker_sha256=launch['worker_sha256'],
    source_sha256=launch['source_sha256'], launch_sha256=sha(run/'launch.json'),
    profile=str(run/'window-final.tsv'), profile_sha256=copies['window-final.tsv'],
    snapshot_sha256=copies, saved_private_project_sha256=sha(saved),
    original_project_unchanged=True, authored_content_preserved=True,
    observed=dict(
        fit_two_clips_with_frame_bitmaps_and_processed_waveforms=True,
        waveform_points=[len(t.split('\t'))-7 for t in waves[1:]], thumbnail_rows=len(thumbs),
        paused_seek='00:00:29:37', fresh_picture_time_histogram_rgb_and_luma=True,
        program_play='00:00:42:57', stereo_output_meters_active=True,
        gain_plus='1.05 at 00:00:49:37; stereo resumed at 00:01:02:31',
        gain_minus='1.00 at 00:01:22:16; stereo active at 00:01:26:20',
        pan_plus='0.05 at 00:01:31:17; stereo active at 00:01:34:19',
        pan_minus='0.00 at 00:01:38:52; stereo active at 00:01:43:56',
        mute='on at 00:01:47:34; picture/time advanced silently to 00:01:52:19; off at 00:01:57:33',
        natural_eof='00:01:59:58 paused; nonblank held image; zero meters',
        source_play='00:00:11:37 active stereo; Program held 00:00:29:37',
        source_stop='00:00:15:34 paused silent; SourceStart returned nonblank zero',
        native_open_modal='opened while playing 00:00:44:48; held longer than 2 seconds; Escape returned paused 00:00:44:49',
        post_modal_play='00:00:58:11 active stereo, same healthy producer',
        scrub_during_play='00:01:03:19 to 00:00:29:37 paused, fresh completed frame',
        locked_lift_and_ripple='both refused with GA_EDIT_LOCKED; two clips and 7199 frames preserved',
        split_undo_redo='2 to 3 clips, Undo 2, Redo 3, Undo 2; duration preserved',
        saved_and_native_reopened=True,
        post_reopen_play='00:00:06:20 active green stereo; Source held zero',
        post_reopen_stop='00:00:12:21 paused silent, held nonblank frame',
        post_reopen_start='both monitors nonblank zero; Fit strips and Scopes visible'),
    expected_editor_error_count=len(errors), unexpected_errors=0, durable_producer_failures=0,
    limitations=['Meters and software device clock observed; no physical speaker or display timing claim',
        'Gain-edit initiating failure from prior build remains unproven; this run verifies recovery behavior',
        'Separate exact-binary 4K cadence and full Windows suite still required',
        'No fullscreen4K or complete professional editing acceptance claimed'])
with (work/'cadence-reserve-gain-ui.json').open('x') as f: json.dump(record,f,indent=2)
print(json.dumps({'passed':True,'profile_rows':len(rows),'waveform_points':record['observed']['waveform_points'],'thumbnail_rows':len(thumbs),'saved_sha256':sha(saved)}))
