"""Bind observed controls to the exact disposable native window build."""
from pathlib import Path
import hashlib,json
root=Path(__file__).resolve().parent.parent;work=root/'build-windows'
run=work/'cadence-window-editing-b2b246698ea04ece94abb33c8433570d'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
launch=json.loads((run/'launch.json').read_text());doc=json.loads((run/'private-project.air').read_text())
assert sha(run/'private-project.air')==launch['original_project_sha256']
assert sha(Path(launch['original_project']))==launch['original_project_sha256']
assert len(doc['clips'])==2 and [(c['start'],c['length'],c['source_in']) for c in doc['clips']]==[(0,3599,0),(3599,3600,0)]
assert not doc['program']['playing'] and doc['program']['frame']==0
record=dict(schema='genesis.window.functional_ui.v1',app_sha256=launch['app_sha256'],
    worker_sha256=launch['worker_sha256'],source_sha256=launch['source_sha256'],
    launch_sha256=sha(run/'launch.json'),profile_sha256=sha(run/'window-final.tsv'),
    saved_private_project_sha256=sha(run/'private-project.air'),
    observed_actions=[
        'Fit two1080p clips; mapped thumbnails and processed waveform strips',
        'Paused ruler seek29:37 updates Program picture/time and histogram RGBparade luma waveform',
        'Play29:37, observed34:56 active stereo output',
        'Gain+39:31 changes1.00to1.05 and stereo resumes43:20; Gain-47:29 restores1.00',
        'Pan+51:23 changes0.00to0.05, playback crosses clipboundary60:56 with active stereo; Pan-64:44 restores0.00',
        'Mute68:50 remains silent while time advances72:36; Unmute76:49 restores stereo80:08',
        'Ruler seek duringPlay86:10 pauses and silences output; completed Programpicture/time29:37',
        'SourcePlay0 advances10:59 with activeL/R while Program remains29:37',
        'SourceStop15:29 silent; SourceStart0 and ProgramStart0 nonblank',
        'Saved restored disposableproject with originalhash; closed only ownedprivatewindow'],
    functional_observations_passed=True,native_4k_cadence_passed=False,
    limitations=['Private9676 separate4K cadence gate failed; no publishedsmoothness claim',
        'Meters/device metadata observed; no independent physical speaker/photon synchronization',
        'No authoredEOF or fullprofessional acceptance in this focused run'],original_project_unchanged=True)
with (work/'cadence-window-ui.json').open('x') as f:json.dump(record,f,indent=2)
print('Exact1080p native functional receipt preserved')
