"""Freeze recovery fixes separately; preserve the prior private timing proof."""
from pathlib import Path
import hashlib,json,shutil,subprocess
root=Path(__file__).resolve().parent.parent;work=root/'build-windows'
prefix='cadence-reserve-modal'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
old=json.loads((work/'cadence-reserve-final-frozen.json').read_text())
allowed={'src/main.ai','src/preview.ai','tests/picture_clock.ai','tests/preview_batch.ai','tests/audio_playback.ai','tests/audio_stream.py'}
for n,h in old['source_sha256'].items():
    if n not in allowed:assert sha(root/n)==h,n
for n,h in old['sdk_source_sha256'].items():assert sha(work/'AIR-SDK'/n)==h,n
for n,h in old['baseline_payload'].items():assert sha(root/n)==h,n
prior=old['qualified_private_cadence'];run=Path(prior['run'])
if not run.is_absolute():run=root/run
assert sha(run/'analysis.json')==prior['analysis_sha256']
analysis=json.loads((run/'analysis.json').read_text())
assert analysis['passed_clock_queue_invariants'] and not analysis['errors']
assert analysis['app_sha256']==prior['app_sha256']
assert (work/'cadence-reserve-final-build.exit').read_text().strip()=='0'
receipt=json.loads((work/'cadence-reserve-final-build-receipt.json').read_text())
assert receipt['app_sha256']==sha(work/'cadence-reserve-final-runtime/Genesis-AIR.exe')
assert receipt['build_log_sha256']==sha(work/'cadence-reserve-final-build.log')
frozen=dict(old);frozen['source_sha256']={n:sha(root/n) for n in set(old['source_sha256'])|allowed}
frozen['retained_pre_recovery_full_build']=dict(receipt='build-windows/cadence-reserve-final-build-receipt.json',
    sha256=sha(work/'cadence-reserve-final-build-receipt.json'),published=False)
stage=work/(prefix+'-runtime');stage.mkdir()
for n in frozen['baseline_payload']:shutil.copyfile(root/n,stage/n)
shutil.copyfile(root/'genesis-media-runtime.txt',stage/'genesis-media-runtime.txt')
shutil.copytree(root/'fonts',stage/'fonts')
snapshot=work/(prefix+'-source');snapshot.mkdir()
for n in frozen['source_sha256']:
    p=snapshot/n;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(root/n,p)
with (work/(prefix+'-frozen.json')).open('x') as f:json.dump(frozen,f,indent=2)
print('Recovery sources frozen; fresh full-build stage prepared, no installed payload changed.')
