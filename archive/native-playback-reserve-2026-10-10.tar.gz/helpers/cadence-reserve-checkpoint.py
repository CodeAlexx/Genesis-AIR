"""Exclusive final cadence checkpoint. Creation does not launch, test or publish.

Set GENESIS_CHECKPOINT_PREFIX for a later cadence-reserve-* frozen build.
Final cadence pointer (<prefix>-cadence.json):
 {"schema":"genesis.cadence_reserve.final.v1", "run":"build-windows/<run>",
  "analysis_sha256":"...", "credit_sha256":"..."}
The run contains analysis.json, window-credit.json, window-final.tsv, launch.json.
An explicit gate --cadence-run RUN binds those immutable files directly instead.
UI proof: passed, app_sha256, worker_sha256, run, profile_sha256, observed;
profile optionally names an immutable profile; default is run/window.tsv.
No archive operation; no process termination or recursive cleanup.
"""
from pathlib import Path
import argparse, datetime, hashlib, json, os, re, shutil, subprocess, uuid

ROOT = Path(__file__).resolve().parent.parent
WORK = ROOT / 'build-windows'
PREFIX = os.environ.get('GENESIS_CHECKPOINT_PREFIX', 'cadence-reserve-final')
assert re.fullmatch(r'cadence-reserve-[a-z0-9]+(?:-[a-z0-9]+)*', PREFIX), 'Invalid checkpoint prefix'
STAGE = WORK / (PREFIX + '-runtime')
BIN = WORK / (PREFIX + '-native/bin/Release')
FROZEN = WORK / (PREFIX + '-frozen.json')
OLD = WORK / 'pro-content-stream-final-publication.json'
UI = WORK / (PREFIX + '-ui.json')
POINTER = WORK / (PREFIX + '-cadence.json')
PROTECTED = {
 ROOT / 'Costa Rica 4K.air': '480d82e310ba6f231fab2c0c0db9945dab193d63073cb63fe053019a13aeb143',
 ROOT / 'Regular 1080p60.air': '7d9e045225e1a236237b85c22342f612c1be92e2cfd298e47df58df8014c9ba0',
 Path('<USER>/Downloads/AirFetch/COSTA RICA IN 4K 60fps HDR (ULTRA HD).mp4'): 'bff7165e6704e7188fee82b990e5128fe87c3ce9c5ef7eeb85bd1bb0da42c6da',
 Path('<USER>/Downloads/AirFetch/Which is The Best Qwen3.8-27B_.mp4'): '061d76990215c31e6dc58d22f4ecd09ac92d414fdc73061e8dfcb502cee3f11d',
}
WORKER_SHA = 'aa40b96c631c82cfc834d027678e95a00bd8d5f61db54f15e7c7ecefcf74228c'


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for b in iter(lambda: f.read(1048576), b''): h.update(b)
    return h.hexdigest()


def load(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def write(path, data):
    with Path(path).open('x', encoding='utf-8') as f: json.dump(data, f, indent=2)


def resolve(path):
    p = Path(path)
    return p if p.is_absolute() else ROOT / p


def protected():
    for path, digest in PROTECTED.items(): assert sha(path) == digest, path


def verify_source():
    f = load(FROZEN)
    for n, h in f['source_sha256'].items(): assert sha(ROOT / n) == h, n
    for n, h in f['sdk_source_sha256'].items(): assert sha(WORK / 'AIR-SDK' / n) == h, n
    for n, h in f['worker_source_sha256'].items(): assert sha(WORK / 'gcompose-source/gcompose' / n) == h, n
    for directory, key in (('AIR-SDK', 'sdk_pin'), ('gcompose-source', 'worker_pin')):
        actual = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=WORK / directory, text=True).strip()
        assert actual == f[key], key
    old = load(OLD)
    assert old['root_binaries'] == f['baseline_payload'], 'Wrong installed baseline'
    assert old['runtime_sha256'] == f['runtime_sha256']
    assert old['sdk_pin'] == f['sdk_pin'] and old['worker_pin'] == f['worker_pin']
    protected()
    return f


def payload():
    f = verify_source()
    hashes = {n: sha(STAGE / n) for n in f['baseline_payload']}
    assert hashes['genesis-gcompose.exe'] == WORKER_SHA == f['baseline_payload']['genesis-gcompose.exe']
    assert hashes['OpenCL.dll'] == f['baseline_payload']['OpenCL.dll']
    assert sha(STAGE / 'genesis-media-runtime.txt') == f['runtime_sha256']
    for n in ('Genesis-AIR.exe', 'air-native-shell.dll', 'air-native-dialogs.dll', 'air-ui-host.dll', 'genesis-native-audio.dll'):
        assert sha(BIN / n) == hashes[n], n
    for n in ('NotoSansJP.ttf', 'OFL.txt'): assert sha(STAGE / 'fonts' / n) == sha(ROOT / 'fonts' / n), n
    forbidden = ('avcodec', 'avformat', 'avutil', 'swresample', 'swscale', 'ffmpeg', 'ffprobe')
    assert not [p for p in STAGE.rglob('*') if p.is_file() and p.suffix.lower() in ('.dll', '.exe')
                and p.name.lower().startswith(forbidden)], 'Separate FFmpeg bundle detected'
    return hashes


def launch(mode, installed=False):
    hashes = payload()
    folder = ROOT if installed else STAGE
    if installed:
        published = load(WORK / (PREFIX + '-publication.json'))
        assert published['published'] and published['root_binaries'] == hashes
        for n, h in hashes.items(): assert sha(ROOT / n) == h, n
    assert (WORK / (PREFIX + '-build.exit')).read_text().strip() == '0'
    if mode == '4k':
        original = ROOT / 'Costa Rica 4K.air'
        expected = PROTECTED[original]
        expected_source = PROTECTED[Path('<USER>/Downloads/AirFetch/COSTA RICA IN 4K 60fps HDR (ULTRA HD).mp4')]
    elif mode == 'editing':
        previous = load(WORK / 'pro-content-stream-final-ui.json')
        original = resolve(previous['run']) / 'private-project.air'
        expected = previous['private_project_saved_sha256']
        assert len(load(original)['clips']) == 2, 'Expected prior two-clip disposable sample'
        expected_source = PROTECTED[Path('<USER>/Downloads/AirFetch/Which is The Best Qwen3.8-27B_.mp4')]
    else:
        assert mode == 'regular' and installed
        original = ROOT / 'Regular 1080p60.air'
        expected = PROTECTED[original]
        expected_source = PROTECTED[Path('<USER>/Downloads/AirFetch/Which is The Best Qwen3.8-27B_.mp4')]
    assert sha(original) == expected
    source = Path(load(original)['sources'][0]['path'])
    assert sha(source) == expected_source
    run = WORK / (PREFIX + ('-root-' if installed else '-' + mode + '-') + uuid.uuid4().hex)
    run.mkdir()
    project = original if installed else run / 'private-project.air'
    if not installed: shutil.copyfile(original, project)
    env = dict(os.environ, GENESIS_GCOMPOSE=str(folder / 'genesis-gcompose.exe'),
        GENESIS_SCRATCH=str(run / 'scratch'), GENESIS_SESSION_REPORT=str(run / 'session-report.txt'),
        GENESIS_WINDOW_PROFILE=str(run / 'window.tsv'), GENESIS_TAB='audio')
    env.pop('GENESIS_FAKE_PROVIDER', None)
    child = subprocess.Popen([str(folder / 'Genesis-AIR.exe'), 'open', str(project)], cwd=ROOT,
        env=env, creationflags=subprocess.CREATE_NO_WINDOW)
    rec = dict(pid=child.pid, app=str(folder / 'Genesis-AIR.exe'), worker=str(folder / 'genesis-gcompose.exe'),
        app_sha256=hashes['Genesis-AIR.exe'], worker_sha256=hashes['genesis-gcompose.exe'], source=str(source),
        source_sha256=expected_source, project=str(project), project_sha256=sha(project),
        original_project=str(original), original_project_sha256=expected, scratch=str(run / 'scratch'),
        window_profile=str(run / 'window.tsv'), session_report=str(run / 'session-report.txt'),
        launched_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), shell_window=False,
        scope='Final reserve candidate, ordinary editor; fitted480x270 monitors; no fullscreen4K')
    write(run / 'launch.json', rec)
    print(json.dumps(dict(run=str(run), **rec)))


def cadence(run, expected_app, expected_worker):
    run = resolve(run)
    a = load(run / 'analysis.json'); c = load(run / 'window-credit.json'); l = load(run / 'launch.json')
    assert a['analyzer_sha256'] == sha(WORK / 'analyze-pro-cadence-current.py') == '037d1a8af2c1eaabf37cc7472cafd99e76f9311abb81689b45d4b3c87870c25b'
    assert a['shared_measure_helper_sha256'] == sha(WORK / 'agent-playback-viewport-hdr-handoff/analyze-native-firstepoch.py') == 'c427df5a28f8aa8452cf95f0fbcf9a3d63f133faba1fb9373435bd5d196b5f5c'
    assert a['passed_clock_queue_invariants'] and not a['errors'] and a['incomplete_rows'] == 0
    assert a['app_sha256'] == l['app_sha256'] == expected_app
    assert a['worker_sha256'] == l['worker_sha256'] == expected_worker
    assert a['source_sha256'] == l['source_sha256'] == PROTECTED[Path('<USER>/Downloads/AirFetch/COSTA RICA IN 4K 60fps HDR (ULTRA HD).mp4')]
    assert a['project_sha256'] == l['project_sha256'] == PROTECTED[ROOT / 'Costa Rica 4K.air']
    assert a['launch_sha256'] == c['launch_sha256'] == sha(run / 'launch.json')
    assert a['raw_profile_sha256'] == c['profile_sha256'] == sha(run / 'window-final.tsv')
    assert c['passed'] and not c['errors'] and c['max_total'] <= 8 and c['max_reserved'] <= 2
    assert a['epoch']['wall_seconds'] >= 110, 'Require a substantial terminal native epoch'
    body = a['steady_manual_stop_body']
    for field in ('skipped_frame_positions', 'stale_picture_presentations_over_two_frames', 'early_picture_presentations',
                  'clock_queue_zero_all_selected_rows', 'overwritten_packet_delta', 'backwards_picture_jumps'):
        assert body[field] == 0, field
    assert body['program_lag_after_present_frames']['maximum'] <= 2
    assert body['maximum_frame_jump'] <= 1
    full = a['raw_full_first_epoch']
    assert full['backwards_picture_jumps'] == 0 and full['early_picture_presentations'] == 0
    assert full['overwritten_packet_delta'] == 0, 'Completed packets must not be overwritten in the raw epoch'
    return dict(run=str(run), app_sha256=expected_app, worker_sha256=expected_worker,
        analysis_sha256=sha(run / 'analysis.json'), credit_sha256=sha(run / 'window-credit.json'),
        raw_profile_sha256=a['raw_profile_sha256'], launch_sha256=a['launch_sha256'],
        steady_pictures_per_second=body['pictures_per_second'], steady_changed_pictures=body['changed_pictures'],
        exclusions=body['exclusion'], physical_av_sync_acceptance=False, fullscreen4k_acceptance=False)


def gate(cadence_run=None):
    f = verify_source(); hashes = payload(); evidence = {}
    def retain(path):
        path = Path(path); evidence[str(path.relative_to(ROOT))] = sha(path)
    for suffix in ('-build', '-windows'):
        status = WORK / (PREFIX + suffix + '.exit')
        assert status.read_text().strip() == '0', status
        retain(status); retain(WORK / (PREFIX + suffix + '.log'))
    body = (WORK / (PREFIX + '-windows.log')).read_text(encoding='utf-8-sig')
    for text in ('Headless: 153 saved application facts and 3 native-drop checks passed.',
                 'Controls: 757 clicks reported an outcome; all four tabs passed overlap checks.',
                 'Real Windows media/Unicode paths, source/program preview and failure exit codes passed.'):
        assert text in body, text
    assert 'exceeded the test deadline' not in body
    assert 'Native window semantic cache: 8 passed, 0 failed, 0 skipped, 2527 checks' in body
    fixture_clients = {}
    for name, cases, checks, client in (('preview-batch-tests.json', 8, 228, 'genesis-preview-batch.exe'),
            ('preview-fifo-tests.json', 8, 93, 'genesis-preview-fifo.exe'),
            ('picture-queue-tests.json', 20, 303, 'genesis-picture-queue.exe'),
            ('picture-clock-tests.json', 18, 3329, 'genesis-picture-clock.exe'),
            ('editing-safety-tests.json', 7, 29, 'genesis-editing-safety.exe')):
        p = WORK / name; t = load(p)['payload']
        assert t['status'] == 'pass' and t['cases']['passed'] == cases and t['checks'] == checks, name
        assert t['cases']['failed'] == t['cases']['skipped'] == t['cases_omitted'] == 0
        retain(p)
        fixture_clients[client] = sha(BIN / client)
    fixture_clients['genesis-window-cache.exe'] = sha(BIN / 'genesis-window-cache.exe')
    # Bind every root report named by the exact maintained full-suite script.
    script = (ROOT / 'tests/windows.ps1').read_text(encoding='utf-8-sig')
    named_reports = set(re.findall(r"Join-Path \$root '([^'/]+\.(?:json|txt))'", script))
    for artifact_list in re.findall(r"foreach \(\$artifact in @\(([^)]*)\)\)", script):
        named_reports.update(re.findall(r"'([^'/]+\.(?:json|txt))'", artifact_list))
    named_reports.update('controls-' + tab + '.txt' for tab in ('properties', 'filters', 'scopes', 'audio'))
    for name in sorted(named_reports):
        report = WORK / name
        assert report.is_file(), ('Missing final full-suite report', name)
        retain(report)
    # Preserve the original media gate binding to this full build's client/app/worker.
    for name, client in (('clip-clipboard-media.json', 'genesis-clip-clipboard-media.exe'),
                         ('direct-waveforms.json', 'genesis-direct-waveforms.exe'),
                         ('nested-waveforms.json', 'genesis-nested-waveforms.exe')):
        p = WORK / name; r = load(p)
        assert r['passed'] and r['worker_sha256'] == hashes['genesis-gcompose.exe'], name
        assert r['client_sha256'] == sha(BIN / client), name
        if name == 'clip-clipboard-media.json':
            assert r['app_sha256'] == hashes['Genesis-AIR.exe'] and len(r['cases']) == 5
            assert all(case['passed'] for case in r['cases'])
        retain(p)
    p = WORK / 'direct-waveform-stream.json'; r = load(p)
    assert r['passed'] and r['worker_sha256'] == hashes['genesis-gcompose.exe']
    assert len(r['cases']) == 16 and len(r['refusals']) == 11
    retain(p)
    if cadence_run is None:
        pointer = load(POINTER)
        assert pointer['schema'] == 'genesis.cadence_reserve.final.v1'
        cadence_run = pointer['run']
        assert sha(resolve(cadence_run) / 'analysis.json') == pointer['analysis_sha256']
        assert sha(resolve(cadence_run) / 'window-credit.json') == pointer['credit_sha256']
        retain(POINTER)
    final = cadence(cadence_run, hashes['Genesis-AIR.exe'], hashes['genesis-gcompose.exe'])
    for n in ('analysis.json', 'window-credit.json', 'window-final.tsv', 'launch.json'): retain(resolve(final['run']) / n)
    prior = f['qualified_private_cadence']
    assert sha(resolve(prior['run']) / 'analysis.json') == prior['analysis_sha256']
    private = cadence(prior['run'], prior['app_sha256'], prior['worker_sha256'])
    for n in ('analysis.json', 'window-credit.json', 'window-final.tsv', 'launch.json'): retain(resolve(private['run']) / n)
    ui = load(UI)
    assert ui['passed'] and ui['app_sha256'] == hashes['Genesis-AIR.exe'] and ui['worker_sha256'] == hashes['genesis-gcompose.exe']
    assert isinstance(ui['observed'], dict) and ui['observed'], 'Actual native observations required'
    profile = resolve(ui['profile']) if 'profile' in ui else resolve(ui['run']) / 'window.tsv'
    assert sha(profile) == ui['profile_sha256']; retain(profile); retain(UI)
    launched = load(resolve(ui['run']) / 'launch.json')
    assert launched['app_sha256'] == ui['app_sha256'] and launched['worker_sha256'] == ui['worker_sha256']
    retain(resolve(ui['run']) / 'launch.json'); retain(FROZEN)
    write(WORK / (PREFIX + '-gate.json'), dict(schema='genesis.cadence_reserve.gate.v1', passed=True,
        source=f, root_payload=hashes, full_windows_exit=0, evidence=evidence,
        final_cadence=final, qualified_private_cadence=private,
        native_ui_sha256=sha(UI), helper_sha256=sha(Path(__file__)), fixture_clients_sha256=fixture_clients,
        publication_criterion=dict(separate_from_unchanged_analyzer=True, minimum_epoch_seconds=110,
            zero_steady_omissions=True, zero_completed_packet_overwrites=True, maximum_lag_frames=2),
        complete_professional_editing_acceptance=False))
    print('Exact final Windows suite, bounded-credit cadence and native UI verified.')


def publish():
    p = WORK / (PREFIX + '-gate.json'); g = load(p)
    assert g['passed'] and g['source'] == verify_source() and g['root_payload'] == payload()
    assert sha(Path(__file__)) == g['helper_sha256']
    for name, h in g['evidence'].items(): assert sha(ROOT / name) == h, name
    for name, h in g['fixture_clients_sha256'].items(): assert sha(BIN / name) == h, name
    old = load(OLD)
    for n, h in old['root_binaries'].items(): assert sha(ROOT / n) == h, n
    backup = WORK / 'runtime-backups' / (PREFIX + '-' + uuid.uuid4().hex)
    backup.mkdir()
    moved = {}
    for n, h in g['root_payload'].items():
        target = ROOT / n
        if sha(target) == h: continue
        shutil.copyfile(target, backup / n)
        try: shutil.copyfile(STAGE / n, target)
        except PermissionError:
            preserved = backup / ('loaded-' + n)
            assert preserved.resolve().is_relative_to((WORK / 'runtime-backups').resolve())
            target.rename(preserved); moved[n] = str(preserved)
            shutil.copyfile(STAGE / n, target)
        assert sha(target) == h, n
    protected()
    assert sha(ROOT / 'genesis-media-runtime.txt') == old['runtime_sha256']
    write(WORK / (PREFIX + '-publication.json'), dict(published=True, root_binaries=g['root_payload'],
        runtime_sha256=old['runtime_sha256'], worker_pin=old['worker_pin'], sdk_pin=old['sdk_pin'],
        backup=str(backup), preserved_loaded_images=moved, no_user_process_terminated=True,
        protected_assets_unchanged=True, shared_mm_air_runtime=True, no_separate_ffmpeg_bundle=True,
        full_windows_gate_exit=0, gate_sha256=sha(p), final_cadence=g['final_cadence'],
        complete_professional_editing_acceptance=False))
    print('Verified final root payload published; loaded images preserved without killing users.')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest='operation', required=True)
    sub.add_parser('verify')
    p = sub.add_parser('launch'); mode = p.add_mutually_exclusive_group(required=True)
    mode.add_argument('--4k', dest='fourk', action='store_true'); mode.add_argument('--editing', action='store_true')
    sub.add_parser('launch-root')
    p = sub.add_parser('gate'); p.add_argument('--cadence-run')
    sub.add_parser('publish')
    args = parser.parse_args()
    if args.operation == 'verify': verify_source(); payload(); print('Frozen source, pins, payload and protected assets verified.')
    elif args.operation == 'launch': launch('4k' if args.fourk else 'editing')
    elif args.operation == 'launch-root': launch('regular', installed=True)
    elif args.operation == 'gate': gate(args.cadence_run)
    elif args.operation == 'publish': publish()


if __name__ == '__main__': main()
