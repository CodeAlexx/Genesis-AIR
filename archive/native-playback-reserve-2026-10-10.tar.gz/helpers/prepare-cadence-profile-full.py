from pathlib import Path
import hashlib, json, shutil
root = Path(__file__).resolve().parent.parent
work = root / 'build-windows'
prefix = 'cadence-reserve-profile'
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
old = json.loads((work / 'cadence-reserve-modal-frozen.json').read_text())
for n,h in old['source_sha256'].items():
    if n != 'tests/window_cache.ai': assert sha(root / n) == h, n
for n,h in old['baseline_payload'].items(): assert sha(root / n) == h, n
assert (work / 'cadence-reserve-modal-build.exit').read_text().strip() == '0'
assert (work / 'cadence-reserve-modal-windows.exit').read_text().strip() == '1'
frozen = dict(old)
frozen['source_sha256'] = {n:sha(root/n) for n in old['source_sha256']}
frozen['retained_prior_windows_failure'] = dict(
    build_receipt='build-windows/cadence-reserve-modal-build-receipt.json',
    build_receipt_sha256=sha(work/'cadence-reserve-modal-build-receipt.json'),
    full_suite_log='build-windows/cadence-reserve-modal-windows.log',
    full_suite_log_sha256=sha(work/'cadence-reserve-modal-windows.log'),
    full_suite_exit=1,
    reason='Profile fixture still expected39 columns after seven appended diagnostic fields; no production change')
stage = work / (prefix + '-runtime'); stage.mkdir()
for n in frozen['baseline_payload']: shutil.copyfile(root/n,stage/n)
shutil.copyfile(root/'genesis-media-runtime.txt',stage/'genesis-media-runtime.txt')
shutil.copytree(root/'fonts',stage/'fonts')
snapshot = work / (prefix + '-source'); snapshot.mkdir()
for n in frozen['source_sha256']:
    p = snapshot/n; p.parent.mkdir(parents=True,exist_ok=True); shutil.copyfile(root/n,p)
with (work/(prefix+'-frozen.json')).open('x') as f: json.dump(frozen,f,indent=2)
print('Profile contract fixture frozen separately; prior failed suite retained; fresh full build stage prepared')
