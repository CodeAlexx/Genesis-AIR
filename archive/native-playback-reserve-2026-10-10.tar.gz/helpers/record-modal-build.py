from pathlib import Path
import argparse, hashlib, json, re

work = Path(__file__).resolve().parent
parser = argparse.ArgumentParser()
parser.add_argument('--prefix', default='cadence-reserve-modal')
prefix = parser.parse_args().prefix
assert re.fullmatch(r'cadence-reserve-[a-z0-9-]+', prefix)
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

assert (work / (prefix + '-build.exit')).read_text().strip() == '0'
stage = work / (prefix + '-runtime')
receipt = dict(build_exit=0,
    app_sha256=sha(stage / 'Genesis-AIR.exe'),
    worker_sha256=sha(stage / 'genesis-gcompose.exe'),
    frozen_sha256=sha(work / (prefix + '-frozen.json')),
    build_log_sha256=sha(work / (prefix + '-build.log')),
    generated_sha256={p.name:sha(p) for p in sorted((work / (prefix + '-generated')).glob('*.c'))},
    full_windows_gate_completed=False, native_cadence_qualified=False, published=False)
with (work / (prefix + '-build-receipt.json')).open('x') as f:
    json.dump(receipt, f, indent=2)
print(json.dumps({k:v for k,v in receipt.items() if k != 'generated_sha256'}))
