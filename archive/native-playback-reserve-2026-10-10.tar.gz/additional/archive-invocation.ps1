$ErrorActionPreference='Stop'
$gainArchiveArgs=@(
 'build-windows/archive-cadence-reserve.py','--prefix','cadence-reserve-gain',
 '--proof','ui-waveforms=build-windows/cadence-reserve-gain-editing-4e9b03d5a01a48ff9a1e761f955c9f8f/waveforms-final.tsv',
 '--proof','ui-thumbnails=build-windows/cadence-reserve-gain-editing-4e9b03d5a01a48ff9a1e761f955c9f8f/thumbnails-final.tsv',
 '--proof','export-launch=build-windows/cadence-reserve-gain-export-5349bb724c324fe1b57ff418922378a4/launch.json',
 '--proof','export-fixture=build-windows/cadence-reserve-gain-export-5349bb724c324fe1b57ff418922378a4/fixture.json',
 '--proof','export-profile=build-windows/cadence-reserve-gain-export-5349bb724c324fe1b57ff418922378a4/window-final.tsv',
 '--proof','export-children=build-windows/cadence-reserve-gain-export-5349bb724c324fe1b57ff418922378a4/cancel-children.json',
 '--proof','export-oracle=build-windows/cadence-reserve-gain-export-5349bb724c324fe1b57ff418922378a4/audible-export-oracle.json',
 '--proof','export-oracle-log=build-windows/cadence-reserve-gain-export-5349bb724c324fe1b57ff418922378a4/audible-export-oracle.log',
 '--proof','export-oracle-exit=build-windows/cadence-reserve-gain-export-5349bb724c324fe1b57ff418922378a4/audible-export-oracle.exit',
 '--proof','archive-invocation=build-windows/archive-gain.ps1'
)
& python @gainArchiveArgs
if($LASTEXITCODE -ne 0){throw 'Acceptance archive refused'}
