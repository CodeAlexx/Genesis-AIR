from pathlib import Path
p=Path('build-windows/agent-editing-window-credit/CMakeLists.txt')
s='''cmake_minimum_required(VERSION 3.20)
set(CMAKE_MSVC_RUNTIME_LIBRARY "MultiThreaded$<$<CONFIG:Debug>:Debug>")
project(GenesisWindowCredit C)
set(CMAKE_C_STANDARD 11)
get_filename_component(GENESIS_ROOT "${CMAKE_CURRENT_SOURCE_DIR}/../.." ABSOLUTE)
'''
for name in ['picture-queue','picture-clock']:
 s+=f'''add_executable(genesis-{name} "${{CMAKE_CURRENT_SOURCE_DIR}}/{name}-final.c")
target_include_directories(genesis-{name} PRIVATE "${{GENESIS_ROOT}}/build-windows/AIR-SDK/runtime")
target_compile_definitions(genesis-{name} PRIVATE _CRT_SECURE_NO_WARNINGS)
target_compile_options(genesis-{name} PRIVATE /O2 /bigobj)
target_link_libraries(genesis-{name} PRIVATE "${{GENESIS_ROOT}}/build-windows/pro-content-stream-final-native/runtime/Release/air_rt.lib" user32 gdi32 d2d1 ole32 uiautomationcore shell32 ws2_32 bcrypt advapi32 secur32 crypt32 mf mfplat mfuuid evr strmiids)
'''
p.write_text(s,encoding='utf-8')
