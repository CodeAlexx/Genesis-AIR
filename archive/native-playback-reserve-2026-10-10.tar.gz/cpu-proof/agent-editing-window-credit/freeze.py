from pathlib import Path
import hashlib,json,subprocess
r=Path.cwd(); d=r/'build-windows/agent-editing-window-credit'
files=['src/main.ai','src/picture_queue.ai','src/window_profile.ai','tests/picture_queue.ai','tests/picture_clock.ai']
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
reports=[]
for mode in ['windows','linux','interp']:
 for fixture,cases,checks in [('picture-queue',17,191),('picture-clock',13,81)]:
  p=d/f'{fixture}-final-{mode}.json'; data=json.loads(p.read_text(encoding='utf-8'))['payload']
  assert data['status']=='pass' and data['checks']==checks and data['cases']['passed']==cases and data['cases']['failed']==0
  reports.append({'execution':mode,'fixture':fixture,'path':str(p.relative_to(r)).replace('\\','/'),'cases':cases,'checks':checks,'sha256':sha(p)})
receipt={'passed':True,'files':{f:sha(r/f) for f in files},'imported_producer_fifo':{f:sha(r/f) for f in ['src/preview.ai','src/preview_link.ai']},'main_frontend_pass':True,'main_generated_c_sha256':sha(d/'main-final.c'),'reports':reports,'contract':{'active_owned_plus_reserved_max':3,'window_frames_max':2,'transport_fifo_max':2,'legacy_single_owned_max':2,'receive_order':'individual ascending request ID and exact active authored frame stamp','window_latency':'issue-to-receipt, common issue timestamp; second includes preceding decode','profile_appended_columns':['window_first_id','window_last_id','window_first_frame','window_last_frame','window_count','owned_picture_credit','reserved_picture_credit']},'scope':'CPU model/controller checks only; no native GUI, worker/media or cadence claim.'}
(d/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8');print(json.dumps(receipt['files'],indent=2));print('6 execution reports verified; main frontend passed')
