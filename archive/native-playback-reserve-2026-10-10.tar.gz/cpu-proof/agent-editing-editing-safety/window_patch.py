from pathlib import Path
p=Path('src/picture_queue.ai'); s=p.read_text(encoding='utf-8')
s=s.replace('requests:array<Request>,first_id:u64,received:u64','requests:array<Request>,first_id:u64,received:u64,window_next:u64,window_last:u64')
s=s.replace('requests:array.new(),first_id:0,received:0}', 'requests:array.new(),first_id:0,received:0,window_next:0,window_last:0}')
s=s.replace('struct.set(queue,0,field=in_flight)\n  struct.set(queue,-1', 'struct.set(queue,0,field=in_flight)\n  struct.set(queue,0,field=window_next)\n  struct.set(queue,0,field=window_last)\n  struct.set(queue,-1',1)
pos=s.index('// Wake no later than')
s=s[:pos]+'''// The native window admits at most two complete-or-reserved frames. Transport
// FIFO packets occupy those reservations; they are never extra picture credit.
pub fn reserved(queue:ref<Queue>) -> u64 effects {} {
  if queue.window_next == 0 {0}else{queue.window_last-queue.window_next+1}
}
pub fn credit(queue:ref<Queue>) -> u64 effects {} {
  let used:u64=array.len(struct.borrow(queue,field=frames))+reserved(queue)
  if used >= 2 {0}else{2-used}
}
pub fn window_target(queue:ref<Queue>,wanted:i64,last:i64,fps:f64,shown:i64)
    -> option<i64> effects {} {
  // A bounded window is ordered work. Never replace its remaining packet while
  // the decoder or FIFO owns it, even if the real device clock has advanced.
  if queue.window_next != 0 or queue.in_flight != 0 or credit(queue)==0 {return option.none()}
  target(queue,wanted,last,fps,shown)
}
pub fn window_count(queue:ref<Queue>,first:i64,last:i64) -> u64 effects {} {
  if first < 0 or last < first or queue.window_next != 0 or queue.in_flight != 0 {return 0}
  let free:u64=credit(queue)
  if not queue.playing or last==first {if free>0 {1}else{0}}
  else{free}
}
pub fn requested_window(queue:ref<Queue>,first_id:u64,count:u64,first:i64,last:i64,now:u64)
    -> bool effects {alloc} {
  if not queue.initialized or first_id==0 or count==0 or count>2 or count>window_count(queue,first,last) or
      first_id>18446744073709551615-(count-1) or (count==2 and first==last) {return false}
  struct.set(queue,first_id,field=window_next)
  struct.set(queue,first_id+count-1,field=window_last)
  var at:u64=0
  loop {if at>=count {break}
    requested(queue,first_id+at,first+cast.wrap(at),now)
    at=at+1}
  true
}
''' +s[pos:]
s=s.replace('queue.first_id != 0 and id >= queue.first_id and id > queue.received and id <= queue.in_flight','queue.first_id != 0 and id >= queue.first_id and id > queue.received and id <= queue.in_flight and\n    (queue.window_next == 0 or id == queue.window_next)')
s=s.replace('  if not accepts(queue,id) {return false}\n  struct.set(queue,id,field=received)', '  if not accepts(queue,id) or array.len(struct.borrow(queue,field=frames))>=2 {return false}\n  if queue.window_next != 0 {\n    if id==queue.window_last {struct.set(queue,0,field=window_next)\n      struct.set(queue,0,field=window_last)}\n    else{struct.set(queue,id+1,field=window_next)}\n  }\n  struct.set(queue,id,field=received)',1)
p.write_text(s,encoding='utf-8')
