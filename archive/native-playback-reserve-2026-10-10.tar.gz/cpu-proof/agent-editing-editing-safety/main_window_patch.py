from pathlib import Path
p=Path('src/picture_queue.ai');s=p.read_text(encoding='utf-8');pos=s.index('pub fn receive(');s=s[:pos]+'''// A producer error can belong to either not-yet-received member of the window.
// Successful packet consumption is stricter and must stay in sequence.
pub fn failure_accepts(queue:ref<Queue>,id:u64) -> bool effects {} {
  if queue.window_next != 0 {id>=queue.window_next and id<=queue.window_last}
  else{accepts(queue,id)}
}
'''+s[pos:];p.write_text(s,encoding='utf-8')
p=Path('src/main.ai');s=p.read_text(encoding='utf-8')
s=s.replace('      if picture_queue.configure(pictures,key,audio_generation,picture_playing,picture_source,monitor_width,monitor_height) {dirty=true}', '      if picture_queue.configure(pictures,key,audio_generation,picture_playing,picture_source,monitor_width,monitor_height) {\n        preview_link.retire_window(preview_transport)\n        dirty=true}')
s=s.replace('picture_queue.accepts(pictures,preview_transport.error_generation)', 'picture_queue.failure_accepts(pictures,preview_transport.error_generation)')
a=s.index('    let ready: u64 = preview_transport.ready\n');b=s.index('    // Completion processing may take time.',a)
old=s[a:b];new=old.replace('    let ready: u64 = preview_transport.ready\n    if ready > preview_seen {','    loop {\n      let ready:u64=preview_link.next_completed(preview_transport)\n      if ready==0 {break}\n      if not preview_link.select_completed(preview_transport,ready) {break}')
new=new.replace('        }\n        let problem:', '''        }else{
          app.set_status(state,"[GA_PREVIEW_PACKET] Completed picture does not match the current media generation")
          pause_transport(state,true)
          pause_transport(state,false)
          picture_failed=true
          dirty=true
        }
        let problem:''')
s=s[:a]+new+s[b:]
s=s.replace('picture_queue.target(pictures,wanted,if finish > 0 {finish-1}else{0},fps,shown)', 'picture_queue.window_target(pictures,wanted,if finish > 0 {finish-1}else{0},fps,shown)',1)
a=s.index('      none=>{},some(target)=>{\n        preview_requested=preview_requested+1',s.index('let next_target:'));b=s.index('        struct.set(window_row,window_row.signature+',a)
s=s[:a]+'''      none=>{},some(target)=>{
        let last:i64=if finish>0 {finish-1}else{0}
        let count:u64=picture_queue.window_count(pictures,target,last)
        let program_frame: i64 = if picture_source {parked_program}else{target}
        let source_frame: i64 = if picture_source {target}else{parked_source}
        let signature_begin: u64 = window_profile.stamp(window_measure)
        if count>0 and preview_requested<=18446744073709551615-count {
          let first_id:u64=preview_requested+1
          let last_id:u64=preview_requested+count
          if preview.request_window(state,preview_root,preview_transport,first_id,count,
              struct.borrow(pictures,field=key),program_frame,source_frame,monitor_width,monitor_height,picture_source) {
            preview_requested=last_id
            if not picture_queue.requested_window(pictures,first_id,count,target,last,clock.start()) {
              app.set_status(state,"[GA_PREVIEW_CREDIT] Cannot reserve the published decode window")
              pause_transport(state,true)
              pause_transport(state,false)
              dirty=true
            }
            if window_measure.enabled {
              struct.set(window_row,first_id,field=window_first_id)
              struct.set(window_row,last_id,field=window_last_id)
              struct.set(window_row,target,field=window_first_frame)
              struct.set(window_row,target+cast.wrap(count-1),field=window_last_frame)
              struct.set(window_row,count,field=window_count)
            }
          }else{app.set_status(state,"[GA_PREVIEW_REQUEST] Cannot publish the preview window")
            pause_transport(state,true)
            pause_transport(state,false)
            dirty=true}
        }else{app.set_status(state,"[GA_PREVIEW_CREDIT] Invalid or exhausted decode-window identity")
          pause_transport(state,true)
          pause_transport(state,false)
          dirty=true}
''' +s[b:]
s=s.replace('      struct.set(window_row,preview_transport.overwritten_total,field=overwritten)\n', '      struct.set(window_row,preview_transport.overwritten_total,field=overwritten)\n      struct.set(window_row,array.len(struct.borrow(pictures,field=frames)),field=owned_credit)\n      struct.set(window_row,picture_queue.reserved(pictures),field=reserved_credit)\n')
p.write_text(s,encoding='utf-8')
p=Path('src/window_profile.ai');s=p.read_text(encoding='utf-8');s=s.replace('received: u64, completed: u64, overwritten: u64\n','received: u64, completed: u64, overwritten: u64,\n  window_first_id:u64,window_last_id:u64,window_first_frame:i64,window_last_frame:i64,\n  window_count:u64,owned_credit:u64,reserved_credit:u64\n')
s=s.replace('received:0,completed:0,overwritten:0}', 'received:0,completed:0,overwritten:0,window_first_id:0,window_last_id:0,window_first_frame:-1,\n    window_last_frame:-1,window_count:0,owned_credit:0,reserved_credit:0}')
s=s.replace('overwritten_packets\\n','overwritten_packets\\twindow_first_id\\twindow_last_id\\twindow_first_frame\\twindow_last_frame\\twindow_count\\towned_picture_credit\\treserved_picture_credit\\n')
s=s.replace('cast.wrap(row.in_flight),cast.wrap(row.received),cast.wrap(row.completed),cast.wrap(row.overwritten)]','cast.wrap(row.in_flight),cast.wrap(row.received),cast.wrap(row.completed),cast.wrap(row.overwritten),\n    cast.wrap(row.window_first_id),cast.wrap(row.window_last_id),row.window_first_frame,row.window_last_frame,\n    cast.wrap(row.window_count),cast.wrap(row.owned_credit),cast.wrap(row.reserved_credit)]')
p.write_text(s,encoding='utf-8')
