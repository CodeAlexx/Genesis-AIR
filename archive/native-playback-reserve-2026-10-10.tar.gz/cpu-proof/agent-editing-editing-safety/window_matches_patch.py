from pathlib import Path
p=Path('src/picture_queue.ai');s=p.read_text(encoding='utf-8').replace('type Request = struct {id:u64,at:u64}','type Request = struct {id:u64,at:u64,frame:i64}')
s=s.replace('Request {id:id,at:now}', 'Request {id:id,at:now,frame:frame}')
pos=s.index('pub fn receive(');s=s[:pos]+'''pub fn matches(queue:ref<Queue>,id:u64,source:i64,program:i64) -> bool effects {} {
  if queue.window_next==0 {return true}
  let requests:ref<array<Request>> =struct.borrow(queue,field=requests)
  var at:u64=0
  loop {if at>=array.len(requests) {break}
    let issued:Request=array.get(requests,at)
    if issued.id==id {return issued.frame==(if queue.source {source}else{program})}
    at=at+1}
  false
}
''' +s[pos:]
s=s.replace('if not accepts(queue,id) or array.len(struct.borrow(queue,field=frames))>=2 {return false}', 'if not accepts(queue,id) or array.len(struct.borrow(queue,field=frames))>=2 or\n      not matches(queue,id,frame.position.source_frame,frame.position.program_frame) {return false}')
p.write_text(s,encoding='utf-8')
p=Path('src/main.ai');s=p.read_text(encoding='utf-8');s=s.replace('  var preview_seen: u64 = 0\n','').replace('      preview_seen = preview_requested\n','').replace('      preview_seen=ready\n','')
s=s.replace('if array.len(images) == 2 and position.revision == state.media_revision {', 'if array.len(images) == 2 and position.revision == state.media_revision and\n            picture_queue.matches(pictures,ready,position.source_frame,position.program_frame) {',1)
s=s.replace('          let _ = picture_queue.receive(pictures,ready,picture_queue.Frame {\n            source:next_source,program:next_program,position:position,held_source:held},clock.start())','''          if not picture_queue.receive(pictures,ready,picture_queue.Frame {
              source:next_source,program:next_program,position:position,held_source:held},clock.start()) {
            app.set_status(state,"[GA_PREVIEW_CREDIT] Completed packet cannot acquire its reserved picture slot")
            pause_transport(state,true)
            pause_transport(state,false)
            picture_failed=true
            dirty=true
          }''',1)
p.write_text(s,encoding='utf-8')
p=Path('tests/picture_queue.ai');s=p.read_text(encoding='utf-8');s=s.replace('  let _=test.check(suite,pictures.receive(batch,100,frame(80,1),140000000),', '  let _=test.check(suite,not pictures.receive(batch,100,frame(80,99),139000000),"Wrong picture stamp cannot consume current window credit")\n  let _=test.check(suite,pictures.receive(batch,100,frame(80,1),140000000),')
p.write_text(s,encoding='utf-8')
p=Path('tests/picture_clock.ai');s=p.read_text(encoding='utf-8');s=s.replace('  pictures.requested(ahead,1,31,100)','  let _=test.check(suite,pictures.requested_window(ahead,1,2,31,299,100),"Actual window reserves both preroll packet credits")',1).replace('  pictures.requested(ahead,2,32,300)\n','',1)
s=s.replace('  pictures.requested(source_ahead,1,31,100)', '  let _=test.check(suite,pictures.requested_window(source_ahead,1,2,31,299,100),"Source window reserves exact independent future positions")',1).replace('  pictures.requested(source_ahead,2,32,300)\n','',1)
p.write_text(s,encoding='utf-8')
