import hashlib,json,subprocess
from pathlib import Path
r=Path.cwd(); sdk=r/'build-windows/AIR-SDK'; folder=r/'build-windows/agent-editing-editing-safety'; base=folder/'overlay-base'; patch=r/'patches/air-editor.patch'
def git(cwd,*args): return subprocess.run(['git','-C',str(cwd),*args],check=True,stdout=subprocess.PIPE).stdout
pin=git(sdk,'rev-parse','HEAD').decode().strip()
assert pin=='df80f270dd28af76674b6e80a4f08970c081be3e'
baseline=git(sdk,'show','HEAD:stdlib/editor.ai'); target=base/'stdlib/editor.ai'; target.write_bytes(baseline)
git(base,'apply','--check',str(patch)); git(base,'apply',str(patch))
normalized=lambda p:p.read_bytes().replace(b'\r\n',b'\n')
assert normalized(target)==normalized(sdk/'stdlib/editor.ai')
git(base,'apply','--reverse','--check',str(patch)); git(sdk,'apply','--reverse','--check',str(patch))
reports=[]
for mode in ['windows','linux','interp']:
 for fixture,checks,cases in [('editing-safety',29,7),('editor-trim',33371,6),('trim-history',187,10),('clip-clipboard',59,11)]:
  suffix='' if fixture=='editing-safety' and mode!='interp' else '-'+fixture
  p=r/f'build-windows/agent-editing-editing-safety-{mode}{suffix}'/f'{fixture}-tests.json'
  payload=json.loads(p.read_text(encoding='utf-8'))['payload']
  assert payload['status']=='pass' and payload['checks']==checks and payload['cases']['passed']==cases and payload['cases']['failed']==0
  reports.append({'execution':mode,'fixture':fixture,'path':str(p.relative_to(r)).replace('\\','/'),'cases':cases,'checks':checks,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
files=['patches/air-editor.patch','src/commands.ai','tests/editing_safety.ai','build-windows/AIR-SDK/stdlib/editor.ai','build-windows/agent-editing-editing-safety-native/Release/genesis-editing-safety.exe','build-windows/agent-editing-editing-safety/editing-safety.c']
receipt={'passed':True,'sdk_pin':pin,'head':git(r,'rev-parse','HEAD').decode().strip(),'overlay_forward_check':True,'overlay_reverse_check':True,'overlay_lf_source_roundtrip':True,'files':{f:hashlib.sha256((r/f).read_bytes()).hexdigest() for f in files},'reports':reports,'scope':'CPU model/controller checks only; no native GUI, worker/media or playback cadence claim.'}
out=folder/'receipt.json'; out.write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8'); print(out); print(json.dumps(receipt['files'],indent=2)); print('12 native/interpreter reports verified')
