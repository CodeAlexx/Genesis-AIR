"""Private launch and exact-build checkpoint receipts; never controls user windows."""
from pathlib import Path
import datetime, hashlib, io, json, os, re, shutil, subprocess, sys, tarfile, uuid

ROOT = Path(__file__).resolve().parent.parent
WORK = ROOT / 'build-windows'
STAGE = WORK / 'long-timeline-runtime'
BIN = WORK / 'long-timeline-native/bin/Release'
OLD = WORK / 'viewport-hdr-final-publication.json'
PROTECTED = {
    ROOT/'Costa Rica 4K.air': '480d82e310ba6f231fab2c0c0db9945dab193d63073cb63fe053019a13aeb143',
    ROOT/'Regular 1080p60.air': '7d9e045225e1a236237b85c22342f612c1be92e2cfd298e47df58df8014c9ba0',
    Path('<USER>/Downloads/AirFetch/COSTA RICA IN 4K 60fps HDR (ULTRA HD).mp4'): 'bff7165e6704e7188fee82b990e5128fe87c3ce9c5ef7eeb85bd1bb0da42c6da',
    Path('<USER>/Downloads/AirFetch/Which is The Best Qwen3.8-27B_.mp4'): '061d76990215c31e6dc58d22f4ecd09ac92d414fdc73061e8dfcb502cee3f11d',
}
def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for part in iter(lambda:f.read(1048576), b''): h.update(part)
    return h.hexdigest()
def load(path): return json.loads(Path(path).read_text(encoding='utf-8-sig'))
def write(path, value):
    with Path(path).open('x', encoding='utf-8') as f: json.dump(value,f,indent=2)
def verify_source():
    frozen = load(WORK/'long-timeline-aligned-frozen.json')['source_sha256']
    for n,h in frozen.items(): assert sha(ROOT/n)==h.lower(),n
    return frozen
def verify_protected():
    for p,h in PROTECTED.items(): assert sha(p)==h,str(p)
def payload():
    old = load(OLD)
    hashes = {n:sha(STAGE/n) for n in old['root_binaries']}
    assert hashes['genesis-gcompose.exe']==old['root_binaries']['genesis-gcompose.exe']
    assert hashes['OpenCL.dll']==old['root_binaries']['OpenCL.dll']
    assert sha(STAGE/'genesis-media-runtime.txt')==old['runtime_sha256']
    for n,h in old['fonts'].items(): assert sha(STAGE/n)==h and sha(ROOT/n)==h,n
    assert sha(BIN/'Genesis-AIR.exe')==hashes['Genesis-AIR.exe']
    assert not list(STAGE.glob('av*.dll')) and not list(STAGE.glob('sw*.dll')) and not list(STAGE.glob('ff*.exe'))
    return hashes
def launch(installed=False, user_project=False):
    verify_source(); hashes=payload(); verify_protected()
    folder=ROOT if installed else STAGE
    if installed:
        for n,h in hashes.items(): assert sha(ROOT/n)==h,n
    run=WORK/('long-timeline-'+('root-' if installed else 'native-')+uuid.uuid4().hex)
    run.mkdir(); project=ROOT/'Regular 1080p60.air' if user_project else run/'private-full.air'
    if not user_project: shutil.copyfile(ROOT/'Regular 1080p60.air',project)
    env=dict(os.environ,GENESIS_GCOMPOSE=str(folder/'genesis-gcompose.exe'),
        GENESIS_SCRATCH=str(run/'scratch'),GENESIS_SESSION_REPORT=str(run/'session-report.txt'),
        GENESIS_WINDOW_PROFILE=str(run/'window.tsv'))
    env.pop('GENESIS_FAKE_PROVIDER',None)
    child=subprocess.Popen([str(folder/'Genesis-AIR.exe'),'open',str(project)],cwd=ROOT,
        env=env,creationflags=subprocess.CREATE_NO_WINDOW)
    receipt=dict(pid=child.pid,app_sha256=hashes['Genesis-AIR.exe'],project=str(project),
        scratch=str(run/'scratch'),session_report=str(run/'session-report.txt'),
        window_profile=str(run/'window.tsv'),shell_window=False,
        original_project_sha256=sha(ROOT/'Regular 1080p60.air'),
        launched_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
    write(run/'launch.json',receipt); print(json.dumps(dict(run=str(run),**receipt)))
def gate():
    frozen=verify_source(); hashes=payload(); verify_protected()
    assert (WORK/'long-timeline-full-windows.exit').read_text().strip()=='0'
    log=(WORK/'long-timeline-full-windows.log').read_text(encoding='utf-8-sig')
    assert 'Real Windows media/Unicode paths, source/program preview and failure exit codes passed.' in log
    assert 'Controls: 757 clicks reported an outcome' in log
    assert 'Exception:' not in log and 'exceeded the test deadline' not in log
    ui=load(WORK/'long-timeline-final-ui.json')
    assert ui['passed'] and ui['app_sha256']==hashes['Genesis-AIR.exe']
    for n,cases,checks in [('timeline-track-scroll-tests.json',8,80),
            ('waveform-view-tests.json',6,34),('waveform-detail-tests.json',6,32)]:
        report=load(WORK/n)['payload']
        assert report['status']=='pass' and report['cases']['passed']==cases and report['checks']==checks,n
    for name,client in [('direct-waveforms.json','genesis-direct-waveforms.exe'),
            ('nested-waveforms.json','genesis-nested-waveforms.exe')]:
        report=load(WORK/name)
        assert report['passed'] and report['worker_sha256']==hashes['genesis-gcompose.exe'],name
        assert report['client_sha256']==sha(BIN/client),name
        assert any(c['buckets']==600 and 'fine-600' in c['name'] for c in report['cases']),name
    write(WORK/'long-timeline-final-gate.json',dict(passed=True,full_windows_gate_exit=0,
        full_windows_log_sha256=sha(WORK/'long-timeline-full-windows.log'),
        native_ui_sha256=sha(WORK/'long-timeline-final-ui.json'),
        frozen_source=frozen,tested_binaries=hashes,full_windows_app_sha256=hashes['Genesis-AIR.exe'],
        full_windows_scope='Full Windows suite and actual native UI use exact aligned app source and binaries',
        complete_professional_editing_acceptance=False))
    print('Exact aligned source, full Windows gate and private native UI verified.')
def publish():
    g=load(WORK/'long-timeline-final-gate.json'); assert g['passed']
    assert sha(WORK/'long-timeline-full-windows.log')==g['full_windows_log_sha256']
    assert sha(WORK/'long-timeline-final-ui.json')==g['native_ui_sha256']
    assert verify_source()==g['frozen_source']; assert payload()==g['tested_binaries']
    verify_protected(); old=load(OLD)
    for n,h in old['root_binaries'].items(): assert sha(ROOT/n)==h,n
    assert sha(ROOT/'genesis-media-runtime.txt')==old['runtime_sha256']
    for d,pin in (('gcompose-source',old['worker_pin']),('AIR-SDK',old['sdk_pin'])):
        assert subprocess.check_output(['git','-C',str(WORK/d),'rev-parse','HEAD'],text=True).strip()==pin
    backup=WORK/'runtime-backups'/('long-timeline-'+uuid.uuid4().hex); backup.mkdir()
    moved={}
    for n,h in g['tested_binaries'].items():
        target=ROOT/n
        if sha(target)==h: continue
        shutil.copyfile(target,backup/n)
        try: shutil.copyfile(STAGE/n,target)
        except PermissionError:
            target.rename(backup/('loaded-'+n)); moved[n]=str(backup/('loaded-'+n))
            shutil.copyfile(STAGE/n,target)
        assert sha(target)==h,n
    verify_protected()
    write(WORK/'long-timeline-publication.json',dict(published=True,root_binaries=g['tested_binaries'],
        runtime_sha256=old['runtime_sha256'],backup=str(backup),preserved_loaded_images=moved,
        worker_pin=old['worker_pin'],sdk_pin=old['sdk_pin'],no_user_process_terminated=True,
        protected_assets_unchanged=True,shared_mm_air_runtime=True,no_separate_ffmpeg_bundle=True,
        full_windows_gate_exit=0,full_windows_app_sha256=g['full_windows_app_sha256'],
        gate_sha256=sha(WORK/'long-timeline-final-gate.json'),complete_professional_editing_acceptance=False))
    print('Published verified root payload; protected media, projects and loaded user images preserved.')
def archive():
    g=load(WORK/'long-timeline-final-gate.json'); p=load(WORK/'long-timeline-publication.json')
    assert g['passed'] and p['published']; verify_source(); verify_protected()
    for n,h in p['root_binaries'].items(): assert sha(ROOT/n)==h,n
    tracked=subprocess.check_output(['git','ls-files'],cwd=ROOT,text=True).splitlines()
    owned=['src/waveform_view.ai','tests/waveform_view.ai','tests/waveform_detail.ai']
    paths=sorted(set(tracked+owned))
    suffixes={'.ai','.py','.ps1','.md','.txt','.cmake','.patch','.c','.h','.hlsl','.rs','.def','.sh','.conf','.tsv'}
    source=[n for n in paths if (ROOT/n).is_file() and (Path(n).suffix in suffixes or n=='.gitignore') and
        (n.startswith(('src/','tests/','windows/','patches/','docs/')) or '/' not in n) and n!='genesis-media-runtime.txt']
    reports=['long-timeline-aligned-frozen.json','long-timeline-final-gate.json','long-timeline-final-ui.json',
        'long-timeline-publication.json','long-timeline-root-ready.json','long-timeline-full-windows.log','long-timeline-full-windows.exit',
        'long-timeline-build-aligned.log','timeline-track-scroll-tests.json','waveform-view-tests.json',
        'waveform-detail-tests.json','direct-waveforms.json','nested-waveforms.json',
        'native-audio-clock.json','strip-viewport-tests.json']
    reports+=['waveform_view-frontend-results/waveform-view-tests.json',
        'waveform_view-aligned-frontend-results/waveform-view-tests.json',
        'waveform_detail-frontend-results/waveform-detail-tests.json',
        'long-fit-bootstrap-results/timeline-track-scroll-tests.json',
        'native-long-timeline-b34b9ae43d3d47cfa1a31fa8d5436203/native-ui-prealignment.json']
    def sanitize(data):
        s=data.decode('utf-8-sig')
        for spelling in [str(ROOT).replace('\\','\\\\'),str(ROOT),ROOT.as_posix(),'/mnt/c'+ROOT.as_posix()[2:]]:
            s=re.sub(re.escape(spelling),'<REPO>',s,flags=re.I)
        s=re.sub(r'c:[\\/]+users[\\/]+alexn','<USER>',s,flags=re.I)
        return s.encode('utf-8')
    entries={ 'source/'+n:sanitize((ROOT/n).read_bytes()) for n in source }
    for n in reports: entries['evidence/'+n]=sanitize((WORK/n).read_bytes())
    entries['helpers/long-timeline-checkpoint.py']=sanitize(Path(__file__).read_bytes())
    entries['helpers/record-long-timeline-ui.py']=sanitize((WORK/'record-long-timeline-ui.py').read_bytes())
    native=WORK/'long-timeline-native-658b06f671f641c0bb2a9248e414d35f'
    ui=load(WORK/'long-timeline-final-ui.json')
    assert sha(native/'window.tsv')==ui['native_window_tsv_sha256']
    for n in ('window.tsv','launch.json','fit-waveform-sha.txt'):
        entries['evidence/native/'+n]=sanitize((native/n).read_bytes())
    indexed={n:subprocess.check_output(['git','show',':'+n],cwd=ROOT) for n in source}
    for n,data in indexed.items(): assert data==(ROOT/n).read_bytes().replace(b'\r\n',b'\n'),n
    manifest=dict(source_worktree_sha256={n:sha(ROOT/n) for n in source},
        indexed_source_sha256={n:hashlib.sha256(data).hexdigest() for n,data in indexed.items()},
        git_lf_source_verified=True,
        entries_sha256={n:hashlib.sha256(v).hexdigest() for n,v in entries.items()},
        app_sha256=p['root_binaries']['Genesis-AIR.exe'],full_windows_gate_exit=0,
        excluded='Media, pixels, executables, codec DLLs, personal projects and stale build artifacts',
        complete_professional_editing_acceptance=False)
    entries['manifest.json']=json.dumps(manifest,indent=2).encode()
    target=ROOT/'archive/long-timeline-fine-waveforms-2026-10-10.tar.gz'
    with target.open('xb') as out:
        with tarfile.open(fileobj=out,mode='w:gz') as tar:
            for n,v in sorted(entries.items()):
                info=tarfile.TarInfo(n); info.size=len(v); info.mode=0o644; tar.addfile(info,io.BytesIO(v))
    with tarfile.open(target) as tar:
        assert set(tar.getnames())==set(entries)
        for n,v in entries.items(): assert tar.extractfile(n).read()==v,n
    write(WORK/'long-timeline-bundle-receipt.json',dict(archive=target.name,sha256=sha(target),
        entries=len(entries),readback_verified=True,app_sha256=manifest['app_sha256']))
    print(json.dumps(load(WORK/'long-timeline-bundle-receipt.json')))
if __name__=='__main__':
    {'launch':launch,'launch-root':lambda:launch(True),'launch-user':lambda:launch(True,True),
        'gate':gate,'publish':publish,'archive':archive}[sys.argv[1]]()
