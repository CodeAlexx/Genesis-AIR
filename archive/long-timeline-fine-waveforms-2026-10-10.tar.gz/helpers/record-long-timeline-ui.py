from pathlib import Path
import csv, hashlib, json, subprocess
root=Path(__file__).resolve().parent.parent
work=root/'build-windows'
run=work/'long-timeline-native-658b06f671f641c0bb2a9248e414d35f'
launch=json.loads((run/'launch.json').read_text())
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(work/'long-timeline-runtime/Genesis-AIR.exe')==launch['app_sha256']
assert sha(root/'Regular 1080p60.air')==launch['original_project_sha256']
check=subprocess.run(['powershell','-NoProfile','-Command',
    f'if (Get-Process -Id {launch["pid"]} -ErrorAction SilentlyContinue) {{exit 1}}'],capture_output=True)
assert check.returncode==0,'Private window did not exit'
strip=Path((run/'session-report.txt').read_text().strip())/'timeline-strips'
raw=(strip/'waveforms.tsv').read_bytes()
peaks=raw.decode().splitlines()[1].split('\t')[7:]
assert len(peaks)==25567
assert (run/'fit-waveform-sha.txt').read_text()=='a416f520acc12b23f16bcf0feb0bd2f90828389a8fd2a8a473f14b40345b5e46'
rows=list(csv.DictReader((run/'window.tsv').read_text().splitlines(),delimiter='\t'))
assert any(r['playing']=='1' and int(r['samples_after'])>0 for r in rows)
assert any(int(r['program_shown'])==72733 for r in rows)
assert any(int(r['program_shown'])==76700 for r in rows)
assert int(rows[-1]['program_shown'])==0
bitmaps=(strip/'thumbnails.tsv').read_text().splitlines()
assert len(bitmaps)==23
assert bitmaps[0].split('\t')[1]=='0' and bitmaps[-1].split('\t')[1]=='75174'
record=dict(passed=True,app_sha256=launch['app_sha256'],
    worker_sha256=sha(work/'long-timeline-runtime/genesis-gcompose.exe'),pid=launch['pid'],window=16190724,
    surface='Ordinary maximized 2560x1316; fitted 480x270 monitor; no fullscreen4K',
    project_frames=76701,processed_peak_count=25567,fit_bitmap_rows=23,
    waveform_zoom_reuse=dict(from_request=3,to_request=4,unchanged_tsv_sha256=(run/'fit-waveform-sha.txt').read_text()),
    native_window_tsv_sha256=sha(run/'window.tsv'),
    observed=[
        'Whole21minute clip fits from start to exclusiveend; ruler remains useful',
        'Zoom exposes fine waveform detail and reuses exact complete processed peaks',
        'Seek72733 at20:12:13 aligns changed Program picture, time, marker and histogram/parade/luma',
        'End76700 at21:18:20 is black; independently decoded source lastframe is allzeroRGB',
        'Start restores nonblank frame0 with populated scopes before and after playback',
        'V1embedded audio mixer enabled; Play advances picture/time with active stereo meters',
        'Mute gives zerooutput and zero processed waveform; Unmute restores both',
        'Manual Stop at1:00:06 retains picture, shows PAUSE and zero output meters',
        'Private project saved and only private process closed; original project/media/userwindows preserved'],
    last_frame_reference=json.loads((work/'native-long-timeline-b34b9ae43d3d47cfa1a31fa8d5436203/native-ui-prealignment.json').read_text())['final_source_frame_reference'],
    original_project_unchanged=True,private_test_process_closed=True,
    limitations=['Functional playback ran alongside full Windows suite; no fresh cadence benchmark',
        'No zero-drop/full21minute/4K60/physicalAV/professionalediting acceptance',
        'Cold changed waveform preparation still processes complete clip; bounded peaks are not a full-audio-body memory bound'])
with (work/'long-timeline-final-ui.json').open('x',encoding='utf-8') as f:json.dump(record,f,indent=2)
print(json.dumps(record))
