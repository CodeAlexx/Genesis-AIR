Final-output audio headroom source and numeric acceptance.
Baseline failures are intentionally retained; known-gap fade/nesting uses the earlier worker hash.
No media, executables or personal paths.
