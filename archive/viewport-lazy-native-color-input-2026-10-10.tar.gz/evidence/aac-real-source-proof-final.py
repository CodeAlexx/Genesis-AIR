"""Ignored bounded real-AAC acceptance; no video/GPU/device commands."""
from array import array
import copy
import hashlib
import json
import math
import os
from pathlib import Path
import subprocess
import sys
import time
import wave

REPO=Path(__file__).resolve().parent.parent
sys.path.insert(0,str(REPO/'tests'))
from lazy_gpu import Worker
from audio_stream import wire
from media_runtime import tool
from nested_waveforms import buckets, read_cache

FLAGS=subprocess.CREATE_NO_WINDOW if os.name=='nt' else 0
WORKER=REPO/'build-windows/viewport-hdr-runtime/genesis-gcompose.exe'
FRESH=REPO/'build-windows/viewport-hdr-native/bin/Release/genesis-direct-waveforms.exe'
CLIENT=FRESH
ROOT=REPO/'build-windows/bounded-real-aac-final'
ROOT.mkdir(exist_ok=False)
REPORT=ROOT/'receipt.json'

def sha(path):
    h=hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda:f.read(1024*1024),b''):h.update(block)
    return h.hexdigest()

def run(args,timeout=180):
    return subprocess.run(list(map(str,args)),capture_output=True,timeout=timeout,creationflags=FLAGS)

def wav(path):
    with wave.open(str(path),'rb') as f:
        assert (f.getnchannels(),f.getsampwidth(),f.getframerate())==(2,2,48000)
        n=f.getnframes();values=array('h');values.frombytes(f.readframes(n))
    return n,values

def compare(actual,expected):
    assert len(actual)==len(expected),(len(actual),len(expected))
    # Independent PCM16 quantization. One code includes native round vs truncation.
    maximum=max(abs(a-int(max(-1.,min(1.,v))*32767)) for a,v in zip(actual,expected))
    assert maximum<=1,maximum
    return maximum

receipt=dict(schema='genesis.bounded-real-aac',passed=False,cases=[],
    scope='Two 30-second real AAC clip bodies; audio-only native worker, no device or GPU commands',
    thresholds=dict(pcm16_codes=1,raw_stereo_peak=2e-6))
try:
    base=json.loads((REPO/'build-windows/regular-1080p60-60sec.air').read_text())
    source=Path(base['sources'][0]['path'])
    before={name:sha(path) for name,path in [('source',source),('worker',WORKER),('client',CLIENT)]}
    receipt.update(hashes_before=before,source_bytes=source.stat().st_size,
                   source=str(source),worker=str(WORKER),client=str(CLIENT))
    ffmpeg=tool(WORKER,'ffmpeg');ffprobe=tool(WORKER,'ffprobe')
    receipt['shared_tools']={str(p):sha(p) for p in (ffmpeg,ffprobe)}
    probe=run([ffprobe,'-v','error','-select_streams','a:0','-read_intervals','%+0.1',
               '-show_streams','-show_frames','-of','json',source])
    assert probe.returncode==0,probe.stderr[-4000:]
    metadata=json.loads(probe.stdout)
    stream=metadata['streams'][0];frame=metadata['frames'][0]
    assert stream['codec_name']=='aac' and int(stream['sample_rate'])==44100 and stream['channels']==2
    # Never silently relabel a delayed source. This real asset must prove zero anchor.
    first_pts=float(frame.get('best_effort_timestamp_time',frame.get('pts_time','nan')))
    assert math.isfinite(first_pts) and abs(first_pts)<=.5/44100,(first_pts,frame)
    receipt['native_origin_probe']=dict(stream=stream,first_valid_decoded_frame=frame,
        zero_anchor_proven=True,normal_decoder_priming_editlist_policy_preserved=True,
        nonzero_priming_or_offset_exercised=False)
    for name,start in [('aac-start',0),('aac-late',72000)]:
        doc=copy.deepcopy(base);doc['clips'][0].update(source_in=start,length=1800)
        project=ROOT/(name+'.air');project.write_text(json.dumps(doc),encoding='utf-8')
        project_digest=sha(project)
        manifest=ROOT/(name+'-manifest.tsv');manifest.write_text(f'{name}\t8\tok\n')
        begin=start*735;end=begin+30*44100
        chain=f'atrim=start_sample={begin}:end_sample={end},asetpts=N/SR/TB,aresample=48000,aformat=sample_fmts=flt:sample_rates=48000:channel_layouts=stereo'
        started=time.perf_counter()
        reference=run([ffmpeg,'-nostdin','-v','error','-i',source,'-map','0:a:0',
                       '-af',chain,'-t','30','-f','f32le','pipe:1'])
        assert reference.returncode==0,reference.stderr[-4000:]
        expected=array('f');expected.frombytes(reference.stdout)
        assert len(expected)==1440000*2,len(expected)
        assert all(math.isfinite(v) for v in expected)
        target=buckets(expected,512)
        reference_seconds=time.perf_counter()-started
        out=ROOT/(name+'-native');out.mkdir(exist_ok=True)
        started=time.perf_counter()
        result=run([CLIENT,out,WORKER,manifest])
        elapsed=time.perf_counter()-started
        (ROOT/(name+'-client.log')).write_bytes(result.stdout+result.stderr)
        assert result.returncode==0,(name,result.returncode,result.stdout[-4000:],result.stderr[-4000:])
        _,rows=read_cache(out/(name+'-waveforms.tsv'));actual=rows[8]['peaks']
        assert len(actual)==512,len(actual)
        peak_error=max(abs(a-b) for a,b in zip(actual,target))
        assert peak_error<=2e-6,(name,peak_error)
        pulls=array('h');pull_rows=(out/name/'pulls.tsv').read_text().splitlines()
        for row in pull_rows:
            filename,a,b=row.split('\t');count,part=wav(out/name/filename)
            assert count==(int(b)-int(a))*800,(count,a,b)
            pulls.extend(part)
        pcm_error=compare(pulls,expected)
        count,processed=wav(out/name/'processed.wav');assert count==1440000,count
        processed_error=compare(processed,expected)
        parity=max(abs(a-b) for a,b in zip(pulls,processed));assert parity<=1,parity
        caches=list(out.rglob('.genesis-nested-*'));assert not caches,caches
        # Separately measure cold actual processed-envelope availability, not full fixture duration.
        cache=ROOT/(name+'-cold-cache');cache.mkdir()
        p=Worker(WORKER)
        try:
            p.command('NESTBEGIN '+wire(cache))
            p.command(f'NESTLEAF bus.leaf bus 0 1440000 {wire(source)} {start/60:.17g} 30 1 0 0 30 -')
            p.command('NESTBUS bus - 0 1440000 0 1440000 1 0 0 30 -')
            p.command('NESTCOMMIT')
            peaks=cache/'peaks.f32';p.command('NESTENV bus 512 '+wire(peaks))
            first_result=time.perf_counter()-p.started
            cold=array('f');cold.frombytes(peaks.read_bytes())
            cold_error=max(abs(a-b) for a,b in zip(cold,target));assert len(cold)==512 and cold_error<=2e-6
        finally:
            closed=p.close()
        assert p.init_count()==0,p.trace
        assert not list(cache.glob('*.rf64')),list(cache.iterdir())
        peaks.unlink();cache.rmdir()
        assert sha(project)==project_digest
        receipt['cases'].append(dict(name=name,source_in_owner_frames=start,native_selected_first=begin,
            native_selected_end=end,body_seconds=30,sample_frames=count,stereo_values=len(expected),buckets=512,
            retained_chunks=len(pull_rows),maximum_pcm16_error=pcm_error,
            maximum_processed_pcm16_error=processed_error,maximum_processed_retained_error=parity,
            maximum_raw_peak_error=peak_error,maximum_cold_peak_error=cold_error,
            independent_decode_seconds=reference_seconds,client_closed_seconds=elapsed,
            cold_processed_envelope_first_seconds=first_result,cold_process_closed_seconds=closed,
            native_opencl_init_count=p.init_count(),cache_cleanup=True,project_immutable=True,
            expected_float_sha256=hashlib.sha256(expected.tobytes()).hexdigest(),
            retained_pcm_sha256=hashlib.sha256(pulls.tobytes()).hexdigest()))
        REPORT.write_text(json.dumps(receipt,indent=2),encoding='utf-8')
        print(json.dumps(receipt['cases'][-1]),flush=True)
    after={name:sha(path) for name,path in [('source',source),('worker',WORKER),('client',CLIENT)]}
    assert before==after,(before,after)
    receipt.update(passed=True,hashes_after=after,source_worker_client_immutable=True,
                   late_scope='Origin decode to 1200 seconds remains required; authored/cache body is bounded to 30 seconds. No whole-source waveform, video, device or interactive timing claim.')
except BaseException as error:
    receipt['error']=repr(error)
    raise
finally:
    REPORT.write_text(json.dumps(receipt,indent=2),encoding='utf-8')
