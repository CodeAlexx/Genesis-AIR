"""Private CPU-only project authoring. Never launches Genesis or media tools."""
import argparse
import copy
import hashlib
import json
from pathlib import Path

REPO = Path(__file__).resolve().parents[2]

def sha(path):
    digest = hashlib.sha256()
    with path.open('rb') as source:
        for chunk in iter(lambda: source.read(1048576), b''):
            digest.update(chunk)
    return digest.hexdigest()

def track(ident, owner, kind, order, name):
    return dict(id=ident, owner=owner, kind=kind, order=order, name=name,
                hidden=False, muted=False, locked=False, solo=False,
                gain=0 if kind == 0 else .8, pan=0, height=44)

def clip(ident, owner, lane, source, start, source_in, length=120, nested=0):
    return dict(id=ident, owner=owner, track=lane, source=source, nested=nested,
                source_in=source_in, start=start, length=length, group=0,
                enabled=True, selected=ident == 1000, fade_in=0, fade_out=0,
                gain=1, pan=0, speed=1, reverse=False)

def authored(source):
    doc = dict(schema='air.editor.project', revision=2, active=2,
               source_bounds=0, monitor_source=3, next_id=10000000,
               program=dict(playing=False, frame=0, mark_in=0, mark_out=11,
                            rate=1, looping=False),
               monitor=dict(playing=False, frame=0, mark_in=-1, mark_out=-1,
                            rate=1, looping=False),
               bins=[dict(id=1, name='Private real-source acceptance', parent=0)],
               sequences=[dict(id=2, name='1024 real media placements / 32 tracks',
                               fps=60, width=1920, height=1080)],
               sources=[dict(id=3, path=str(source), name=source.name, bin=1,
                             frames=76701, fps=60, width=1920, height=1080,
                             has_video=True, has_audio=True, audio_rate=44100,
                             audio_channels=2, online=True)],
               tracks=[], clips=[], transitions=[], keys=[], markers=[],
               subtitles=[], filters=[], filter_params=[], filter_text_params=[],
               names=['gain', 'opacity'])
    # Eight busy video/audio pairs plus sixteen empty tracks. At any authored
    # time only one pair is active; empty upper lanes expose viewport scheduling.
    for lane in range(32):
        doc['tracks'].append(track(10+lane, 2, lane % 2, lane,
                                   ('Busy ' if lane < 16 else 'Empty ') + ('V' if lane % 2 == 0 else 'A') + str(lane//2+1)))
    for child in range(4):
        owner = 100+child
        doc['sequences'].append(dict(id=owner, name=f'Private compound {child}',
                                    fps=60, width=1920, height=1080))
        doc['tracks'].append(track(200+child*2, owner, 0, 0, 'Child V1'))
        doc['tracks'].append(track(201+child*2, owner, 1, 1, 'Child A1'))
        for sound in (False, True):
            doc['clips'].append(clip(9000+child*2+sound, owner,
                                      200+child*2+sound, 3, 0, child*240))
    for pair in range(8):
        for segment in range(64):
            position = segment*8+pair
            start = position*120
            source_in = (position*137) % 70000
            for sound in (False, True):
                ident = 1000+position*2+sound
                value = clip(ident, 2, 10+pair*2+sound, 3, start, source_in)
                if not sound and segment > 0 and segment % 16 == 0:
                    value.update(source=0, nested=100+pair%4, source_in=0)
                doc['clips'].append(value)
                # Eight raw owner-frame keys per clip; imported storage order
                # remains unrelated to lane drawing or timeline order.
                for frame in (0, 8, 16, 32, 48, 64, 96, 119):
                    doc['keys'].append(dict(clip=ident, owner=2,
                                            param=1 if sound else 2, frame=frame,
                                            value=.85 if sound else 1, interp=2))
                effect = 100000+position*3
                if sound:
                    doc['filters'].append(dict(id=200000+position, clip=ident,
                                               kind='compressor', order=0, enabled=True))
                    doc['filter_params'].append(dict(filter=200000+position, name='threshold', value=-12))
                else:
                    for offset, kind, level in ((0, 'brightness', 1.05), (1, 'contrast', 1.1)):
                        doc['filters'].append(dict(id=effect+offset, clip=ident,
                                                   kind=kind, order=offset, enabled=True))
                        doc['filter_params'].append(dict(filter=effect+offset, name='level', value=level))
                    if position % 8 == 0:
                        doc['filters'].append(dict(id=effect+2, clip=ident, kind='text', order=2, enabled=True))
                        doc['filter_params'] += [dict(filter=effect+2, name='size', value=48),
                                                 dict(filter=effect+2, name='x', value=0),
                                                 dict(filter=effect+2, name='y', value=0)]
                        doc['filter_text_params'].append(dict(filter=effect+2, name='content', value=f'PRIVATE CUT {position}'))
            if position % 8 == 0:
                doc['markers'].append(dict(id=300000+position, owner=2, frame=start,
                                           duration=0, label=f'Review {position}', color=position%4))
    return doc

def write(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding='utf-8')

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--out', type=Path, required=True)
    args=parser.parse_args()
    receipt=json.loads((REPO/'build-windows/1080p-test-media.json').read_text())
    source=Path(receipt['path'])
    before=sha(source)
    assert before.lower()==receipt['sha256'].lower(), 'Source provenance changed'
    root=args.out.resolve(); root.mkdir(parents=True, exist_ok=False)
    doc=authored(source)
    project=root/'large-native-private.air'
    write(project,doc)
    modified=copy.deepcopy(doc)
    next(p for p in modified['filter_text_params'] if p['filter']==100002)['value']='PRIVATE EDIT CONFIRMED'
    next(f for f in modified['filters'] if f['id']==100000)['order']=1
    next(f for f in modified['filters'] if f['id']==100001)['order']=0
    write(root/'expected-title-order-edit.json',modified)
    rootclips=[c for c in doc['clips'] if c['owner']==2]
    assert len(rootclips)==1024 and len([t for t in doc['tracks'] if t['owner']==2])==32
    endpoints=sorted({c['start'] for c in rootclips}|{c['start']+c['length'] for c in rootclips})
    maximum=max(sum(c['start']<=frame<c['start']+c['length'] for c in rootclips) for frame in endpoints)
    assert maximum==2 and all(c['length']<=120 for c in doc['clips'])
    report=dict(schema='genesis.private.large_native_ui.authoring.v1',
                project=str(project), project_sha256=sha(project), generator_sha256=sha(Path(__file__)),
                source=str(source), source_sha256=before, source_unchanged=sha(source)==before,
                root_clips=1024, root_tracks=32, total_clips=len(doc['clips']),
                compound_instances=sum(bool(c['nested']) for c in rootclips),
                keys=len(doc['keys']), filters=len(doc['filters']),
                title_filters=len(doc['filter_text_params']), max_simultaneous_root_placements=maximum,
                fps=60, width=1920, height=1080, max_clip_seconds=2,
                initial_export_frames=12, selected_clip=1000, selected_title_filter=100002,
                initial_visible_top_lanes='Empty; scroll down to V1/A1 before playback',
                embedded_video_sound='Video tracks gain0; paired A tracks carry authored AAC once',
                scope='CPU authoring only. No native-window/media/save/export acceptance claimed.')
    write(root/'authoring.json',report)
    print(json.dumps(report))

if __name__=='__main__':main()
