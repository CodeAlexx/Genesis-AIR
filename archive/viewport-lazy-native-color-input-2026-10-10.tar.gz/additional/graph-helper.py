"""Private strict wholegraph comparison; CPU JSON only, never media/UI."""
import argparse
from collections import Counter
import copy
import hashlib
import json
import math
from pathlib import Path

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def object_pairs(pairs):
    result={}
    for k,v in pairs:
        if k in result:raise ValueError('Duplicate JSON property: '+k)
        result[k]=v
    return result
def load(p):return json.loads(p.read_text(encoding='utf-8-sig'),object_pairs_hook=object_pairs)
def numeric(v):
    if isinstance(v,float):
        if not math.isfinite(v):raise ValueError('Nonfinite project number')
        return int(v) if v.is_integer() else v
    if isinstance(v,list):return [numeric(x) for x in v]
    if isinstance(v,dict):return {k:numeric(x) for k,x in v.items()}
    return v
def canonical(raw):
    doc=numeric(copy.deepcopy(raw));ledger={}
    names=doc['names']
    assert all(isinstance(n,str) for n in names),'Invalid name pool'
    for key in doc['keys']:
        n=key['param'];assert type(n)==int and 1<=n<=len(names),'Invalid key interner ID'
        key['param']=names[n-1]
    # Resolve every key reference. Preserve unused entries and multiplicity too.
    doc['names']=sorted(names)
    doc['keys'].sort(key=lambda k:json.dumps(k,sort_keys=True,ensure_ascii=False))
    for section in ('program','monitor'):
        for field in ('playing','frame','mark_in','mark_out'):
            if field in doc[section]:
                v=doc[section][field]
                assert type(v)==(bool if field=='playing' else int),'Invalid transport field'
                ledger[f'/{section}/{field}']=v
                doc[section][field]={'explicit_interactive_ledger':True}
    for clip in doc['clips']:
        if 'selected' in clip:
            assert type(clip['selected'])==bool,'Invalid clip selection'
            ledger[f"/clips/id={clip['id']}/selected"]=clip['selected']
            clip['selected']={'explicit_interactive_ledger':True}
    return doc,ledger
def differences(a,b,path=''):
    if isinstance(a,dict) and isinstance(b,dict):
        out=[]
        for k in sorted(a.keys()|b.keys()):
            if k not in a or k not in b:out.append(dict(path=path+'/'+k,expected=a.get(k),actual=b.get(k),missing=True))
            else:out.extend(differences(a[k],b[k],path+'/'+k))
        return out
    if isinstance(a,list) and isinstance(b,list):
        out=[]
        if len(a)!=len(b):out.append(dict(path=path,expected_count=len(a),actual_count=len(b)))
        for i,(x,y) in enumerate(zip(a,b)):out.extend(differences(x,y,f'{path}/{i}'))
        return out
    return [] if type(a)==type(b) and a==b else [dict(path=path,expected=a,actual=b)]
def main():
    p=argparse.ArgumentParser();p.add_argument('--expected',type=Path,required=True);p.add_argument('--actual',type=Path,required=True);p.add_argument('--report',type=Path,required=True)
    args=p.parse_args();expected,actual=load(args.expected),load(args.actual)
    a,la=canonical(expected);b,lb=canonical(actual);diff=differences(a,b)
    selected=set(la)|set(lb)
    ledger=[dict(path=k,expected=la.get(k),actual=lb.get(k)) for k in sorted(selected) if la.get(k)!=lb.get(k)]
    report=dict(schema='genesis.private.wholegraph-comparison',passed=not diff,
        hashes=dict(expected=sha(args.expected),actual=sha(args.actual)),
        graph_difference_count=len(diff),graph_differences=diff,
        explicit_interactive_ledger=ledger,
        interner_storage_ledger=dict(expected=expected['names'],actual=actual['names']),
        canonicalization=['Exact finite numeric JSON values; integral floating representation normalized.',
            'All key param IDs resolve through their own name pool; key storage order canonical only.',
            'Entire name pool sorted as a multiset, including unused entries. No additions/loss ignored.',
            'Program/monitor playing,frame,marks and clip.selected only are explicit separate ledger.',
            'Every other field and array storage order is preserved and compared; unknown fields remain.'],
        counts_expected={k:len(v) for k,v in expected.items() if isinstance(v,list)},
        counts_actual={k:len(v) for k,v in actual.items() if isinstance(v,list)},
        canonical_graph_sha256={label:hashlib.sha256(json.dumps(doc,sort_keys=True,ensure_ascii=False).encode()).hexdigest() for label,doc in [('expected',a),('actual',b)]})
    args.report.parent.mkdir(parents=True,exist_ok=True)
    with args.report.open('x',encoding='utf-8') as f:json.dump(report,f,indent=2)
    print(json.dumps(dict(passed=not diff,graph_differences=len(diff),interactive_changes=len(ledger))))
    return int(bool(diff))
if __name__=='__main__':raise SystemExit(main())
