"""First published-root playback epoch; explicit manual Stop, not authored EOF."""
import csv
import hashlib
import importlib.util
import json
from pathlib import Path
import sys

helper=Path(__file__).with_name('analyze-native-firstepoch.py')
spec=importlib.util.spec_from_file_location('native_epoch',helper)
native=importlib.util.module_from_spec(spec)
spec.loader.exec_module(native)
snapshot,launch_path,output=map(Path,sys.argv[1:4])
raw=snapshot.read_bytes()
rows=[]
ignored=0
for values in csv.DictReader(raw.decode('utf-8-sig').splitlines(),delimiter='\t'):
    if not values or any(v is None or v=='' for v in values.values()):
        ignored+=1
        continue
    rows.append({k:float(v) if k=='fps' else int(v) for k,v in values.items()})
start=next(i for i,r in enumerate(rows) if r['playing'])
end=start
while end<len(rows) and rows[end]['playing']:end+=1
epoch=rows[start:end]
clock_rows=[r for r in epoch if r['clock_ok']]
stop_sample=max(r['samples_after'] for r in clock_rows)
stop_seconds=stop_sample/48000
tail_cutoff=stop_sample-24000
steady=[r for r in epoch if r['clock_ok'] and r['samples_before']>=48000 and r['samples_after']<tail_cutoff]
first60=[r for r in epoch if r['clock_ok'] and r['samples_before']>=48000 and r['samples_after']<2856000]
full=native.measure(epoch)
body=native.measure(steady)
body.update(exclusion='Device first1.0s and final0.5s before observed manual Stop excluded; no authored EOF occurred.',
    exact_selection=f'clock_ok and samples_before >= 48000 and samples_after < {tail_cutoff}',
    manual_stop_device_samples=stop_sample,manual_stop_device_seconds=stop_seconds,
    selected_rows=len(steady),
    clock_queue_zero_all_selected_rows=sum(r['queued_before']==0 or r['queued_after']==0 for r in steady))
bounded=native.measure(first60)
bounded.update(exclusion='A separately named FIRST60 subset: sample range1.0s..59.5s only, not an EOF or observed Stop boundary.',
    exact_selection='clock_ok and samples_before >= 48000 and samples_after < 2856000',
    selected_rows=len(first60))
launch=json.loads(launch_path.read_text(encoding='utf-8-sig'))
hashes=launch['hashes']
errors=[]
if full['backwards_picture_jumps']:errors.append('Backward displayed frame in first epoch')
if body['early_picture_presentations']:errors.append('Steady early picture')
if body['stale_picture_presentations_over_two_frames']:errors.append('Steady lag exceeds two frames')
if body['clock_queue_zero_all_selected_rows']:errors.append('Steady observed drained device queue')
result=dict(schema='genesis.native-root-manual-stop-first-epoch.v1',
    scope='Published root52A6 native handoff/EndDraw and audio clock over one manually stopped interval; not whole21min-source cadence',
    app_sha256=hashes[launch['app']],worker_sha256=hashes[launch['worker']],
    source_sha256=hashes[launch['source']],project_sha256=hashes[launch['original_project']],
    launch_metadata_sha256=hashlib.sha256(launch_path.read_bytes()).hexdigest(),
    original_launch_sha256=launch['original_receipt_sha256'],
    source_hash_provenance=launch['source_hash_provenance'],
    authored_duration_seconds=launch['authored_duration_seconds'],
    authored_video_frames=launch['authored_video_frames'],manual_stop=True,
    profile_snapshot_sha256=hashlib.sha256(raw).hexdigest(),profile_snapshot_bytes=len(raw),
    complete_rows_observed=len(rows),incomplete_rows_ignored=ignored,
    selected_epoch=dict(first_row_index=start,end_row_index_exclusive=end,actual_contiguous_playing=True,
        playing_rows=len(epoch),wall_seconds=(epoch[-1]['loop_end_ns']-epoch[0]['loop_begin_ns'])/1e9,
        identity_values={k:sorted({r[k] for r in epoch}) for k in
            ('audio_origin','fps','source_mode','document_revision','media_revision','width','height','snapshot_generation')},
        excluded_later_rows=len(rows)-end),
    raw_full_first_epoch=full,steady_manual_stop_body=body,bounded_first60_comparator=bounded,
    first_epoch_cache_rebuild_delta=epoch[-1]['audio_cache_rebuilds']-epoch[0]['audio_cache_rebuilds'],
    first_epoch_strip_request_delta=epoch[-1]['strip_requests']-epoch[0]['strip_requests'],
    errors=errors,passed_not_early_clock_and_queue_invariants=not errors,
    limitations=['Only this52A6 root epoch; separate AD/80A6/C524 evidence retains original identities.',
        'Manual Stop does not prove authored EOF or sustained21min cadence.',
        'Frame positions are application metadata, not independent source pixels for every picture.',
        'EndDraw/audio-clock observations exclude physical speaker/photon latency.',
        'Full startup offsets are preserved; steady exclusions do not substitute for raw evidence.',
        'Recorded skips preclude zero-drop60fps acceptance.'],
    analyzer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    shared_measure_helper_sha256=hashlib.sha256(helper.read_bytes()).hexdigest())
with output.open('x',encoding='utf-8') as target:
    json.dump(result,target,indent=2)
    target.write('\n')
print(json.dumps({k:result[k] for k in ('app_sha256','selected_epoch','raw_full_first_epoch','steady_manual_stop_body','errors')},indent=2))
