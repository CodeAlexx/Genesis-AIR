"""CPU-only first contiguous native playback epoch analysis; never reads live UI."""
import argparse
import csv
import hashlib
import json
from pathlib import Path
import statistics


def stats(values):
    values = sorted(values)
    if not values:
        return dict(count=0, median=None, p95=None, maximum=None)
    return dict(count=len(values), median=statistics.median(values),
                p95=values[int((len(values)-1)*.95)], maximum=values[-1])


def measure(rows):
    shown = [r for r in rows if r['present_ok'] and r['present_ns'] > 0
             and r['program_shown'] >= 0 and r['clock_ok']]
    changed = []
    for row in shown:
        if not changed or row['program_shown'] != changed[-1]['program_shown']:
            changed.append(row)
    gaps = [(b['present_end_ns']-a['present_end_ns'])/1e6
            for a, b in zip(changed, changed[1:])]
    jumps = [b['program_shown']-a['program_shown']
             for a, b in zip(changed, changed[1:])]
    before = [r['heard_before']-r['program_shown'] for r in shown]
    after = [r['heard_after']-r['program_shown'] for r in shown]
    interval = ((changed[-1]['present_end_ns']-changed[0]['present_end_ns'])/1e9
                if len(changed) > 1 else 0)
    drift = (((shown[-1]['samples_after']-shown[0]['samples_after'])/48000
              -(shown[-1]['present_end_ns']-shown[0]['present_end_ns'])/1e9)*1000
             if len(shown) > 1 else None)
    return dict(
        presentations=len(shown), changed_pictures=len(changed),
        repeated_picture_presentations=len(shown)-len(changed),
        first_frame=changed[0]['program_shown'] if changed else None,
        last_frame=changed[-1]['program_shown'] if changed else None,
        changed_picture_interval_seconds=interval,
        pictures_per_second=(len(changed)-1)/interval if interval else None,
        rate_definition='Intervals between distinct presented frame positions / elapsed EndDraw time',
        skipped_frame_positions=sum(max(0, j-1) for j in jumps),
        maximum_frame_jump=max(jumps, default=0),
        backwards_picture_jumps=sum(j < 0 for j in jumps),
        picture_gap_ms=stats(gaps),
        program_lag_before_present_frames=stats(before),
        program_lag_after_present_frames=stats(after),
        program_lag_after_present_ms=stats([(r['heard_after']-r['program_shown'])*1000/r['fps'] for r in shown]),
        stale_picture_presentations_over_two_frames=sum(lag > 2 for lag in after),
        early_picture_presentations=sum(lag < 0 for lag in before),
        queue_before_distribution=stats([r['queued_before'] for r in shown]),
        queue_after_distribution=stats([r['queued_after'] for r in shown]),
        observed_drained_queue_presentations=sum(r['queued_before'] == 0 or r['queued_after'] == 0 for r in shown),
        prepared_picture_queue=stats([r['prepared_frames'] for r in shown]),
        device_interval_drift_ms=drift,
        phases_ms={name: stats([r[name]/1e6 for r in shown])
                   for name in ('paint_ns','present_ns','wait_ns','signature_ns','diagnostic_previous_ns')},
        completed_packet_delta=shown[-1]['completed_packets']-shown[0]['completed_packets'] if shown else 0,
        overwritten_packet_delta=shown[-1]['overwritten_packets']-shown[0]['overwritten_packets'] if shown else 0,
        frame_gap_events=[dict(from_frame=a['program_shown'],to_frame=b['program_shown'],
                               gap_ms=(b['present_end_ns']-a['present_end_ns'])/1e6)
                          for a,b in zip(changed,changed[1:]) if b['program_shown'] > a['program_shown']+1])


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('snapshot',type=Path)
    parser.add_argument('launch',type=Path)
    parser.add_argument('output',type=Path)
    parser.add_argument('--duration-seconds',type=float,default=60)
    args=parser.parse_args()
    raw=args.snapshot.read_bytes()
    rows=[]
    incomplete=0
    reader=csv.DictReader(raw.decode('utf-8-sig').splitlines(),delimiter='\t')
    for values in reader:
        if not values or any(v is None or v == '' for v in values.values()):
            incomplete+=1
            continue
        rows.append({k:float(v) if k=='fps' else int(v) for k,v in values.items()})
    start=next(i for i,r in enumerate(rows) if r['playing'])
    end=start
    while end < len(rows) and rows[end]['playing']:
        end+=1
    epoch=rows[start:end]
    steady=[r for r in epoch if r['clock_ok'] and r['samples_before'] >= 48000
            and r['samples_after'] < round((args.duration_seconds-.5)*48000)]
    full=measure(epoch)
    body=measure(steady)
    body.update(exclusion='First1.0s device samples and last0.5s authored body excluded; raw full epoch retained.',
                exact_selection='clock_ok and samples_before >= 48000 and samples_after < (duration_seconds-.5)*48000',
                selected_rows=len(steady),
                clock_queue_zero_all_selected_rows=sum(r['queued_before']==0 or r['queued_after']==0 for r in steady))
    launch=json.loads(args.launch.read_text(encoding='utf-8-sig'))
    hashes=launch['hashes']
    app_hash=hashes[launch['app']]
    worker_hash=hashes[launch['worker']]
    errors=[]
    if full['backwards_picture_jumps']:errors.append('Backward displayed frame in first epoch')
    if body['early_picture_presentations']:errors.append('Steady early picture')
    if body['stale_picture_presentations_over_two_frames']:errors.append('Steady lag exceeds two frames')
    if body['clock_queue_zero_all_selected_rows']:errors.append('Steady observed drained device queue')
    result=dict(schema='genesis.native-regular-1080p-first-epoch',
        scope='Actual run_window native handoff/EndDraw and audio sample clock; no speaker or photon latency claim',
        app_sha256=app_hash,worker_sha256=worker_hash,
        source_sha256=hashes[launch['source']],project_sha256=hashes[launch['original_project']],
        profile_snapshot=str(args.snapshot),profile_snapshot_sha256=hashlib.sha256(raw).hexdigest(),
        profile_snapshot_bytes=len(raw),complete_rows_observed=len(rows),incomplete_rows_ignored=incomplete,
        selected_epoch=dict(first_row_index=start,end_row_index_exclusive=end,
            actual_contiguous_playing=True,playing_rows=len(epoch),
            wall_seconds=(epoch[-1]['loop_end_ns']-epoch[0]['loop_begin_ns'])/1e9,
            identity_values={k:sorted({r[k] for r in epoch}) for k in
                ('audio_origin','fps','source_mode','document_revision','media_revision','width','height','snapshot_generation')},
            excluded_later_rows=len(rows)-end),
        full_first_epoch=full,provisional_steady_body=body,
        first_epoch_cache_rebuild_delta=epoch[-1]['audio_cache_rebuilds']-epoch[0]['audio_cache_rebuilds'],
        first_epoch_strip_request_delta=epoch[-1]['strip_requests']-epoch[0]['strip_requests'],
        errors=errors,passed_not_early_clock_and_queue_invariants=not errors,
        limitations=['One bounded playback of the identified app/worker only; no earlier or future app acceptance transfer.',
                     'Shown positions are app metadata, not independently decoded source-pixel identity for every frame.',
                     'The explicit steady exclusions do not replace raw full-epoch startup/EOF observations.',
                     'App width/height are the actual surface, not monitor viewport size.',
                     'Full-epoch device drift includes startup offset; steady interval is the clock-rate observation.',
                     'Unique cadence permits recorded skips; no zero-drop60fps or audible speaker/photon latency claim.'])
    with args.output.open('x',encoding='utf-8') as target:
        json.dump(result,target,indent=2)
        target.write('\n')
    print(json.dumps({k:result[k] for k in ('app_sha256','selected_epoch','full_first_epoch','provisional_steady_body','errors')},indent=2))


if __name__=='__main__':main()
