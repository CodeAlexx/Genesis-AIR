"""Private independent audible12-frame retry oracle. Decodes only when invoked.

Reference is original source + declared scalar math/TTF/FFmpeg audio graph;
Genesis rendered output is never an oracle input. No Genesis export command here.
"""
import argparse
import hashlib
import json
import math
import os
from pathlib import Path
import struct
import subprocess
import sys
import numpy as np
from PIL import Image,ImageDraw,ImageFont,ImageFilter

REPO=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(REPO/'tests'))
from media_runtime import tool
FLAGS=subprocess.CREATE_NO_WINDOW if os.name=='nt' else 0
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def run(args):
    r=subprocess.run(list(map(str,args)),capture_output=True,timeout=120,creationflags=FLAGS)
    assert r.returncode==0,(args,r.returncode,r.stderr[-4000:])
    return r.stdout
def f32(v):return struct.unpack('<f',struct.pack('<f',v))[0]
def advances(path,text,px):
    # Independent TrueType table reader: unhinted advance, no kerning, matching
    # declared renderer typography. Pillow is only the independent glyph raster.
    data=path.read_bytes();u16=lambda at:struct.unpack_from('>H',data,at)[0]
    u32=lambda at:struct.unpack_from('>I',data,at)[0]
    tables={data[12+i*16:16+i*16].decode():u32(20+i*16) for i in range(u16(4))}
    em=u16(tables['head']+18);metrics=u16(tables['hhea']+34);cmap=tables['cmap'];sub=None
    for i in range(u16(cmap+2)):
        at=cmap+u32(cmap+4+i*8+4)
        if u16(at)==4:sub=at;break
    assert sub is not None,'Independent ASCII cmap4 required'
    segments=u16(sub+6)//2;ends=sub+14;starts=ends+segments*2+2;deltas=starts+segments*2;offsets=deltas+segments*2
    values=[]
    for char in text:
        code=ord(char);gid=None
        for i in range(segments):
            if u16(starts+i*2)<=code<=u16(ends+i*2):
                delta=u16(deltas+i*2);off=u16(offsets+i*2)
                gid=(code+delta)&65535 if off==0 else u16(offsets+i*2+off+(code-u16(starts+i*2))*2)
                if off and gid:gid=(gid+delta)&65535
                break
        assert gid,'Missing independent glyph'
        values.append(u16(tables['hmtx']+min(gid,metrics-1)*4)*px/em)
    return values
def title_masks(font_path,text):
    size=48*1080/856;px=math.floor(size/.729+.5)
    face=ImageFont.truetype(str(font_path),px,layout_engine=ImageFont.Layout.BASIC)
    mask=Image.new('L',(1920,1080));draw=ImageDraw.Draw(mask)
    widths=advances(font_path,text,px);pen=960-sum(widths)/2;baseline=540+size
    # AIR's declared origin rule rounds each glyph pen/baseline to the nearest
    # integer via floor(value+.5). Keep unhinted advances; only origins round.
    for char,width in zip(text,widths):
        draw.text((math.floor(pen+.5),math.floor(baseline+.5)),char,font=face,anchor='ls',fill=255)
        pen+=width
    box=mask.getbbox();assert box
    # Two-pixel interior excludes anti-alias boundaries. A three-pixel square
    # erosion deletes the <=6px stems of the independently declared Segoe UI
    # 83px glyphs (13 pixels survive, versus 3404 with this fixed 5x5 kernel).
    # This construction was fixed before decoding any rendered output.
    core=np.asarray(mask.filter(ImageFilter.MinFilter(5)))>=250
    assert core.sum()>=500,'Insufficient independent title interior'
    outside=np.ones((1080,1920),dtype=bool)
    x0,y0,x1,y1=box;outside[max(0,y0-32):min(1080,y1+34),max(0,x0-32):min(1920,x1+34)]=False
    return core,outside,dict(font_px=px,baseline=baseline,rounded_baseline=math.floor(baseline+.5),
        glyph_origin_rule='floor(pen+.5),floor(baseline+.5); unhinted advances, no kerning',
        interior_margin_pixels=2,interior_kernel=5,
        bbox=box,core_pixels=int(core.sum()),outside_pixels=int(outside.sum()))
def declarations(doc,source_frame):
    assert source_frame==600,'Audible reference was declared only for source frames600..611'
    video=next(c for c in doc['clips'] if c['id']==1000);sound=next(c for c in doc['clips'] if c['id']==1001)
    source=next(s for s in doc['sources'] if s['id']==video['source'])
    for c in (video,sound):assert c['owner']==2 and c['start']==0 and c['source_in']==source_frame and c['length']==120 and c['speed']==1 and not c['reverse'] and c['enabled']
    assert sound['source']==video['source'] and source['fps']==60
    vf=sorted([f for f in doc['filters'] if f['clip']==1000 and f['enabled']],key=lambda f:f['order'])
    assert [(f['id'],f['kind']) for f in vf]==[(100001,'contrast'),(100000,'brightness'),(100002,'text')]
    params={(p['filter'],p['name']):p['value'] for p in doc['filter_params']}
    for key,wanted in [((100001,'level'),1.1),((100000,'level'),1.05),((100002,'size'),48),((100002,'x'),0),((100002,'y'),0),((200000,'threshold'),-12)]:assert params[key]==wanted,(key,params[key])
    text=next(p['value'] for p in doc['filter_text_params'] if p['filter']==100002 and p['name']=='content');assert text=='PRIVATE EDIT CONFIRMED'
    names=doc['names'];keys=[k for k in doc['keys'] if k['clip']==1001]
    assert len(keys)==8 and all(names[k['param']-1]=='gain' and k['value']==.85 and k['interp']==2 for k in keys)
    video_keys=[k for k in doc['keys'] if k['clip']==1000]
    assert len(video_keys)==8 and all(names[k['param']-1]=='opacity' and k['value']==1 and k['interp']==2 for k in video_keys)
    assert sorted(k['frame'] for k in keys)==sorted(k['frame'] for k in video_keys)==[0,8,16,32,48,64,96,119]
    assert [f['kind'] for f in doc['filters'] if f['clip']==1001 and f['enabled']]==['compressor']
    tracks={t['id']:t for t in doc['tracks']}
    assert tracks[video['track']]['gain']==0 and tracks[sound['track']]['gain']==.8
    active=[c for c in doc['clips'] if c['owner']==2 and c['enabled'] and c['start']<12 and c['start']+c['length']>0]
    assert sorted(c['id'] for c in active)==[1000,1001]
    assert not any(t['muted'] or t['solo'] for t in tracks.values())
    assert video['fade_in']==video['fade_out']==sound['fade_in']==sound['fade_out']==0
    assert video['pan']==sound['pan']==tracks[sound['track']]['pan']==0
    assert all(params.get((200000,k),v)==v for k,v in [('ratio',4),('attack',10),('release',120)])
    allowed={100000:{'level'},100001:{'level'},100002:{'size','x','y'},200000:{'threshold','ratio','attack','release'}}
    assert all(name in allowed[ident] for (ident,name) in params if ident in allowed),'Unexpected first-pair filter parameter'
    return Path(source['path']),text

def audio_reference_chain(source_frame):
    assert source_frame==600
    start=source_frame*44100//60;end=(source_frame+12)*44100//60
    return f'atrim=start_sample={start}:end_sample={end},asetpts=N/SR/TB,aresample=48000,aformat=sample_fmts=flt:sample_rates=48000:channel_layouts=stereo,acompressor=threshold=0.251188643150958:ratio=4:attack=10:release=120,aformat=sample_fmts=flt:sample_rates=48000:channel_layouts=stereo'
def main():
    p=argparse.ArgumentParser();p.add_argument('--project',type=Path,required=True);p.add_argument('--movie',type=Path,required=True);p.add_argument('--worker',type=Path,required=True);p.add_argument('--font',type=Path,default=Path('C:/Windows/Fonts/segoeui.ttf'));p.add_argument('--report',type=Path,required=True);p.add_argument('--source-frame',type=int,required=True,choices=[600])
    args=p.parse_args();doc=json.loads(args.project.read_text(encoding='utf-8-sig'));source,text=declarations(doc,args.source_frame)
    before={k:sha(v) for k,v in [('project',args.project),('source',source),('movie',args.movie),('worker',args.worker),('font',args.font)]}
    report=dict(schema='genesis.private.original-source-export-oracle',passed=False,hashes_before=before,
        declared_source_frame=args.source_frame,declared_source_native_sample_interval=[441000,449820],
        thresholds=dict(outside_mean_rgb=3/255,outside_p95_rgb=8/255,outside_p99_rgb=18/255,
            correct_order_mean_advantage=.25/255,title_observable_white_coverage=.93,
            aac_zero_lag_correlation=.99,aac_relative_rmse=.10,aac_additive_rms_floor=.0003))
    try:
        ffmpeg=tool(args.worker,'ffmpeg');probe=tool(args.worker,'ffprobe')
        streams=json.loads(run([probe,'-v','error','-show_streams','-of','json',args.movie]))['streams']
        v=next(s for s in streams if s['codec_type']=='video');a=next(s for s in streams if s['codec_type']=='audio')
        assert (v['width'],v['height'],v['codec_name'],v['r_frame_rate'])==(1920,1080,'h264','60/1'),v
        assert a['codec_name']=='aac' and int(a['sample_rate'])==48000 and a['channels']==2,a
        original=run([ffmpeg,'-nostdin','-v','error','-i',source,'-map','0:v:0','-vf',f'trim=start_frame={args.source_frame}:end_frame={args.source_frame+12},setpts=PTS-STARTPTS','-frames:v','12','-fps_mode','passthrough','-pix_fmt','rgb48le','-f','rawvideo','pipe:1'])
        rendered=run([ffmpeg,'-nostdin','-v','error','-i',args.movie,'-map','0:v:0','-pix_fmt','rgb48le','-f','rawvideo','pipe:1'])
        assert len(original)==len(rendered)==12*1920*1080*6,(len(original),len(rendered))
        raw=np.frombuffer(original,dtype='<u2').reshape(12,1080,1920,3);actual=np.frombuffer(rendered,dtype='<u2').reshape(raw.shape)
        core,outside,title=title_masks(args.font,text);checks=[]
        for frame in range(12):
            x=raw[frame].astype(np.float32)/65535;got=actual[frame].astype(np.float32)/65535
            expected=np.clip(np.clip((x-.5)*1.1+.5,0,1)+.05,0,1)
            wrong=np.clip((np.clip(x+.05,0,1)-.5)*1.1+.5,0,1)
            delta=np.abs(got[outside]-expected[outside]);mean=float(delta.mean());p95,p99=map(float,np.quantile(delta,[.95,.99]))
            advantage=float(np.abs(got[outside]-wrong[outside]).mean())-mean
            observable=core&(expected.max(axis=2)<.8);assert observable.sum()>=300
            coverage=float((got[observable].min(axis=1)>=.90).mean())
            checks.append(dict(frame=frame,source_frame=args.source_frame+frame,outside_mean_error=mean,outside_p95_error=p95,outside_p99_error=p99,
                correct_order_mean_advantage=advantage,title_observable_pixels=int(observable.sum()),title_white_coverage=coverage))
            assert mean<=3/255 and p95<=8/255 and p99<=18/255,checks[-1]
            assert advantage>=.25/255,('Grade order not independently distinguished',checks[-1])
            assert coverage>=.93,('Edited title glyph coverage absent/misaligned',checks[-1])
        chain=audio_reference_chain(args.source_frame)
        reference=np.frombuffer(run([ffmpeg,'-nostdin','-v','error','-i',source,'-map','0:a:0','-af',chain,'-t','0.2','-f','f32le','pipe:1']),dtype='<f4').copy()
        assert reference.size==19200,reference.size
        reference=np.clip(reference*f32(f32(.8)*f32(.85)),-1,1)
        decoded=np.frombuffer(run([ffmpeg,'-nostdin','-v','error','-i',args.movie,'-map','0:a:0','-f','f32le','pipe:1']),dtype='<f4')
        assert 19200<=decoded.size<=19200+4096,decoded.size
        aligned=decoded[:19200];rms=float(np.sqrt(np.mean(reference.astype(np.float64)**2)));got_rms=float(np.sqrt(np.mean(aligned.astype(np.float64)**2)))
        assert rms>.00003 and got_rms>.00003,'No meaningful audible-source content in authored export range'
        corr=float(np.dot(reference.astype(np.float64),aligned.astype(np.float64))/(np.linalg.norm(reference.astype(np.float64))*np.linalg.norm(aligned.astype(np.float64))))
        error=float(np.sqrt(np.mean((aligned.astype(np.float64)-reference.astype(np.float64))**2)))
        assert corr>=.99 and error<=.10*rms+.0003,(corr,error,rms)
        report.update(passed=True,video_frames=12,authored_source_frames=list(range(args.source_frame,args.source_frame+12)),outside_video_checks=checks,title=title,
            audio=dict(reference_sample_frames=9600,decoded_sample_frames=decoded.size//2,source_native_samples=8820,
                compressor_threshold_db=-12,key_gain=.85,track_gain=.8,rms_reference=rms,rms_actual=got_rms,
                zero_sample_shift_correlation=corr,rmse=error,aac_padding_sample_frames=decoded.size//2-9600),
            limitations=['Broad outside-title scalar math + independent glyph interiors, not exact anti-alias raster parity.',
                'AAC320kbps lossy reference thresholds fixed before execution; no output-derived compensation or shift alignment.',
                'Source decoded from origin; independently selected frames600..611/native samples441000..449819 only. No timing/device/whole-project render performance claim.'])
        after={k:sha(v) for k,v in [('project',args.project),('source',source),('movie',args.movie),('worker',args.worker),('font',args.font)]};assert before==after
        report.update(hashes_after=after,inputs_immutable=True)
    except BaseException as e:report['error']=repr(e);raise
    finally:
        args.report.parent.mkdir(parents=True,exist_ok=True)
        with args.report.open('x',encoding='utf-8') as f:json.dump(report,f,indent=2)
    print(json.dumps(dict(passed=True,video_frames=12,aac_correlation=report['audio']['zero_sample_shift_correlation'])))
if __name__=='__main__':main()
