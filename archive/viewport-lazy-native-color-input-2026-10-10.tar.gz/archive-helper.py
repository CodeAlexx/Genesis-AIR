"""Prepare the final archive only after explicit publication/gate/UI receipts.

Authoring this helper does not create an archive. --list-inputs prints its
contract without reading payloads or running any application/media process.
"""
import argparse
import gzip
import hashlib
import io
import json
from pathlib import Path
import re
import tarfile

ROOT=Path(__file__).resolve().parent.parent
WORK=ROOT/'build-windows'
NAME='viewport-lazy-native-color-input-2026-10-10.tar.gz'
TEXT_SUFFIXES={'.ai','.py','.ps1','.md','.txt','.log','.json','.cmake','.patch',
               '.conf','.c','.h','.hlsl','.def','.rs','.copying','.air','.sh','.tsv'}
FIXED_REPORTS=[
    'viewport-hdr-full-windows.log',
    'viewport-hdr-strict-fault-final.json','viewport-hdr-strict-fault-final.log',
    'viewport-hdr-ledger-final.log','viewport-hdr-real4k-final.json',
    'viewport-hdr-real4k-final.log','bounded-real-aac-final.log',
    'aac-real-source-proof-final.py','viewport-hdr-1080p-device-final.json',
    'viewport-hdr-1080p-device-final.log','strip-viewport-tests.json',
    'lazy-gpu.json','native-hdr-color.json','native-hdr-runtime.log',
    'timeline-track-scroll-tests.json','direct-waveforms.json',
    'nested-waveforms.json','audio-source-boundaries.json',
    'agent-lazy-gpu-provenance.json','agent-editing-native-color-lazy-guard-proof.log',
    'agent-editing-native-color-lazy-abba/comparison.json',
    'agent-editing-native-color-lazy-abba/baseline-a.json',
    'agent-editing-native-color-lazy-abba/baseline-b.json',
    'agent-editing-native-color-lazy-abba/native-color-a.json',
    'agent-editing-native-color-lazy-abba/native-color-b.json',
    'agent-playback-strip-viewport/check-final1/strip-viewport-tests.json',
    'agent-playback-large-native-ui/fixture/authoring.json',
    'agent-playback-large-native-ui/prepare.py',
    'agent-playback-large-native-ui/PLAN.md',
]
REQUIRED_FINAL_SOURCE=['src/main.ai','src/app.ai','src/input.ai','src/view.ai',
    'src/preview.ai','tests/inspector.ai','tests/strip_viewport.ai',
    'tests/worker_wrapper.c','windows/gcompose-windows.patch',
    'windows/native-hdr.c','windows/native-hdr.hlsl','windows/native-hdr-runtime.c',
    'patches/air-ui-text-windows.patch','tests/ui_clipboard_windows.c']

def sha(data):return hashlib.sha256(data).hexdigest()

def digest(path):
    result=hashlib.sha256()
    with path.open('rb') as source:
        for block in iter(lambda:source.read(1048576),b''):result.update(block)
    return result.hexdigest()

def sanitize(raw):
    text=raw.decode('utf-8-sig')
    root_spellings=[str(ROOT).replace('\\','\\\\'),str(ROOT),ROOT.as_posix(),
                    '/mnt/c'+ROOT.as_posix()[2:]]
    for spelling in root_spellings:
        text=re.sub(re.escape(spelling),'<REPO>',text,flags=re.I)
    text=re.sub(r'c:[\\/]+users[\\/]+alexn','<USER>',text,flags=re.I)
    text=re.sub(r'<USER_WSL>','<USER_WSL>',text,flags=re.I)
    assert not re.search(r'c:[\\/]+users[\\/]+alexn',text,re.I)
    return text.encode('utf-8')

def local(path):
    path=Path(path)
    return (ROOT/path).resolve() if not path.is_absolute() else path.resolve()

def source_paths():
    paths=[ROOT/n for n in ('.gitignore','README.md','air-sdk.conf','build-windows.ps1',
            'setup-windows.ps1','build.sh','patches/air-editor.patch',
            'patches/air-process-wait-windows.patch','patches/air-ui-text-windows.patch',
            'docs/CONTROL_COVERAGE.md','docs/FFMPEG_GPU_PREVIEW.md')]
    for directory in ('src','tests','windows'):
        paths += [p for p in sorted((ROOT/directory).iterdir())
                  if p.is_file() and p.suffix.lower() in TEXT_SUFFIXES]
    return sorted(set(paths))

def source_mapping(value):
    for field in ('frozen_source','validated_worktree_sha256','worktree_source_sha256'):
        if field in value:return value[field]
    if value and all(isinstance(h,str) and re.fullmatch('[0-9a-fA-F]{64}',h)
                     for h in value.values()):return value
    raise ValueError('Source receipt must contain exact tested worktree hashes')

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--list-inputs',action='store_true')
    parser.add_argument('--publication',type=Path)
    parser.add_argument('--source-receipt',type=Path)
    parser.add_argument('--initial-source-receipt',type=Path)
    parser.add_argument('--final-gate',type=Path)
    parser.add_argument('--ui-receipt',type=Path)
    parser.add_argument('--analysis',type=Path,action='append',default=[])
    parser.add_argument('--proof',action='append',default=[],metavar='ROLE=FILE')
    parser.add_argument('--output',type=Path,default=ROOT/'archive'/NAME)
    parser.add_argument('--receipt',type=Path,default=WORK/'viewport-lazy-native-color-input-bundle-receipt.json')
    args=parser.parse_args()
    if args.list_inputs:
        print(json.dumps(dict(required_arguments=['publication','source-receipt',
             'initial-source-receipt','final-gate','ui-receipt','one-or-more analysis'],
             publication_contract='root_binaries map of relative filename to SHA256; exact published files verified',
             source_contract='frozen_source/validated_worktree_sha256/worktree_source_sha256 or raw relative-path SHA256 map',
             ui_contract='passed=true or complete=true; scope/limitations retained verbatim',
             extra_proof='Repeat --proof ROLE=FILE for final inspector/input/save/export/provenance receipts',
             fixed_reports=FIXED_REPORTS,required_final_source=REQUIRED_FINAL_SOURCE,
             current_sources=[p.relative_to(ROOT).as_posix() for p in source_paths()],
             archive=NAME,not_executed='No archives, UI or media jobs created by --list-inputs'),indent=2))
        return
    for field in ('publication','source_receipt','initial_source_receipt','final_gate','ui_receipt'):
        if getattr(args,field) is None:parser.error('--'+field.replace('_','-')+' is required')
    if not args.analysis:parser.error('At least one explicit --analysis is required')
    publication_path=local(args.publication)
    publication=json.loads(publication_path.read_text(encoding='utf-8-sig'))
    hashes=publication.get('root_binaries')
    assert isinstance(hashes,dict) and 'Genesis-AIR.exe' in hashes and 'genesis-gcompose.exe' in hashes
    for name,expected in hashes.items():
        relative=Path(name)
        assert not relative.is_absolute() and '..' not in relative.parts
        assert digest(ROOT/relative).lower()==expected.lower(),name
    for flag in ('published','passed','complete'):
        if flag in publication:assert publication[flag] is True,flag
    runtime_hash=publication.get('runtime_sha256')
    if runtime_hash is not None:
        assert digest(ROOT/'genesis-media-runtime.txt').lower()==runtime_hash.lower(),'published runtime manifest changed'
    frozen_path=local(args.source_receipt)
    frozen=source_mapping(json.loads(frozen_path.read_text(encoding='utf-8-sig')))
    for name in REQUIRED_FINAL_SOURCE:assert name in frozen,('missing final source proof',name)
    for name,expected in frozen.items():
        candidate=local(name)
        assert candidate.is_relative_to(ROOT),name
        assert digest(candidate).lower()==expected.lower(),('source changed since final validation',name)
    gate_path=local(args.final_gate)
    gate=gate_path.read_text(encoding='utf-8-sig')
    assert 'Real Windows media/Unicode paths, source/program preview and failure exit codes passed.' in gate
    ui_path=local(args.ui_receipt)
    ui=json.loads(ui_path.read_text(encoding='utf-8-sig'))
    assert ui.get('passed') is True or ui.get('complete') is True,'UI receipt must explicitly affirm its bounded scope'
    archive=local(args.output);receipt=local(args.receipt)
    assert archive.parent==ROOT/'archive' and archive.name==NAME
    assert receipt.is_relative_to(WORK)
    assert not archive.exists() and not receipt.exists(),'Preserve previous archives/receipts'
    entries={};provenance={}
    def add(name,path,role):
        path=local(path)
        assert path.is_file() and (path.suffix.lower() in TEXT_SUFFIXES or path.name=='.gitignore'),('text-only archive boundary',path)
        assert not name.startswith('/') and '..' not in Path(name).parts
        assert name not in entries,('duplicate archive member',name)
        raw=path.read_bytes();entries[name]=sanitize(raw)
        provenance[name]=dict(original_sha256=sha(raw),sanitized_sha256=sha(entries[name]),
            original_bytes=len(raw),role=role)
    for path in source_paths():add('source/'+path.relative_to(ROOT).as_posix(),path,'current maintained source; raw hash retained')
    for name in FIXED_REPORTS:add('evidence/'+name,WORK/name,'original stage receipt; original app/worker/source scope preserved')
    add('final/publication.json',publication_path,'verified published root payload')
    if runtime_hash is not None:
        add('final/shared-runtime.txt',ROOT/'genesis-media-runtime.txt','verified shared MM-AIR location manifest; no codec files included')
    add('final/tested-source.json',frozen_path,'exact final tested source hashes')
    add('initial/tested-source.json',args.initial_source_receipt,'initial AD8985 source fingerprints; not relabeled as final')
    add('final/windows.log',gate_path,'explicit final acceptance log; full-suite and targeted identities are preserved in publication and gate receipts')
    add('final/native-ui.json',ui_path,'explicit final bounded native UI receipt')
    for index,path in enumerate(args.analysis):
        add(f'native-profiles/analysis-{index}.json',path,'actual native profile analysis; exclusions preserved')
    for value in args.proof:
        role,separator,path=value.partition('=')
        assert separator and re.fullmatch(r'[A-Za-z0-9_-]{1,96}',role),value
        suffix=local(path).suffix.lower()
        add('additional/'+role+suffix,path,'explicit additional evidence: '+role)
    add('archive-helper.py',Path(__file__),'exact archive helper')
    manifest=dict(schema='genesis.viewport_lazy_hdr_input_acceptance.v1',
        final_root_binaries=hashes,validated_worktree_sha256=frozen,
        current_source_lf_sha256={p.relative_to(ROOT).as_posix():sha(p.read_bytes().replace(b'\r\n',b'\n'))
                                  for p in source_paths()},
        normalized_hash_scope='LF hashes identify Git source bytes; exact tested worktree hashes are separate',
        archive_entries=provenance,initial_candidate_app_sha256='AD8985B4311EA74A673A615893B9ADE3491C065575AF97F518E909CE0ED7A5EC',
        initial_candidate_worker_sha256='378685335B4C17AE44B5A03C892F0008B85C172CFBE6EA57FB20339BB377552F',
        historical_evidence='Original receipt identities/scopes unchanged; current source is the final validated revision, not every historical prototype',
        complete_professional_editing_acceptance=False,
        limitations=['No fullscreen4K or sustained compound4K60 acceptance',
                     'Native source-pixel and physical speaker/photon alignment remain separately bounded',
                     'QA pixels/media/codec DLLs and application binaries excluded'],
        ui_scope=ui.get('scope'),ui_limitations=ui.get('limitations'),
        archived_ui_success_means='Only the explicit receipt scope; not complete professional editing')
    entries['manifest.json']=(json.dumps(manifest,indent=2)+'\n').encode('utf-8')
    archive.parent.mkdir(parents=True,exist_ok=True)
    # Exclusive creation never replaces an earlier acceptance archive.
    with archive.open('xb') as target:
        with gzip.GzipFile(fileobj=target,mode='wb',filename='',mtime=0) as compressed:
            with tarfile.open(fileobj=compressed,mode='w') as bundle:
                for name,data in sorted(entries.items()):
                    member=tarfile.TarInfo(name);member.size=len(data);member.mtime=0;member.mode=0o644
                    bundle.addfile(member,io.BytesIO(data))
    with tarfile.open(archive,'r:gz') as bundle:
        assert sorted(bundle.getnames())==sorted(entries)
        for member in bundle:
            actual=bundle.extractfile(member).read()
            assert actual==entries[member.name]
            if member.name!='manifest.json':assert sha(actual)==provenance[member.name]['sanitized_sha256']
        checked=json.loads(bundle.extractfile('manifest.json').read())
        assert checked==manifest
    result=dict(archive=archive.relative_to(ROOT).as_posix(),sha256=digest(archive),
        entries=len(entries),sanitized=True,every_entry_read_back=True,
        root_payload_verified=True,final_sources_verified=True,
        source_receipt_sha256=digest(frozen_path),publication_receipt_sha256=digest(publication_path),
        complete_professional_editing_acceptance=False)
    with receipt.open('x',encoding='utf-8') as output:output.write(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result))

if __name__=='__main__':main()
