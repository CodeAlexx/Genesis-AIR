from pathlib import Path
import hashlib,json,subprocess,datetime
p=Path('build-windows/agent-present-immediate')
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
prior=json.loads((p/'proposal-receipt.json').read_text())
for name,b in prior['files'].items():
    assert sha(p/'private'/name)==b['candidate_sha256']
    assert sha(Path('build-windows/AIR-SDK/runtime/windows')/name)==b['baseline_bytes_sha256']
assert sha(p/'present-immediate.patch')==prior['patch_sha256']
reports={}
for mode in ('default','immediate'):
    d=json.loads((p/f'component-{mode}.json').read_text())
    assert d['passed'] and d['checks']==97 and d['compared_rgb_values']==2150400
    assert (p/f'component-{mode}.exit').read_text()=='0'
    reports[mode]=d
assert (p/'pixels.exit').read_text().strip()=='0'
files=['baseline/air_ui_presenter_win32.cpp','baseline/air_ui_presenter_win32.h','private/air_ui_presenter_win32.cpp','private/air_ui_presenter_win32.h','present-immediate.patch','proposal-receipt.json','CMakeLists.txt','derive-fixture.py','fixture-presenter.cpp','component.cpp','run-components.py','ui_pixels.c','air_ui_pixels.h','component-configure.log','component-build.log','pixels.log','native/Release/existing-ui-pixels.exe','native/Release/presenter-default.lib','native/Release/presenter-immediate.lib']
for mode in ('default','immediate'):
    files.extend([f'native/Release/component-{mode}.exe',f'component-{mode}.json',f'component-{mode}.stdout.log',f'component-{mode}.stderr.log',f'component-{mode}.exit'])
r={'schema':'genesis.private.immediate-present.components.v1','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'passed':True,'sdk_pin':prior['sdk_head'],'pinned_presenter_unchanged':True,'proposal_source_and_patch_unchanged':True,'proposal_lf_forward_reverse_roundtrip':prior['lf_forward_reverse_byte_roundtrip'],'production_candidate_deltas':['compile-time opt-in initial/recreated D2D flags','separate C actual mode/options metadata'],'sdk_default_unchanged':True,'test_only_instrumentation':['actual successful target creation flags recorded','one real successful EndDraw replaced by D2DERR_RECREATE_TARGET','create_target failure before API call for forced-vs-auto fallback'],'component_results':reports,'total_checks':sum(d['checks'] for d in reports.values()),'total_exact_rgb_values':sum(d['compared_rgb_values'] for d in reports.values()),'existing_no_window_gate':{'exit':0,'all_channel_alpha_pairs':65536,'rgb24_straight_rgba32_roworder_invalidbuffers':True,'copied_sdk_source_identical':sha(p/'ui_pixels.c')==sha(Path('build-windows/AIR-SDK/tests/stdlib/ui_pixels.c'))},'window_scope':'Own test HWND/client DC only; no user-app input, capture, settings changes or audio device','fixture_windows_closed':True,'no_console_runner':True,'physical_scanout_measured':False,'native_editor_cadence_measured':False,'limits':['D2D recreation injected after actual successful EndDraw, not an actual device-loss test','Private C++ component copies; full coherent AIR runtime/editor not qualified yet','Immediate submission does not prove physical display rate or every-frame scanout'],'files':{f:sha(p/f) for f in files}}
(p/'component-receipt.json').write_text(json.dumps(r,indent=2)+'\n')
print('receipt',sha(p/'component-receipt.json'))
print('privatecpp',sha(p/'private/air_ui_presenter_win32.cpp'))
print('patch',sha(p/'present-immediate.patch'))
print('default_exe',sha(p/'native/Release/component-default.exe'))
print('immediate_exe',sha(p/'native/Release/component-immediate.exe'))
