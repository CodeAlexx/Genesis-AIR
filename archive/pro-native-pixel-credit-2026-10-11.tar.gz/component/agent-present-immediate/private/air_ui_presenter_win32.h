#ifndef AIR_UI_PRESENTER_WIN32_H
#define AIR_UI_PRESENTER_WIN32_H

#include <windows.h>

#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef struct air_ui_presenter air_ui_presenter;

/*
 * Windows window/input ownership stays in air_ui_win32.c. Rendering is a
 * replaceable presenter selected here so Direct2D, a future D3D renderer, and
 * test/fallback drivers consume the same normalized opaque BGRA frame.
 */
air_ui_presenter *air_ui_presenter_create(HWND window, uint32_t width, uint32_t height);
void air_ui_presenter_destroy(air_ui_presenter *presenter);
int air_ui_presenter_resize(air_ui_presenter *presenter, uint32_t width, uint32_t height);
int air_ui_presenter_present(air_ui_presenter *presenter, const uint8_t *bgra,
                             uint32_t width, uint32_t height);
void air_ui_presenter_paint(air_ui_presenter *presenter, HDC paint_dc);
const char *air_ui_presenter_driver(const air_ui_presenter *presenter);
/* Actual mode/flags of this instance, including auto-GDI fallback; not a timing claim.
 * D2D flags0 = refresh-wait(default), flags2 = compile-time opt-in immediate.
 * UINT32_MAX means no Direct2D presentation options (GDI or no instance). */
const char *air_ui_presenter_mode(const air_ui_presenter *presenter);
uint32_t air_ui_presenter_present_options(const air_ui_presenter *presenter);

#ifdef __cplusplus
}
#endif

#endif
