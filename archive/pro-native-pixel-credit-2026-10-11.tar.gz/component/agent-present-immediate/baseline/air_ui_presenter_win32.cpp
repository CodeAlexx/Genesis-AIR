#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#include <windows.h>

#include <d2d1.h>
#include <wrl/client.h>

#include <algorithm>
#include <cstdint>
#include <cstring>
#include <cwctype>
#include <iterator>
#include <memory>
#include <new>
#include <stdexcept>
#include <string>
#include <vector>

#include "air_ui_presenter_win32.h"

using Microsoft::WRL::ComPtr;

namespace {

class Presenter {
public:
    virtual ~Presenter() = default;
    virtual bool resize(std::uint32_t width, std::uint32_t height) = 0;
    virtual bool present(const std::uint8_t *bgra, std::uint32_t width,
                         std::uint32_t height) = 0;
    virtual void paint(HDC paint_dc) = 0;
    virtual const char *driver() const = 0;
};

class Direct2dPresenter final : public Presenter {
public:
    Direct2dPresenter(HWND window, std::uint32_t width, std::uint32_t height)
        : window_(window), target_width_(nonzero(width)), target_height_(nonzero(height)) {
        const HRESULT factory_result = D2D1CreateFactory(
            D2D1_FACTORY_TYPE_SINGLE_THREADED, factory_.GetAddressOf());
        if (FAILED(factory_result)) throw std::runtime_error("D2D1CreateFactory failed");
        if (!create_target()) throw std::runtime_error("Direct2D window target failed");
    }

    bool resize(std::uint32_t width, std::uint32_t height) override {
        target_width_ = nonzero(width);
        target_height_ = nonzero(height);
        if (!target_ && !create_target()) return false;
        const HRESULT result = target_->Resize(D2D1::SizeU(target_width_, target_height_));
        if (result == D2DERR_RECREATE_TARGET) return recreate_target();
        return SUCCEEDED(result);
    }

    bool present(const std::uint8_t *bgra, std::uint32_t width,
                 std::uint32_t height) override {
        if (bgra == nullptr || width == 0u || height == 0u) return false;
        const std::uint64_t count = static_cast<std::uint64_t>(width) * height;
        if (count > static_cast<std::uint64_t>(SIZE_MAX) / 4u) return false;
        pixels_.resize(static_cast<std::size_t>(count * 4u));
        std::memcpy(pixels_.data(), bgra, static_cast<std::size_t>(count * 4u));
        source_width_ = width;
        source_height_ = height;
        if (!upload()) return false;
        return draw();
    }

    void paint(HDC paint_dc) override {
        (void)paint_dc;
        (void)draw();
    }

    const char *driver() const override { return "direct2d"; }

private:
    static std::uint32_t nonzero(std::uint32_t value) { return value == 0u ? 1u : value; }

    bool create_target() {
        if (!factory_) return false;
        const D2D1_RENDER_TARGET_PROPERTIES properties = D2D1::RenderTargetProperties();
        const D2D1_HWND_RENDER_TARGET_PROPERTIES window_properties =
            D2D1::HwndRenderTargetProperties(
                window_, D2D1::SizeU(target_width_, target_height_), D2D1_PRESENT_OPTIONS_NONE);
        const HRESULT result = factory_->CreateHwndRenderTarget(
            properties, window_properties, target_.ReleaseAndGetAddressOf());
        // AIR canvas dimensions and RGB buffers are physical client pixels. Direct2D uses
        // device-independent pixels and otherwise inherits the monitor DPI, which makes a
        // 1600-pixel frame occupy 2800 physical pixels at 175% scaling. Pinning the target
        // to 96 DPI keeps one AIR canvas unit equal to one client pixel on every monitor.
        if (SUCCEEDED(result)) target_->SetDpi(96.0f, 96.0f);
        return SUCCEEDED(result);
    }

    bool recreate_target() {
        bitmap_.Reset();
        target_.Reset();
        if (!create_target()) return false;
        return pixels_.empty() || upload();
    }

    bool upload() {
        if (!target_ && !create_target()) return false;
        if (source_width_ == 0u || source_height_ == 0u || pixels_.empty()) return true;
        if (bitmap_) {
            const D2D1_SIZE_U size = bitmap_->GetPixelSize();
            if (size.width == source_width_ && size.height == source_height_) {
                const HRESULT copied =
                    bitmap_->CopyFromMemory(nullptr, pixels_.data(), source_width_ * 4u);
                if (SUCCEEDED(copied)) return true;
            }
            bitmap_.Reset();
        }
        const D2D1_BITMAP_PROPERTIES properties = D2D1::BitmapProperties(
            D2D1::PixelFormat(DXGI_FORMAT_B8G8R8A8_UNORM, D2D1_ALPHA_MODE_IGNORE),
            96.0f, 96.0f);
        const HRESULT result = target_->CreateBitmap(
            D2D1::SizeU(source_width_, source_height_), pixels_.data(), source_width_ * 4u,
            properties, bitmap_.ReleaseAndGetAddressOf());
        return SUCCEEDED(result);
    }

    bool draw() {
        if (!target_ && !recreate_target()) return false;
        target_->BeginDraw();
        target_->Clear(D2D1::ColorF(D2D1::ColorF::Black));
        if (bitmap_) {
            const D2D1_RECT_F destination = D2D1::RectF(
                0.0f, 0.0f, static_cast<float>(target_width_), static_cast<float>(target_height_));
            target_->DrawBitmap(bitmap_.Get(), destination, 1.0f,
                                D2D1_BITMAP_INTERPOLATION_MODE_LINEAR);
        }
        const HRESULT result = target_->EndDraw();
        if (result == D2DERR_RECREATE_TARGET) {
            if (!recreate_target()) return false;
            target_->BeginDraw();
            target_->Clear(D2D1::ColorF(D2D1::ColorF::Black));
            if (bitmap_) {
                const D2D1_RECT_F destination = D2D1::RectF(
                    0.0f, 0.0f, static_cast<float>(target_width_),
                    static_cast<float>(target_height_));
                target_->DrawBitmap(bitmap_.Get(), destination, 1.0f,
                                    D2D1_BITMAP_INTERPOLATION_MODE_LINEAR);
            }
            return SUCCEEDED(target_->EndDraw());
        }
        return SUCCEEDED(result);
    }

    HWND window_ = nullptr;
    std::uint32_t target_width_ = 1u;
    std::uint32_t target_height_ = 1u;
    std::uint32_t source_width_ = 0u;
    std::uint32_t source_height_ = 0u;
    std::vector<std::uint8_t> pixels_;
    ComPtr<ID2D1Factory> factory_;
    ComPtr<ID2D1HwndRenderTarget> target_;
    ComPtr<ID2D1Bitmap> bitmap_;
};

class GdiPresenter final : public Presenter {
public:
    GdiPresenter(HWND window, std::uint32_t width, std::uint32_t height)
        : window_(window), target_width_(width), target_height_(height) {}

    bool resize(std::uint32_t width, std::uint32_t height) override {
        target_width_ = width;
        target_height_ = height;
        return true;
    }

    bool present(const std::uint8_t *bgra, std::uint32_t width,
                 std::uint32_t height) override {
        if (bgra == nullptr || width == 0u || height == 0u) return false;
        const std::uint64_t count = static_cast<std::uint64_t>(width) * height;
        if (count > static_cast<std::uint64_t>(SIZE_MAX) / 4u) return false;
        pixels_.resize(static_cast<std::size_t>(count * 4u));
        std::memcpy(pixels_.data(), bgra, static_cast<std::size_t>(count * 4u));
        source_width_ = width;
        source_height_ = height;
        std::memset(&bitmap_, 0, sizeof(bitmap_));
        bitmap_.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
        bitmap_.bmiHeader.biWidth = static_cast<LONG>(width);
        bitmap_.bmiHeader.biHeight = -static_cast<LONG>(height);
        bitmap_.bmiHeader.biPlanes = 1u;
        bitmap_.bmiHeader.biBitCount = 32u;
        bitmap_.bmiHeader.biCompression = BI_RGB;
        HDC dc = GetDC(window_);
        if (dc == nullptr) return false;
        paint(dc);
        (void)ReleaseDC(window_, dc);
        return true;
    }

    void paint(HDC paint_dc) override {
        if (paint_dc == nullptr) return;
        RECT client = {};
        if (pixels_.empty() || source_width_ == 0u || source_height_ == 0u ||
            !GetClientRect(window_, &client)) {
            (void)FillRect(paint_dc, &client, static_cast<HBRUSH>(GetStockObject(BLACK_BRUSH)));
            return;
        }
        (void)StretchDIBits(paint_dc, 0, 0, client.right - client.left, client.bottom - client.top,
                            0, 0, static_cast<int>(source_width_),
                            static_cast<int>(source_height_), pixels_.data(), &bitmap_,
                            DIB_RGB_COLORS, SRCCOPY);
    }

    const char *driver() const override { return "gdi"; }

private:
    HWND window_ = nullptr;
    std::uint32_t target_width_ = 0u;
    std::uint32_t target_height_ = 0u;
    std::uint32_t source_width_ = 0u;
    std::uint32_t source_height_ = 0u;
    std::vector<std::uint8_t> pixels_;
    BITMAPINFO bitmap_ = {};
};

std::wstring requested_driver() {
    wchar_t value[32] = {};
    const DWORD length = GetEnvironmentVariableW(L"AIR_UI_DRIVER", value,
                                                  static_cast<DWORD>(std::size(value)));
    if (length == 0u || length >= std::size(value)) return std::wstring();
    std::wstring result(value, length);
    std::transform(result.begin(), result.end(), result.begin(),
                   [](wchar_t character) { return static_cast<wchar_t>(towlower(character)); });
    return result;
}

} // namespace

struct air_ui_presenter {
    std::unique_ptr<Presenter> implementation;
};

extern "C" air_ui_presenter *air_ui_presenter_create(HWND window, std::uint32_t width,
                                                       std::uint32_t height) {
    if (window == nullptr) return nullptr;
    try {
        const std::wstring choice = requested_driver();
        auto presenter = std::make_unique<air_ui_presenter>();
        if (choice == L"gdi") {
            presenter->implementation = std::make_unique<GdiPresenter>(window, width, height);
        } else if (choice.empty() || choice == L"direct2d" || choice == L"directx") {
            try {
                presenter->implementation =
                    std::make_unique<Direct2dPresenter>(window, width, height);
            } catch (const std::exception &) {
                if (!choice.empty()) return nullptr;
                presenter->implementation = std::make_unique<GdiPresenter>(window, width, height);
            }
        } else {
            return nullptr;
        }
        return presenter.release();
    } catch (const std::exception &) {
        return nullptr;
    }
}

extern "C" void air_ui_presenter_destroy(air_ui_presenter *presenter) { delete presenter; }

extern "C" int air_ui_presenter_resize(air_ui_presenter *presenter, std::uint32_t width,
                                        std::uint32_t height) {
    return presenter != nullptr && presenter->implementation != nullptr &&
                   presenter->implementation->resize(width, height)
               ? 1
               : 0;
}

extern "C" int air_ui_presenter_present(air_ui_presenter *presenter, const std::uint8_t *bgra,
                                         std::uint32_t width, std::uint32_t height) {
    return presenter != nullptr && presenter->implementation != nullptr &&
                   presenter->implementation->present(bgra, width, height)
               ? 1
               : 0;
}

extern "C" void air_ui_presenter_paint(air_ui_presenter *presenter, HDC paint_dc) {
    if (presenter != nullptr && presenter->implementation != nullptr)
        presenter->implementation->paint(paint_dc);
}

extern "C" const char *air_ui_presenter_driver(const air_ui_presenter *presenter) {
    if (presenter == nullptr || presenter->implementation == nullptr) return "none";
    return presenter->implementation->driver();
}
