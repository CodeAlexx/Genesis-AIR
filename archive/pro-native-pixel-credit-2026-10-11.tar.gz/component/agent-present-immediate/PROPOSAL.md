Private immediate presentation prototype
========================================

Production candidate changes two copied presenter files only. `driver()` stays
`direct2d` / `gdi`, preserving existing SDK tests. The compile definition
`AIR_WIN32_CANVAS_PRESENT_IMMEDIATE=1` selects `D2D1_PRESENT_OPTIONS_IMMEDIATELY`;
undefined or zero selects the existing `D2D1_PRESENT_OPTIONS_NONE`. All initial
and recreated targets use the sole `create_target()` property construction.
Uploads, DPI, resource ownership, error recovery and GDI fallback remain intact.

Separate C component accessors report this presenter's actual driver and
configured mode/options. A GDI fallback reports `gdi`, `not-applicable`,
`UINT32_MAX`, so the requested compile option never masquerades as actual D2D.
There is no AIR metadata/logging subsystem. At editor level, compiled requested
mode and actual driver must remain separate until a runtime query is available.

Proposed isolated Genesis integration (not applied):

    cmake_language(DEFER CALL target_compile_definitions air_rt PRIVATE
      AIR_WIN32_CANVAS_PRESENT_IMMEDIATE=1)

This belongs to that product's isolated graph in `windows/configure.cmake`, not
the SDK default. Every runtime used by the candidate must be rebuilt coherently.

Component checks after approval
-------------------------------

1. Build both small default/immediate presenter libraries from identical private
   source. Run copied existing `tests/stdlib/ui_pixels.c`: all65,536 color/alpha
   combinations, RGB24/RGBA32 and row order, without opening any window.
2. Run the SDK's existing `runtime/tests/windows_ui_tests.c` against each private
   coherent runtime, after root grants visible-window access. It already asserts
   actual `direct2d` driver, independent windows/resize, invalid present buffers,
   and native screenshot pixels matching the authored canvas exactly. Preserve
   these assertions rather than calling `EndDraw` success a pixel oracle.
3. Add a test-only derived presenter copy (not the product delta): after a real
   successful EndDraw, inject one D2DERR_RECREATE_TARGET result. Count successful
   create_target calls and the actual flags passed to CreateHwndRenderTarget.
   Verify first/second targets both0 in default and both2 in opt-in, a resize
   between them, existing retained pixels survive recreation, and next distinct
   authored canvas presents correctly. Preserve normal resource RAII and leave
   injection disabled outside the single test. A plain initial-target check is
   insufficient for the recovery requirement.
4. Explicit GDI selection must retain driver/metadata and pixel behavior in both
   builds. Null metadata returns `none` / UINT32_MAX. Actual construction failure
   should retain default auto-fallback vs forced-direct2d refusal semantics.

No visible prototype or editor is launched before coordination with root. No
physical60Hz claim follows from immediate submission or a faster EndDraw. DWM
and the actual59.951Hz monitor can still replace submissions before scanout.
Root owns exact-editor cadence tests and unchanged parser/zero-omission limits.

Microsoft contract:
https://learn.microsoft.com/en-us/windows/win32/api/d2d1/ne-d2d1-d2d1_present_options
Immediate avoids the render target's refresh wait; NONE remains the SDK default.
