import subprocess,json,hashlib
from pathlib import Path
p=Path(__file__).resolve().parent
for mode in ('default','immediate'):
    exe=p/'native/Release'/('component-'+mode+'.exe')
    with (p/('component-'+mode+'.stdout.log')).open('xb') as out,(p/('component-'+mode+'.stderr.log')).open('xb') as err:
        run=subprocess.run([str(exe),str(p/('component-'+mode+'.json'))],stdout=out,stderr=err,timeout=25,creationflags=subprocess.CREATE_NO_WINDOW)
    (p/('component-'+mode+'.exit')).write_text(str(run.returncode))
    print(mode,run.returncode,(p/('component-'+mode+'.json')).read_text())
    if run.returncode:break
