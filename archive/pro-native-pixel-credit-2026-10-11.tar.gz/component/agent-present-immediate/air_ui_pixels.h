/* Pixel conversion shared by native canvas presenters. No window or display needed. */
#ifndef AIR_UI_PIXELS_H
#define AIR_UI_PIXELS_H
#include <stdint.h>
#include <stddef.h>

static inline unsigned air_ui_pixel_channels(const void *source, uint64_t length,
                                             uint32_t width, uint32_t height) {
    if (!source || !width || !height || width > 16384u || height > 16384u) return 0u;
    const uint64_t count = (uint64_t)width * height;
    if (count > SIZE_MAX / 4u) return 0u;
    return length == count * 3u ? 3u : length == count * 4u ? 4u : 0u;
}

/* Straight RGBA composites over black with the std.draw.surface_rgb24 rounding. */
static inline uint8_t air_ui_pixel_channel(const uint8_t *pixel, unsigned channel,
                                           unsigned channels) {
    return channels == 3u || pixel[3] == 255u ? pixel[channel]
        : (uint8_t)(((unsigned)pixel[channel] * pixel[3] + 127u) / 255u);
}

static inline void air_ui_pixels_bgra(uint8_t *destination, const uint8_t *source,
                                      uint64_t count, unsigned channels) {
    for (uint64_t i = 0; i < count; ++i) {
        const uint8_t *p = source + i * channels;
        destination[i * 4u] = air_ui_pixel_channel(p, 2u, channels);
        destination[i * 4u + 1u] = air_ui_pixel_channel(p, 1u, channels);
        destination[i * 4u + 2u] = air_ui_pixel_channel(p, 0u, channels);
        destination[i * 4u + 3u] = 255u;
    }
}
#endif
