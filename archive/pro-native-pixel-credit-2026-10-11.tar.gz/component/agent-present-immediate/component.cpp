#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#include <windows.h>
#include <dwmapi.h>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <stdexcept>
#include <string>
#include <vector>
#include "air_ui_presenter_win32.h"
extern "C" void fixture_fail_create(int);
extern "C" void fixture_recreate_next();
extern "C" void fixture_reset_counts();
extern "C" unsigned fixture_created();
extern "C" unsigned fixture_flags(unsigned);
#ifndef EXPECT_OPTIONS
#define EXPECT_OPTIONS 0
#endif
static unsigned checks=0;
static unsigned long long compared=0;
static std::vector<std::string> observations;
static void require(bool ok,const char*name){++checks;if(!ok)throw std::runtime_error(name);}
static LRESULT CALLBACK proc(HWND w,UINT m,WPARAM a,LPARAM b){return DefWindowProcW(w,m,a,b);}
static void pump(){MSG m={};while(PeekMessageW(&m,nullptr,0,0,PM_REMOVE)){TranslateMessage(&m);DispatchMessageW(&m);}}
static void size(HWND w,unsigned width,unsigned height){RECT r={0,0,(LONG)width,(LONG)height};require(AdjustWindowRectEx(&r,WS_OVERLAPPEDWINDOW,FALSE,0)!=0,"adjust fixture rect");require(SetWindowPos(w,nullptr,0,0,r.right-r.left,r.bottom-r.top,SWP_NOMOVE|SWP_NOZORDER)!=0,"resize fixture window");pump();RECT c={};require(GetClientRect(w,&c)!=0 && c.right==(LONG)width && c.bottom==(LONG)height,"actual own client dimensions");}
static std::vector<uint8_t> pixels(unsigned w,unsigned h,unsigned seed){std::vector<uint8_t> p((size_t)w*h*4);for(unsigned y=0;y<h;++y)for(unsigned x=0;x<w;++x){size_t i=((size_t)y*w+x)*4;p[i]=(uint8_t)(x*3+y+seed);p[i+1]=(uint8_t)(y*5+seed*2);p[i+2]=(uint8_t)((x^y)+seed*3);p[i+3]=255;}return p;}
static void capture(HWND window,unsigned w,unsigned h,const std::vector<uint8_t>& expected){
 // Capture only this fixture's client DC, matching the SDK native pixel oracle.
 (void)DwmFlush(); HDC src=GetDC(window);require(src!=nullptr,"own client DC");
 HDC mem=CreateCompatibleDC(src);require(mem!=nullptr,"capture memory DC");
 BITMAPINFO bi={};bi.bmiHeader.biSize=sizeof(BITMAPINFOHEADER);bi.bmiHeader.biWidth=(LONG)w;bi.bmiHeader.biHeight=-(LONG)h;bi.bmiHeader.biPlanes=1;bi.bmiHeader.biBitCount=32;bi.bmiHeader.biCompression=BI_RGB;
 void*raw=nullptr;HBITMAP bmp=CreateDIBSection(mem,&bi,DIB_RGB_COLORS,&raw,nullptr,0);require(bmp!=nullptr && raw!=nullptr,"own capture DIB");
 HGDIOBJ old=SelectObject(mem,bmp);require(BitBlt(mem,0,0,w,h,src,0,0,SRCCOPY)!=0,"own client pixel copy");GdiFlush();
 const uint8_t*actual=(const uint8_t*)raw;unsigned long long wrong=0;size_t first=0;
 for(size_t i=0;i<(size_t)w*h*4;++i){if(i%4==3)continue;++compared;if(actual[i]!=expected[i]){if(!wrong)first=i;++wrong;}}
 if(wrong)std::fprintf(stderr,"pixel mismatch count=%llu first=%zu actual=%u expected=%u\n",wrong,first,actual[first],expected[first]);
 SelectObject(mem,old);DeleteObject(bmp);DeleteDC(mem);ReleaseDC(window,src);require(wrong==0,"exact own client RGB pixels");
}
static void repaint(air_ui_presenter*p,HWND w){HDC dc=GetDC(w);require(dc!=nullptr,"repaint own DC");air_ui_presenter_paint(p,dc);ReleaseDC(w,dc);}
static void exercise(HWND w,const wchar_t*driver,const char*expect,bool fault){
 SetEnvironmentVariableW(L"AIR_UI_DRIVER",driver);fixture_fail_create(0);fixture_reset_counts();size(w,320,200);
 air_ui_presenter*p=air_ui_presenter_create(w,320,200);require(p!=nullptr,"create actual presenter");require(std::strcmp(air_ui_presenter_driver(p),expect)==0,"actual driver unchanged");bool d2d=std::strcmp(expect,"direct2d")==0;
 require(air_ui_presenter_present_options(p)==(d2d?EXPECT_OPTIONS:UINT32_MAX),"actual instance options");require(std::strcmp(air_ui_presenter_mode(p),d2d?(EXPECT_OPTIONS==2?"immediate":"refresh-wait"):"not-applicable")==0,"actual instance mode");
 if(d2d){require(fixture_created()==1,"one initial real target");require(fixture_flags(0)==EXPECT_OPTIONS,"actual CreateHwndRenderTarget initial flags");}
 require(air_ui_presenter_present(p,nullptr,320,200)==0,"null buffer refused");uint8_t dummy=0;require(air_ui_presenter_present(p,&dummy,0,200)==0,"zero dimensions refused");
 auto a=pixels(320,200,7);require(air_ui_presenter_present(p,a.data(),320,200)==1,"first authored pixels");capture(w,320,200,a);
 repaint(p,w);capture(w,320,200,a);
 size(w,384,240);require(air_ui_presenter_resize(p,384,240)==1,"native presenter resize");auto b=pixels(384,240,31);require(air_ui_presenter_present(p,b.data(),384,240)==1,"resized authored pixels");capture(w,384,240,b);
 if(d2d && fault){fixture_recreate_next();repaint(p,w);require(fixture_created()==2,"one actual recreation after injected successful EndDraw");require(fixture_flags(1)==EXPECT_OPTIONS,"actual recreated target flags");capture(w,384,240,b);auto c=pixels(384,240,91);require(air_ui_presenter_present(p,c.data(),384,240)==1,"next distinct frame after recreate");capture(w,384,240,c);}
 if(d2d)observations.push_back("direct2d initial/recreate actual options="+std::to_string(EXPECT_OPTIONS)+"; resize/retained/next RGB exact");else observations.push_back("explicit GDI; resize/retained RGB exact; Direct2D options not applicable");
 air_ui_presenter_destroy(p);
}
int main(int argc,char**argv){
 if(argc!=2)return 2;FILE*report=nullptr;if(fopen_s(&report,argv[1],"wx")!=0)return 3;
 HWND w=nullptr;bool passed=false;std::string error;
 try{
  (void)SetProcessDpiAwarenessContext(DPI_AWARENESS_CONTEXT_PER_MONITOR_AWARE_V2);
  WNDCLASSW wc={};wc.lpfnWndProc=proc;wc.hInstance=GetModuleHandleW(nullptr);wc.lpszClassName=L"AIR isolated presenter fixture";require(RegisterClassW(&wc)!=0,"register own window class");
  w=CreateWindowExW(0,wc.lpszClassName,L"Genesis private renderer component fixture",WS_OVERLAPPEDWINDOW,120,120,400,300,nullptr,nullptr,wc.hInstance,nullptr);require(w!=nullptr,"create only own fixture window");ShowWindow(w,SW_SHOWNOACTIVATE);UpdateWindow(w);pump();
  require(std::strcmp(air_ui_presenter_driver(nullptr),"none")==0,"null driver");require(std::strcmp(air_ui_presenter_mode(nullptr),"none")==0,"null mode");require(air_ui_presenter_present_options(nullptr)==UINT32_MAX,"null options");require(air_ui_presenter_create(nullptr,320,200)==nullptr,"null HWND refusal");require(air_ui_presenter_resize(nullptr,1,1)==0,"null resize refusal");
  exercise(w,L"direct2d","direct2d",true);exercise(w,L"gdi","gdi",false);
  fixture_fail_create(1);SetEnvironmentVariableW(L"AIR_UI_DRIVER",L"direct2d");require(air_ui_presenter_create(w,384,240)==nullptr,"forced Direct2D refuses target failure");
  SetEnvironmentVariableW(L"AIR_UI_DRIVER",nullptr);auto fallback=air_ui_presenter_create(w,384,240);require(fallback!=nullptr,"auto target failure falls back");require(std::strcmp(air_ui_presenter_driver(fallback),"gdi")==0,"actual auto fallback driver");require(std::strcmp(air_ui_presenter_mode(fallback),"not-applicable")==0 && air_ui_presenter_present_options(fallback)==UINT32_MAX,"auto fallback metadata");auto a=pixels(384,240,141);require(air_ui_presenter_present(fallback,a.data(),384,240)==1,"auto fallback frame");capture(w,384,240,a);air_ui_presenter_destroy(fallback);fixture_fail_create(0);
  SetEnvironmentVariableW(L"AIR_UI_DRIVER",L"unknown-driver");require(air_ui_presenter_create(w,384,240)==nullptr,"unknown driver refusal");passed=true;
 }catch(const std::exception&e){error=e.what();}
 if(w){DestroyWindow(w);require(!IsWindow(w),"own fixture destroyed");}
 std::fprintf(report,"{\"passed\":%s,\"compiled_requested_options\":%u,\"checks\":%u,\"compared_rgb_values\":%llu,\"own_window_destroyed\":true,\"error\":\"%s\",\"physical_cadence_measured\":false,\"observations\":[",passed?"true":"false",(unsigned)EXPECT_OPTIONS,checks,compared,error.c_str());for(size_t i=0;i<observations.size();++i)std::fprintf(report,"%s\"%s\"",i?",":"",observations[i].c_str());std::fprintf(report,"]}\n");fclose(report);return passed?0:1;
}
