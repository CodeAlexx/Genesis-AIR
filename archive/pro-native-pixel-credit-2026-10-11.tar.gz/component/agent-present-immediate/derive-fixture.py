from pathlib import Path
p=Path('build-windows/agent-present-immediate')
s=(p/'private/air_ui_presenter_win32.cpp').read_text()
s=s.replace('namespace {','''// Test-only deterministic hooks. Excluded from the production proposal.
static bool test_fail_create = false;
static bool test_recreate_draw = false;
static unsigned test_created = 0;
static unsigned test_flags[16] = {};
extern "C" void fixture_fail_create(int flag) { test_fail_create = flag != 0; }
extern "C" void fixture_recreate_next() { test_recreate_draw = true; }
extern "C" void fixture_reset_counts() { test_created = 0; }
extern "C" unsigned fixture_created() { return test_created; }
extern "C" unsigned fixture_flags(unsigned index) { return index < test_created && index < 16 ? test_flags[index] : UINT32_MAX; }
namespace {''',1)
s=s.replace('if (!factory_) return false;','if (!factory_ || test_fail_create) return false;',1)
s=s.replace('if (SUCCEEDED(result)) target_->SetDpi(96.0f, 96.0f);','''if (SUCCEEDED(result)) {
            target_->SetDpi(96.0f, 96.0f);
            if (test_created < 16) test_flags[test_created] = static_cast<unsigned>(window_properties.presentOptions);
            ++test_created;
        }''',1)
s=s.replace('const HRESULT result = target_->EndDraw();','''HRESULT result = target_->EndDraw();
        // Only replace a REAL successful EndDraw result once; real target handling remains intact.
        if (SUCCEEDED(result) && test_recreate_draw) {
            test_recreate_draw = false;
            result = D2DERR_RECREATE_TARGET;
        }''',1)
(p/'fixture-presenter.cpp').write_text(s,newline='\n')
