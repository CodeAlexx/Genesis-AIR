"""Independent bounded native056E export check; no UI, device, or new export."""
import hashlib,json,math,os,struct,subprocess,sys,wave
from pathlib import Path
import numpy as np
from PIL import Image,ImageDraw,ImageFont,ImageFilter
REPO=Path(__file__).resolve().parents[3]
sys.path.insert(0,str(REPO/'tests'))
from media_runtime import tool
from audio_stream import wire
import importlib.util
spec=importlib.util.spec_from_file_location('prior_oracle',REPO/'build-windows/large-native-final-verification/check_export_audible.py')
prior=importlib.util.module_from_spec(spec);spec.loader.exec_module(prior)
OUT=Path(__file__).resolve().parent
BASE=OUT.parent
RUNTIME=REPO/'build-windows/pro-native-title-timing-stop-final-2026-10-11-runtime'
PROJECT=BASE/'Native title export.air';MOVIE=BASE/'Native title retry.mp4'
CANCELLED=BASE/'Native title cancelled.mp4'
WORKER=RUNTIME/'genesis-gcompose.exe';APP=RUNTIME/'Genesis-AIR.exe'
BUILD=REPO/'build-windows/pro-native-title-timing-stop-final-2026-10-11-build-receipt.json'
FONT=Path('C:/Windows/Fonts/segoeui.ttf')
FLAGS=subprocess.CREATE_NO_WINDOW if os.name=='nt' else 0
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
def run(args):
 r=subprocess.run(list(map(str,args)),capture_output=True,timeout=180,creationflags=FLAGS)
 assert r.returncode==0,(args,r.returncode,r.stderr[-3000:])
 return r.stdout
def masks(text):
 cap=36*1080/856;px=math.floor(cap/.729+.5)
 face=ImageFont.truetype(str(FONT),px,layout_engine=ImageFont.Layout.BASIC)
 outside=np.ones((1080,1920),dtype=bool);result=[]
 for row,line in enumerate(text.split('\n')):
  mask=Image.new('L',(1920,1080));draw=ImageDraw.Draw(mask)
  widths=prior.advances(FONT,line,px);pen=960-sum(widths)/2
  baseline=540+row*cap*1.3+cap
  for char,width in zip(line,widths):
   draw.text((math.floor(pen+.5),math.floor(baseline+.5)),char,font=face,anchor='ls',fill=255);pen+=width
  box=mask.getbbox();assert box
  x0,y0,x1,y1=box;outside[max(0,y0-32):min(1080,y1+34),max(0,x0-32):min(1920,x1+34)]=False
  core=np.asarray(mask.filter(ImageFilter.MinFilter(5)))>=250
  assert core.sum()>=500
  result.append((core,dict(text=line,font_px=px,cap_height=cap,baseline=baseline,bbox=box,core_pixels=int(core.sum()),interior_kernel=5)))
 return result,outside
def main():
 report=dict(schema='genesis.native056e.export.independent.v1',passed=False,
 thresholds=dict(outside_mean=3/255,outside_p95=8/255,outside_p99=18/255,title_white_coverage=.93,
 aac_correlation=.99,aac_relative_rmse=.10,aac_additive_rms_floor=.0003,worker_pcm_codes=1),
 limitations=['178-frame lossy H264/AAC export, three authored picture positions; not pixel-bitexact anti-alias or whole-source verification.',
 'Independent original-source decode and TTF interiors; default Segoe UI explicitly confirmed before execution.',
 'No GUI/device actions, physical hearing, speaker latency or playback timing claims.'])
 paths={};before={}
 try:
  doc=json.loads(PROJECT.read_text(encoding='utf-8-sig'));source=Path(doc['sources'][0]['path'])
  paths=dict(project=PROJECT,movie=MOVIE,source=source,worker=WORKER,app=APP,dll=RUNTIME/'genesis-native-audio.dll',build_receipt=BUILD,font=FONT)
  before={k:sha(p) for k,p in paths.items()};report['hashes_before']=before
  assert before['app']=='056eafa3a01f0f1dd594d2a8e201b4d72d044bdb2a3297c5b5806009080f238c'
  assert before['dll']=='5a004885dfff4604a6826e9500f2cfcb640240db57f195d23cbfe84bef8ced85'
  assert before['worker']=='aa40b96c631c82cfc834d027678e95a00bd8d5f61db54f15e7c7ecefcf74228c'
  assert before['build_receipt']=='3720a808babf2ebab2407e70a8663e7e348189e13349bcccd7eb23d79fed254a'
  assert not CANCELLED.exists() and not Path(str(CANCELLED)+'.part').exists()
  assert not Path(str(MOVIE)+'.part').exists()
  assert doc['program']['mark_in']==0 and doc['program']['mark_out']==178
  assert doc['keys']==[] and doc['transitions']==[] and len(doc['clips'])==2
  video,sound=sorted(doc['clips'],key=lambda c:c['id'])
  assert video['id']==8 and sound['id']==9 and video['streams']==1 and sound['streams']==2
  for c in (video,sound):assert c['source_in']==c['start']==0 and c['speed']==1 and not c['reverse'] and c['enabled'] and c['fade_in']==c['fade_out']==c['pan']==0
  tracks={t['id']:t for t in doc['tracks']};track=tracks[sound['track']]
  assert abs(track['gain']-.45)<1e-14 and abs(track['pan']+.95)<1e-14 and abs(sound['gain']-.60)<1e-14
  assert not any(t['muted'] or t['solo'] for t in tracks.values())
  assert [(f['id'],f['clip'],f['kind'],f['enabled']) for f in doc['filters']]==[(11,9,'eq_3band',True),(12,8,'text',True)]
  assert doc['filter_params']==[dict(filter=11,name='low',value=2.5)]
  text=doc['filter_text_params'][0]['value'];assert text=='Genesis AIR — café\n1080p60 • Linked video + audio'
  ffmpeg,probe=tool(WORKER,'ffmpeg'),tool(WORKER,'ffprobe')
  assert ffmpeg==Path('C:/MM-Air/ffmpeg.exe') and probe==Path('C:/MM-Air/ffprobe.exe')
  report['shared_tools']={k:dict(path=str(p),sha256=sha(p)) for k,p in [('ffmpeg',ffmpeg),('ffprobe',probe)]}
  metadata=json.loads(run([probe,'-v','error','-count_frames','-show_streams','-show_format','-of','json',MOVIE]));report['probe']=metadata
  v=next(s for s in metadata['streams'] if s['codec_type']=='video');a=next(s for s in metadata['streams'] if s['codec_type']=='audio')
  assert (v['width'],v['height'],v['codec_name'],v['r_frame_rate'],int(v['nb_read_frames']))==(1920,1080,'h264','60/1',178)
  assert abs(float(v['duration'])-178/60)<1e-5
  assert a['codec_name']=='aac' and int(a['sample_rate'])==48000 and a['channels']==2
  indices=[0,89,177];select='select='+ '+'.join(f'eq(n\\,{i})' for i in indices)
  frames=[]
  for file in (source,MOVIE):
   raw=run([ffmpeg,'-nostdin','-v','error','-i',file,'-map','0:v:0','-vf',select,'-frames:v','3','-fps_mode','passthrough','-pix_fmt','rgb48le','-f','rawvideo','pipe:1'])
   assert len(raw)==3*1080*1920*6;frames.append(np.frombuffer(raw,dtype='<u2').reshape(3,1080,1920,3))
  cores,outside=masks(text);checks=[]
  report['title_declaration']=[entry for _,entry in cores]
  for at,index in enumerate(indices):
   expected=frames[0][at].astype(np.float32)/65535;got=frames[1][at].astype(np.float32)/65535
   delta=np.abs(got[outside]-expected[outside]);mean=float(delta.mean());p95,p99=map(float,np.quantile(delta,[.95,.99]))
   entry=dict(frame=index,outside_mean=mean,outside_p95=p95,outside_p99=p99,lines=[]);checks.append(entry)
   assert mean<=3/255 and p95<=8/255 and p99<=18/255,entry
   for core,decl in cores:
    observable=core&(expected.max(axis=2)<.8);assert observable.sum()>=300
    coverage=float((got[observable].min(axis=1)>=.90).mean())
    entry['lines'].append(dict(text=decl['text'],observable_pixels=int(observable.sum()),white_coverage=coverage))
    assert coverage>=.93,entry
  report['picture_checks']=checks
  # Independent selected native44100 samples, origin decode preserves AAC edit-list/priming.
  # Float stereo normalization -> track balance -> authored100HzEQ -> final scalar gain.
  end=178*44100//60;count=178*48000//60
  fx='stereotools=balance_out=-0.95,equalizer=f=100:t=q:w=1:g=2.5'
  chain=f'atrim=start_sample=0:end_sample={end},asetpts=N/SR/TB,aresample=48000,aformat=sample_fmts=flt:sample_rates=48000:channel_layouts=stereo,{fx},aformat=sample_fmts=flt:sample_rates=48000:channel_layouts=stereo'
  raw=run([ffmpeg,'-nostdin','-v','error','-i',source,'-map','0:a:0','-af',chain,'-t',str(178/60),'-f','f32le','pipe:1'])
  reference=np.frombuffer(raw,dtype='<f4').copy();assert reference.size==count*2
  gain=prior.f32(prior.f32(.45)*prior.f32(.60));reference=np.clip(reference*gain,-1,1)
  np.asarray(reference,dtype='<f4').tofile(OUT/'independent-reference.f32')
  wav=OUT/'worker-reference.wav'
  commands=[f'WAVE {wire(wav)} {178/60:.17f}',f'AUDIO {wire(source)} 0 {178/60:.17f} 0 {gain:.17f} 0 0 {76701/60:.17f} 0 {fx}',f'WAVECLOSE {wire(wav)}']
  child=subprocess.run([str(WORKER),'--serve','--size','16','16'],input='\n'.join(commands)+'\n',text=True,capture_output=True,timeout=120,creationflags=FLAGS)
  (OUT/'worker.stdout.log').write_text(child.stdout,encoding='utf-8');(OUT/'worker.stderr.log').write_text(child.stderr,encoding='utf-8')
  assert child.returncode==0 and 'ERR' not in child.stdout and sum(x.startswith('DONE') for x in child.stdout.splitlines())==3,(child.returncode,child.stdout,child.stderr)
  with wave.open(str(wav)) as w:
   assert (w.getnchannels(),w.getframerate(),w.getsampwidth(),w.getnframes())==(2,48000,2,count)
   pcm=np.frombuffer(w.readframes(count),dtype='<i2').astype(np.float64)
  expected_pcm=np.sign(reference)*np.floor(np.abs(reference.astype(np.float64))*32767+.5)
  maximum=float(np.max(np.abs(pcm-expected_pcm)));assert maximum<=1,maximum
  decoded=np.frombuffer(run([ffmpeg,'-nostdin','-v','error','-i',MOVIE,'-map','0:a:0','-f','f32le','pipe:1']),dtype='<f4')
  assert count*2<=decoded.size<=count*2+4096
  got=decoded[:count*2].astype(np.float64);ref=reference.astype(np.float64)
  rms=float(np.sqrt(np.mean(ref**2)));got_rms=float(np.sqrt(np.mean(got**2)));assert rms>.00003 and got_rms>.00003
  corr=float(np.dot(ref,got)/(np.linalg.norm(ref)*np.linalg.norm(got)));rmse=float(np.sqrt(np.mean((got-ref)**2)))
  report['audio']=dict(source_native_samples=end,reference_sample_frames=count,decoded_sample_frames=decoded.size//2,
    track_gain=.45,track_pan=-.95,clip_gain=.60,eq_low_db=2.5,gain_f32= gain,worker_pcm_maximum_codes=maximum,
    reference_rms=rms,actual_rms=got_rms,zero_shift_correlation=corr,rmse=rmse,
    channel_rms_reference=list(np.sqrt(np.mean(ref.reshape(-1,2)**2,axis=0))),channel_rms_actual=list(np.sqrt(np.mean(got.reshape(-1,2)**2,axis=0))))
  assert corr>=.99 and rmse<=.10*rms+.0003,report['audio']
  after={k:sha(p) for k,p in paths.items()};assert before==after
  report.update(passed=True,hashes_after=after,inputs_immutable=True,cancelled_target_absent=True,range_exclusive=[0,178],video_frames=178,authored_positions=indices)
 except BaseException as e:report['error']=repr(e);raise
 finally:
  with (OUT/'receipt.json').open('x',encoding='utf-8') as f:json.dump(report,f,indent=2)
 print(json.dumps(dict(passed=True,frames=178,audio=report['audio'],picture_checks=report['picture_checks'])))
if __name__=='__main__':main()
