param(
 [Parameter(Mandatory=$true)][int]$ProcessId,
 [Parameter(Mandatory=$true)][string]$RuntimeDirectory,
 [Parameter(Mandatory=$true)][string]$ExpectedAppSha256,
 [Parameter(Mandatory=$true)][string]$ExpectedDllSha256,
 [Parameter(Mandatory=$true)][string]$OutputPath
)
$ErrorActionPreference='Stop'
if(Test-Path -LiteralPath $OutputPath){throw 'Preserve existing module capture'}
$runtime=(Resolve-Path -LiteralPath $RuntimeDirectory).Path
$native=Get-Process -Id $ProcessId -ErrorAction Stop
$main=$native.MainModule.FileName
if([IO.Path]::GetFullPath($main) -ne [IO.Path]::GetFullPath((Join-Path $runtime 'Genesis-AIR.exe'))){throw 'Wrong live editor path'}
$mainHash=(Get-FileHash -LiteralPath $main -Algorithm SHA256).Hash
if($mainHash -ne $ExpectedAppSha256){throw 'Wrong live editor hash'}
$audio=@($native.Modules | Where-Object ModuleName -EQ 'genesis-native-audio.dll')
if($audio.Count -ne 1){throw 'Missing/ambiguous loaded native audio DLL'}
$audioPath=$audio[0].FileName
$audioHash=(Get-FileHash -LiteralPath $audioPath -Algorithm SHA256).Hash
if($audioHash -ne $ExpectedDllSha256 -or [IO.Path]::GetFullPath($audioPath) -ne [IO.Path]::GetFullPath((Join-Path $runtime 'genesis-native-audio.dll'))){throw 'Wrong actual loaded DLL'}
$record=[ordered]@{schema='genesis.native.loaded-modules.v1';captured_utc=[DateTime]::UtcNow.ToString('o');pid=$ProcessId;main_path=$main;main_sha256=$mainHash;modules=@([ordered]@{name='genesis-native-audio.dll';path=$audioPath;sha256=$audioHash})}
$record | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath $OutputPath
Get-FileHash -LiteralPath $OutputPath -Algorithm SHA256
