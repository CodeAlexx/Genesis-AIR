# Prepared only: execute after the parent explicitly releases the device slot.
& (Join-Path $PSScriptRoot 'run.ps1') `
  -RuntimeDirectory '<ROOT>\build-windows\pro-native-pixel-credit-2026-10-11-runtime' `
  -BinDirectory '<ROOT>\build-windows\pro-native-pixel-credit-2026-10-11-native\bin\Release' `
  -BuildReceipt '<ROOT>\build-windows\pro-native-pixel-credit-2026-10-11-build-receipt.json' `
  -ExpectedAppSha256 '3b5eee99965db27e0604fb6408109245edd9b0b8b1e50b62c75361edb0cc7093' `
  -ExpectedDllSha256 '005f5f01f943a7183919f706fa3869356f8fea99574d09b781ff0340fb91ab59' `
  -ExpectedBuildReceiptSha256 'f20f5fe40b4e7fdae74374528dab4652594027c943f0abdcce4fde4a0e5049e7'
