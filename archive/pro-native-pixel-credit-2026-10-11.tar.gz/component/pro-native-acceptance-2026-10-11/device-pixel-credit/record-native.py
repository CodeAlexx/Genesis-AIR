"""Reusable exact-candidate receipt; fresh supplied observations only.
No application launches, GUI actions, media decoding or sound-device tests.
"""
import argparse,ctypes,datetime,hashlib,json
from pathlib import Path
REPO=Path(__file__).resolve().parents[3]
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
def need(v,why):
 if not v:raise AssertionError(why)
def closed(pid):
 k=ctypes.WinDLL('kernel32',use_last_error=True)
 k.OpenProcess.argtypes=[ctypes.c_uint32,ctypes.c_int,ctypes.c_uint32];k.OpenProcess.restype=ctypes.c_void_p
 k.WaitForSingleObject.argtypes=[ctypes.c_void_p,ctypes.c_uint32];k.WaitForSingleObject.restype=ctypes.c_uint32
 k.CloseHandle.argtypes=[ctypes.c_void_p]
 h=k.OpenProcess(0x00100000,False,pid)
 if not h:need(ctypes.get_last_error()==87,'Unexpected process-check error');return True
 try:return k.WaitForSingleObject(h,0)==0
 finally:k.CloseHandle(h)
def main():
 p=argparse.ArgumentParser()
 for name in ('prefix','app-sha256','dll-sha256','build-receipt-sha256'):p.add_argument('--'+name,required=True)
 for name in ('observations','modules','project','output'):p.add_argument('--'+name,type=Path,required=True)
 a=p.parse_args();need(not a.output.exists(),'Preserve previous receipt')
 need(a.prefix.startswith('pro-native-') and '/' not in a.prefix and '\\' not in a.prefix,'Unsafe build prefix')
 runtime=REPO/'build-windows'/f'{a.prefix}-runtime';buildpath=REPO/'build-windows'/f'{a.prefix}-build-receipt.json'
 frozenpath=REPO/'build-windows'/f'{a.prefix}-frozen.json'
 need(sha(buildpath)==a.build_receipt_sha256.lower(),'Build receipt mismatch')
 build=json.loads(buildpath.read_text());frozen=json.loads(frozenpath.read_text())
 need(build['passed'] and build['source_frozen_sha256']==sha(frozenpath),'Source/build binding differs')
 need(sha(runtime/'Genesis-AIR.exe')==a.app_sha256.lower(),'Candidate app differs')
 need(sha(runtime/'genesis-native-audio.dll')==a.dll_sha256.lower(),'Candidate DLL differs')
 payload={n:sha(runtime/n) for n in build['payload_sha256']};need(payload==build['payload_sha256'],'Payload mismatch')
 source=REPO/'build-windows'/f'{a.prefix}-source'
 sourcehash={n:sha(source/n) for n in frozen['source_sha256']};need(sourcehash==frozen['source_sha256'],'Snapshot differs')
 generated=REPO/'build-windows'/f'{a.prefix}-generated'
 need({n:sha(generated/n) for n in build['generated_sha256']}==build['generated_sha256'],'Generated inputs differ')
 protected={n:sha(n) for n in frozen['protected_assets']};need(protected==frozen['protected_assets'],'Protected originals changed')
 obs=json.loads(a.observations.read_text(encoding='utf-8-sig'));modules=json.loads(a.modules.read_text(encoding='utf-8-sig'))
 need(obs['app_sha256'].lower()==a.app_sha256.lower(),'Observations belong to another binary')
 need(obs['audio_dll_sha256'].lower()==a.dll_sha256.lower(),'Observations belong to another DLL')
 need(obs['process_id']==modules['pid'] and obs['native_window_id']>0,'Observation/process identity differs')
 need(obs['owned_process_exited'] is True and closed(modules['pid']),'Owned editor has not exited')
 need(len(obs['observations'])>0,'No fresh observations supplied')
 need(modules['main_sha256'].lower()==a.app_sha256.lower(),'Actual module app differs')
 need(Path(modules['main_path']).resolve()==(runtime/'Genesis-AIR.exe').resolve(),'Actual app path differs')
 audio=[m for m in modules['modules'] if m['name']=='genesis-native-audio.dll']
 need(len(audio)==1 and audio[0]['sha256'].lower()==a.dll_sha256.lower(),'Actual DLL hash differs')
 need(Path(audio[0]['path']).resolve()==(runtime/'genesis-native-audio.dll').resolve(),'Actual DLL directory differs')
 doc=json.loads(a.project.read_text(encoding='utf-8-sig'))
 need(doc['program']['playing'] is False and doc['monitor']['playing'] is False,'Saved project still playing')
 # Any assertions beyond structural bind are explicitly supplied with fresh UI
 # observations, rather than inherited from a different native run.
 checks=obs.get('saved_graph_expectations',{})
 for name,value in checks.items():
  if name=='clip_count':actual=len(doc['clips'])
  elif name=='program_frame':actual=doc['program']['frame']
  elif name=='source_frame':actual=doc['monitor']['frame']
  elif name=='title_contents':actual=[x['value'] for x in doc['filter_text_params'] if x['name']=='content']
  elif name=='track_mixers':
   actual={str(t['id']):dict(gain=t['gain'],pan=t['pan'],muted=t['muted'],solo=t['solo']) for t in doc['tracks'] if str(t['id']) in value}
  else:raise AssertionError('Unknown saved graph expectation: '+name)
  need(actual==value,'Saved graph mismatch: '+name)
 receipt=dict(schema='genesis.native-live.observed.v4',passed=True,captured_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
 candidate_prefix=a.prefix,app_sha256=a.app_sha256.lower(),audio_dll_sha256=a.dll_sha256.lower(),build_receipt_sha256=sha(buildpath),
 source_frozen_sha256=sha(frozenpath),process_id=modules['pid'],native_window_id=obs['native_window_id'],owned_process_exited=True,
 loaded_module_capture_sha256=sha(a.modules),actual_loaded_audio_dll=audio[0]['path'],private_project_sha256={a.project.name:sha(a.project)},
 observations=obs['observations'],observations_sha256=sha(a.observations),saved_graph_expectations_verified=checks,
 payload_sha256=payload,source_files_checked=len(sourcehash),generated_files_checked=len(build['generated_sha256']),
 protected_assets_sha256=protected,originals_unchanged=True,helper_sha256=sha(__file__),
 scope='Fresh parent-supplied native observations only. Independent file/module/graph validation; prior candidates are not relabeled.',
 limitations=obs.get('limitations',['No quantitative cadence or physical speaker/photon latency claim.']))
 with a.output.open('x',encoding='utf-8') as f:json.dump(receipt,f,indent=2)
 print(json.dumps(dict(passed=True,receipt_sha256=sha(a.output))))
if __name__=='__main__':main()
