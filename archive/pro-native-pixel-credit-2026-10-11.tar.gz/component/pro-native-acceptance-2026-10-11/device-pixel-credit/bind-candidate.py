from pathlib import Path
import hashlib,json,datetime,py_compile
r=Path.cwd();p=r/'build-windows/pro-native-acceptance-2026-10-11/device-pixel-credit';prefix='pro-native-pixel-credit-2026-10-11'
runtime=r/'build-windows'/f'{prefix}-runtime';bin=r/'build-windows'/f'{prefix}-native/bin/Release';receipt=r/'build-windows'/f'{prefix}-build-receipt.json'
expected={'app':'3b5eee99965db27e0604fb6408109245edd9b0b8b1e50b62c75361edb0cc7093','dll':'005f5f01f943a7183919f706fa3869356f8fea99574d09b781ff0340fb91ab59','build':'f20f5fe40b4e7fdae74374528dab4652594027c943f0abdcce4fde4a0e5049e7'}
def sha(q):return hashlib.sha256(q.read_bytes()).hexdigest()
actual={'app':sha(runtime/'Genesis-AIR.exe'),'dll':sha(runtime/'genesis-native-audio.dll'),'build':sha(receipt)}
assert actual==expected
adjacent=sha(bin/'genesis-native-audio.dll');assert adjacent==expected['dll']
b=json.loads(receipt.read_text());assert b['passed'];assert b['payload_sha256']['Genesis-AIR.exe']==expected['app'];assert b['payload_sha256']['genesis-native-audio.dll']==expected['dll']
for name in ['run.ps1','fixtures.py','capture-modules.ps1','record-native.py']:assert(p/name).exists()
assert not(p/'receipt.json').exists()
py_compile.compile(str(p/'record-native.py'),doraise=True)
args={'RuntimeDirectory':str(runtime),'BinDirectory':str(bin),'BuildReceipt':str(receipt),'ExpectedAppSha256':expected['app'],'ExpectedDllSha256':expected['dll'],'ExpectedBuildReceiptSha256':expected['build']}
command="# Prepared only: execute after the parent explicitly releases the device slot.\n& (Join-Path $PSScriptRoot 'run.ps1') `\n"+' `\n'.join("  -"+k+" '"+v.replace("'","''")+"'" for k,v in args.items())+'\n'
with (p/'invoke-bound-device.ps1').open('x',encoding='utf-8')as f:f.write(command)
record={'schema':'genesis.device-candidate-binding.prepared.v1','prepared_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'prefix':prefix,'bindings':actual,'client_sha256':sha(bin/'genesis-audio-device.exe'),'adjacent_dll_sha256':adjacent,'helpers':{n:sha(p/n) for n in ['prepared.json','run.ps1','fixtures.py','capture-modules.ps1','record-native.py','invoke-bound-device.ps1']},'device_jobs_run':False,'awaiting_parent_full_background_pass_and_explicit_slot':True,'native_helpers_ready':True,'no_inherited_native_observations':True,'observation_contract':'Require fresh process/window and supplied candidate hashes, live module capture before exit, new project, owned-process exit. Historical F718 data is not imported.','graph_values':'Exact serialized values required for optional saved_graph_expectations; track gain/pan may have f32 representation.'}
with(p/'candidate-binding.json').open('x',encoding='utf-8')as f:json.dump(record,f,indent=2)
print(json.dumps({'binding_sha256':sha(p/'candidate-binding.json'),'invocation_sha256':sha(p/'invoke-bound-device.ps1'),'client_sha256':record['client_sha256'],'prepared_receipt_preserved':True,'device_jobs_run':False},indent=2))
