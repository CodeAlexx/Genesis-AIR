param(
  [Parameter(Mandatory=$true)][string]$RuntimeDirectory,
  [Parameter(Mandatory=$true)][string]$BinDirectory,
  [Parameter(Mandatory=$true)][string]$BuildReceipt,
  [Parameter(Mandatory=$true)][string]$ExpectedAppSha256,
  [Parameter(Mandatory=$true)][string]$ExpectedDllSha256,
  [Parameter(Mandatory=$true)][string]$ExpectedBuildReceiptSha256,
  [string]$Python = '<USER>/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe'
)
$ErrorActionPreference = 'Stop'
# Run only after the parent explicitly releases the audio device slot. This
# driver never launches Genesis or closes any pre-existing application.
$repo = (Resolve-Path -LiteralPath (Join-Path $PSScriptRoot '../../..')).Path
$runtime = (Resolve-Path -LiteralPath $RuntimeDirectory).Path
$bin = (Resolve-Path -LiteralPath $BinDirectory).Path
$build = (Resolve-Path -LiteralPath $BuildReceipt).Path
$appPath = Join-Path $runtime 'Genesis-AIR.exe'
$dllPath = Join-Path $runtime 'genesis-native-audio.dll'
$clientPath = Join-Path $bin 'genesis-audio-device.exe'
$adjacentDll = Join-Path $bin 'genesis-native-audio.dll'
$clockScript = Join-Path $repo 'tests/audio_clock.py'
function Digest([string]$LiteralPath) { (Get-FileHash -LiteralPath $LiteralPath -Algorithm SHA256).Hash }
if (Test-Path -LiteralPath (Join-Path $PSScriptRoot 'receipt.json')) { throw 'Final device driver already ran; preserve its receipt.' }
foreach($priorOutput in @('native-audio-clock.log','native-audio-device.log')) {
  if(Test-Path -LiteralPath (Join-Path $PSScriptRoot $priorOutput)) { throw 'Existing run evidence must not be overwritten.' }
}
$bindings = [ordered]@{
  app_sha256=(Digest $appPath); dll_sha256=(Digest $dllPath)
  client_sha256=(Digest $clientPath); adjacent_dll_sha256=(Digest $adjacentDll)
  build_receipt_sha256=(Digest $build); clock_script_sha256=(Digest $clockScript)
  device_source_sha256=(Digest (Join-Path $repo 'tests/audio_device.ai'))
  driver_sha256=(Digest $PSCommandPath); fixtures_script_sha256=(Digest (Join-Path $PSScriptRoot 'fixtures.py'))
}
if($bindings.app_sha256 -ne $ExpectedAppSha256 -or $bindings.dll_sha256 -ne $ExpectedDllSha256 -or
   $bindings.adjacent_dll_sha256 -ne $ExpectedDllSha256 -or $bindings.build_receipt_sha256 -ne $ExpectedBuildReceiptSha256) {
  throw 'Candidate/build binding mismatch before touching the audio device.'
}
$receipt = [ordered]@{
  schema='genesis.native.audio.acceptance.v2'; captured_utc=[DateTime]::UtcNow.ToString('o')
  head=(& git -C $repo rev-parse HEAD).Trim(); passed=$false; bindings=$bindings
  runtime_path=$runtime; client_path=$clientPath; build_receipt_path=$build
  clock_exit=$null; device_exit=$null; loaded_module=$null; failure=''
  requested_clock_seconds=20; drift_limit_ms=75; phase_range_limit_ms=75
  maximum_drain_resume_shortfall_exclusive_samples=48
  scope='Isolated final-candidate waveOut clock/meters/Stop; no Genesis launch, desktop actions, physical hearing or A/V presentation claim.'
}
$ownedProcess = $null
try {
  & $Python (Join-Path $PSScriptRoot 'fixtures.py') *> (Join-Path $PSScriptRoot 'fixtures.log')
  if($LASTEXITCODE -ne 0) { throw 'Independent PCM fixture generation failed.' }
  & $Python $clockScript --library $dllPath --seconds 20 --report (Join-Path $PSScriptRoot 'native-audio-clock.json') *> (Join-Path $PSScriptRoot 'native-audio-clock.log')
  $receipt.clock_exit=$LASTEXITCODE
  if($LASTEXITCODE -ne 0) { throw 'Final candidate native clock gate failed.' }
  $receipt.clock=Get-Content -LiteralPath (Join-Path $PSScriptRoot 'native-audio-clock.json') -Raw | ConvertFrom-Json
  if($receipt.clock.library_sha256 -ne $ExpectedDllSha256) { throw 'Clock harness loaded an unexpected DLL.' }
  $fixtures=@((Join-Path $PSScriptRoot 'stereo.wav'),(Join-Path $PSScriptRoot 'left.wav'),(Join-Path $PSScriptRoot 'silent.wav'))
  $fixtureArguments=($fixtures | ForEach-Object { '"' + $_ + '"' }) -join ' '
  $ownedProcess=Start-Process -FilePath $clientPath -ArgumentList $fixtureArguments -WindowStyle Hidden -PassThru -RedirectStandardOutput (Join-Path $PSScriptRoot 'native-audio-device.log') -RedirectStandardError (Join-Path $PSScriptRoot 'native-audio-device.stderr.log')
  $loaded=$null
  $deadline=[DateTime]::UtcNow.AddSeconds(3)
  while(-not $ownedProcess.HasExited -and [DateTime]::UtcNow -lt $deadline) {
    try {$loaded=$ownedProcess.Modules | Where-Object {$_.ModuleName -eq 'genesis-native-audio.dll'} | Select-Object -First 1} catch {}
    if($null -ne $loaded) { break }
    Start-Sleep -Milliseconds 10
    $ownedProcess.Refresh()
  }
  if($null -ne $loaded) {
    $receipt.loaded_module=[ordered]@{pid=$ownedProcess.Id;path=$loaded.FileName;sha256=(Digest $loaded.FileName)}
  }
  if(-not $ownedProcess.WaitForExit(5000)) { throw 'Owned device client exceeded its strict bounded duration.' }
  $ownedProcess.Refresh()
  $receipt.device_exit=$ownedProcess.ExitCode
  if($receipt.device_exit -ne 0) { throw 'Final candidate stereo/pan/silent/Stop gate failed.' }
  if($null -eq $receipt.loaded_module -or $receipt.loaded_module.sha256 -ne $ExpectedDllSha256 -or
     [IO.Path]::GetFullPath($receipt.loaded_module.path) -ne [IO.Path]::GetFullPath($adjacentDll)) {
    throw 'Actual loaded coherent client DLL was not proved.'
  }
  $receipt.fixtures=Get-Content -LiteralPath (Join-Path $PSScriptRoot 'fixtures.json') -Raw | ConvertFrom-Json
  $receipt.payload_unchanged=(Digest $appPath) -eq $ExpectedAppSha256 -and (Digest $dllPath) -eq $ExpectedDllSha256 -and
    (Digest $clientPath) -eq $bindings.client_sha256 -and (Digest $adjacentDll) -eq $ExpectedDllSha256 -and (Digest $build) -eq $ExpectedBuildReceiptSha256
  if(-not $receipt.payload_unchanged) { throw 'Candidate changed during device acceptance.' }
  $receipt.passed=$true
} catch {
  $receipt.failure=$_.Exception.Message
  throw
} finally {
  if($null -ne $ownedProcess -and -not $ownedProcess.HasExited) { $ownedProcess.Kill(); $ownedProcess.WaitForExit() }
  $receipt.all_owned_jobs_closed=$true
  $evidence=[ordered]@{}
  foreach($name in @('fixtures.json','fixtures.log','native-audio-clock.json','native-audio-clock.log','native-audio-device.log','native-audio-device.stderr.log')) {
    $target=Join-Path $PSScriptRoot $name
    if(Test-Path -LiteralPath $target) { $evidence[$name]=Digest $target }
  }
  $receipt.evidence=$evidence
  $receipt | ConvertTo-Json -Depth 12 | Set-Content -LiteralPath (Join-Path $PSScriptRoot 'receipt.json')
}
Get-Content -LiteralPath (Join-Path $PSScriptRoot 'native-audio-device.log')
Get-Content -LiteralPath (Join-Path $PSScriptRoot 'native-audio-clock.json')
