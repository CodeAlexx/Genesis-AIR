import hashlib
import json
import math
import struct
import wave
from pathlib import Path

root = Path(__file__).resolve().parent
rate = 48000
records = []
for name in ("stereo", "left", "silent"):
    target = root / (name + ".wav")
    data = bytearray()
    for frame in range(rate):
        left = round(32767 * .1 * math.sin(2 * math.pi * 440 * frame / rate)) if name != "silent" else 0
        right = round(32767 * .1 * math.sin(2 * math.pi * 880 * frame / rate)) if name == "stereo" else 0
        data.extend(struct.pack("<hh", left, right))
    with wave.open(str(target), "wb") as output:
        output.setnchannels(2)
        output.setsampwidth(2)
        output.setframerate(rate)
        output.writeframes(data)
    records.append(dict(name=name, sha256=hashlib.sha256(target.read_bytes()).hexdigest(),
                        frames=rate, channels=2, pcm_bits=16, rate=rate,
                        left_hz=440 if name != "silent" else 0,
                        right_hz=880 if name == "stereo" else 0, nominal_amplitude=.1))
(root / "fixtures.json").write_text(json.dumps(records, indent=2), encoding="utf-8")
print(json.dumps(records))
