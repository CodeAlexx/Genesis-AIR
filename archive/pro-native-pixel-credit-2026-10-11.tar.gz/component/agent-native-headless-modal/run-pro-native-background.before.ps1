param([string]$Prefix='pro-native-title-timing-2026-10-11')
$ErrorActionPreference='Stop'
$project=Split-Path -Parent $PSScriptRoot
$python='<USER>\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe'
$env:GENESIS_PRO_PREFIX=$Prefix
$log=Join-Path $PSScriptRoot ($prefix+'-background.log')
$status=Join-Path $PSScriptRoot ($prefix+'-background.exit')
if((Test-Path -LiteralPath $log) -or (Test-Path -LiteralPath $status)){throw 'Preserve existing acceptance receipts.'}
try {
  & $python (Join-Path $PSScriptRoot 'pro-native-checkpoint.py') verify
  if($LASTEXITCODE -ne 0){throw 'Frozen verification failed.'}
  if((Get-Content -LiteralPath (Join-Path $PSScriptRoot ($prefix+'-build.exit')) -Raw).Trim() -ne '0'){throw 'Coherent build required.'}
  $env:PATH='C:\MM-Air;'+(Split-Path -Parent $python)+';'+$env:PATH
  & (Join-Path $project 'tests/windows.ps1') -Bin (Join-Path $PSScriptRoot ($prefix+'-native/bin/Release')) -Worker (Join-Path $PSScriptRoot ($prefix+'-runtime/genesis-gcompose.exe')) -BackgroundOnly *> $log
  if($LASTEXITCODE -ne 0){throw 'Windows background acceptance failed.'}
  & $python (Join-Path $PSScriptRoot 'pro-native-checkpoint.py') verify >> $log
  if($LASTEXITCODE -ne 0){throw 'Source drift during acceptance.'}
  Set-Content -LiteralPath $status -Value '0' -NoNewline
}catch{$_ | Out-File -LiteralPath $log -Append;Set-Content -LiteralPath $status -Value '1' -NoNewline;throw}
