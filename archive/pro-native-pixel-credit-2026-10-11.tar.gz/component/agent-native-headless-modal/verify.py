import hashlib,json,os,shutil,subprocess
from pathlib import Path
root=Path(__file__).resolve().parents[2];work=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
expected=dict(line.split('\t',1) for line in (root/'tests/headless.expected.tsv').read_text(encoding='utf-8-sig').splitlines() if '\t' in line)
results=[]
windows=work/'native/Release/genesis-headless-modal.exe'
for folder in [windows.parent/'fonts',work/'fonts']:
 folder.mkdir(exist_ok=True)
 for name in ['NotoSansJP.ttf','OFL.txt']:
  source=root/'fonts'/name
  if source.exists():shutil.copyfile(source,folder/name)
def linuxpath(p):
 return subprocess.check_output(['wsl.exe','-d','Ubuntu','-u','root','--exec','wslpath','-a',str(p)],text=True).strip()
for platform in ['windows','linux']:
 check=work/('check-'+platform);check.mkdir(exist_ok=False)
 binary=windows if platform=='windows' else work/'genesis-headless-linux'
 args=[str(binary),str(check),str(check/'project.air'),str(check/'frame.png')]
 env=os.environ.copy();env.pop('GENESIS_FONT',None)
 if platform=='linux':
  args=['wsl.exe','-d','Ubuntu','-u','root','--exec','env','-u','GENESIS_FONT',linuxpath(binary),linuxpath(check),linuxpath(check/'project.air'),linuxpath(check/'frame.png')]
 cp=subprocess.run(args,cwd=root,env=env,capture_output=True,timeout=120)
 (check/'stdout.txt').write_bytes(cp.stdout);(check/'stderr.txt').write_bytes(cp.stderr)
 actual=dict(line.split('\t',1) for line in cp.stdout.decode('utf-8-sig').splitlines() if '\t' in line)
 mismatches=[dict(fact=k,expected=v,actual=actual.get(k)) for k,v in expected.items() if k!='status_pixel_r' and actual.get(k)!=v]
 drop={k:actual.get(k) for k in ['drop_imported','drop_count','drop_order']}
 passed=cp.returncode==0 and not mismatches and drop==dict(drop_imported='true',drop_count='2',drop_order='true')
 results.append(dict(platform=platform,passed=passed,exit_code=cp.returncode,saved_facts=sum(k!='status_pixel_r' for k in expected),native_drop_checks=3,mismatches=mismatches,drop=drop,client_sha256=sha(binary),stdout_sha256=sha(check/'stdout.txt'),stderr_sha256=sha(check/'stderr.txt'),modal_fact=actual.get('prompt_menu_blocked'),file_menu_fact=actual.get('menu_access_opens_file'),project_sha256=sha(check/'project.air') if (check/'project.air').exists() else None))
 print(json.dumps(results[-1]),flush=True)
receipt=dict(schema='genesis.headless.modal.focused.v1',passed=all(r['passed'] for r in results),before_sha256=sha(work/'before.json'),sources={p:sha(root/p) for p in ['tests/headless.ai','tests/headless.expected.tsv']},generated_c_sha256=sha(work/'headless.c'),build_log_sha256=sha(work/'build.log'),runtime_sha256=sha(root/'build-windows/pro-native-title-timing-stop-final-2026-10-11-native/runtime/Release/air_rt.lib'),results=results,scope='Fake-provider component Windows/Linux; no production modification, real device, GUI or full-suite acceptance')
with (work/'receipt.json').open('x',encoding='utf-8') as f:json.dump(receipt,f,indent=2)
raise SystemExit(int(not receipt['passed']))
