$ErrorActionPreference='Stop'
$repo='<ROOT>'
$prefix=Join-Path $repo 'build-windows/agent-native-headless-modal'
$sdkLinux=(& wsl.exe -d Ubuntu -u root --exec wslpath -a (Join-Path $repo 'build-windows/AIR-SDK')).Trim()
$source=(& wsl.exe -d Ubuntu -u root --exec wslpath -a (Join-Path $repo 'tests/headless.ai')).Trim()
$target=(& wsl.exe -d Ubuntu -u root --exec wslpath -a (Join-Path $prefix 'headless.c')).Trim()
$linuxPrefix=(& wsl.exe -d Ubuntu -u root --exec wslpath -a $prefix).Trim()
& wsl.exe -d Ubuntu -u root --exec env "AIR_STDLIB=$sdkLinux/stdlib" "XDG_CACHE_HOME=$linuxPrefix/xdg-cache" /root/Genesis-AIR-compiler/bin/airc build $source -o "$linuxPrefix/genesis-headless-linux" --mode release --provider hash.sha256=portable --keep-c $target
if($LASTEXITCODE -ne 0){throw 'Frontend refused'}
$cmake=Join-Path ${env:ProgramFiles(x86)} 'Microsoft Visual Studio/2022/BuildTools/Common7/IDE/CommonExtensions/Microsoft/CMake/CMake/bin/cmake.exe'
& $cmake -S $prefix -B (Join-Path $prefix 'native') -G 'Visual Studio 17 2022' -A x64
if($LASTEXITCODE -ne 0){throw 'Configure refused'}
& $cmake --build (Join-Path $prefix 'native') --config Release --parallel 2
if($LASTEXITCODE -ne 0){throw 'Native CPU build refused'}
