$ErrorActionPreference='Stop'
$repo='<ROOT>'
$prefix=Join-Path $repo 'build-windows/agent-native-timing-recorder'
$sdkLinux=(& wsl.exe -d Ubuntu -u root --exec wslpath -a (Join-Path $repo 'build-windows/AIR-SDK')).Trim()
foreach($name in @('window-cache','main')) {
 $input=if($name -eq 'main'){'src/main.ai'}else{'tests/window_cache.ai'}
 $source=(& wsl.exe -d Ubuntu -u root --exec wslpath -a (Join-Path $repo $input)).Trim()
 $target=(& wsl.exe -d Ubuntu -u root --exec wslpath -a (Join-Path $prefix ($name+'.c'))).Trim()
 & wsl.exe -d Ubuntu -u root --exec env "AIR_STDLIB=$sdkLinux/stdlib" /root/Genesis-AIR-compiler/bin/airc build $source -o "$target.bootstrap" --mode release --provider hash.sha256=portable --keep-c $target
 if($LASTEXITCODE -ne 0){throw "Frontend refused $name"}
}
$cmake=Join-Path ${env:ProgramFiles(x86)} 'Microsoft Visual Studio/2022/BuildTools/Common7/IDE/CommonExtensions/Microsoft/CMake/CMake/bin/cmake.exe'
& $cmake -S $prefix -B (Join-Path $prefix 'native') -G 'Visual Studio 17 2022' -A x64
if($LASTEXITCODE -ne 0){throw 'Configure refused'}
& $cmake --build (Join-Path $prefix 'native') --config Release --parallel 2
if($LASTEXITCODE -ne 0){throw 'Native CPU build refused'}
& (Join-Path $prefix 'native/Release/genesis-window-cache.exe') (Join-Path $prefix 'check')
if($LASTEXITCODE -ne 0){throw 'Recorder/cache focused gate failed'}
