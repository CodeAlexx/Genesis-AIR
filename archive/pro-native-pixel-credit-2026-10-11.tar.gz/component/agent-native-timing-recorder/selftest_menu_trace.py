"""CPU synthetic tests only: no process, media, window or device is launched."""
import copy
import hashlib
import importlib.util
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location("menu_parser",ROOT/"analyze_menu_trace.py")
parser=importlib.util.module_from_spec(spec)
spec.loader.exec_module(parser)


def source():
    rows=[]
    for frame in range(7500):
        row=dict.fromkeys(parser.FIELDS,0)
        begin=1_000_000_000+round(frame*1_000_000_000/60)
        row.update(loop_begin_ns=begin,present_begin_ns=begin+1_000_000,
          present_end_ns=begin+3_000_000,loop_end_ns=begin+3_100_000,
          signature_ns=100_000,paint_ns=900_000,present_ns=2_000_000,wait_ns=10_000,
          program_shown=frame,source_shown=0,heard_before=frame,heard_after=frame,
          samples_before=frame*800,samples_after=frame*800,queued_before=12000,
          queued_after=11800,audio_origin=0,fps=60.0,playing=1,clock_ok=1,present_ok=1,
          document_revision=1,media_revision=1,width=1280,height=720,prepared_frames=1,
          prepared_first_frame=frame+1,prepared_last_frame=frame+1,last_requested_frame=frame,
          received_request=frame+1,completed_packets=frame+1,window_first_id=frame+1,
          window_last_id=frame+1,window_first_frame=frame,window_last_frame=frame,
          window_count=1,owned_picture_credit=1,input_events=int(3600<=frame<3660))
        rows.append(row)
    paused=copy.deepcopy(rows[-1]);paused.update(playing=0,clock_ok=0,present_ok=0,
       window_count=0,window_first_id=0,window_last_id=0,window_first_frame=-1,
       window_last_frame=-1,present_ns=0,present_begin_ns=0,present_end_ns=0,
       loop_begin_ns=paused['loop_begin_ns']+20_000_000,
       loop_end_ns=paused['loop_end_ns']+20_000_000)
    rows.append(paused)
    return rows


def raw(rows):
    return ("\t".join(parser.FIELDS)+"\n"+"".join(
       "\t".join(str(r[k]) for k in parser.FIELDS)+"\n" for r in rows)).encode()


def run(rows):
    return parser.analyze(parser.read_rows(raw(rows)))


def main():
    cases=[]
    base=source();result=run(base)
    assert result['passed'],result['errors']
    assert result['selection']['first_row']==60
    assert result['selection']['last_row']==7468
    assert result['steady']['changed_pictures']==7409
    assert result['selection']['startup_samples']==48000
    assert result['selection']['terminal_samples_excluded']==24000
    assert result['selection']['input_rows_excluded']==0
    assert result['steady']['input_event_count']==60
    assert abs(result['steady']['pictures_per_second']-60)<1e-7
    assert len(result['all_raw_epochs'])==2
    cases.append(dict(name='fixed_first_one_second_all_rows_46_fields',passed=True))

    mutations={
      'late_three_frames':lambda r:r[3000].update(heard_after=3003),
      'early_picture':lambda r:r[3000].update(heard_before=2999),
      'queue_drained':lambda r:r[3000].update(queued_after=0),
      'capacity_nine':lambda r:r[3000].update(owned_picture_credit=7,reserved_picture_credit=2),
      'three_packet_reservation':lambda r:r[3000].update(reserved_picture_credit=3),
      'overwritten_packet':lambda r:r[3000].update(overwritten_packets=1),
      'counter_reset':lambda r:r[3000].update(completed_packets=2),
      'reused_request_identity':lambda r:r[3000].update(window_first_id=3000,window_last_id=3000),
      'nonconsecutive_window':lambda r:r[3000].update(window_count=2,window_last_id=3003),
      'unknown_received_packet':lambda r:r[3000].update(received_request=90000),
      'packet_not_yet_issued':lambda r:r[3000].update(received_request=7000),
      'unissued_frame_identity':lambda r:r[3000].update(program_shown=90000),
      'unclocked_present_not_hidden':lambda r:r[3000].update(clock_ok=0),
      'failed_present_not_hidden':lambda r:r[3000].update(present_ok=0),
      'inconsistent_enddraw':lambda r:r[3000].update(present_ns=1),
      'backward_sample':lambda r:r[3000].update(samples_after=r[3000]['samples_before']-1),
      'identity_edit_splits_first_epoch':lambda r:[x.update(document_revision=2) for x in r[3000:]],
      'first_short_epoch_no_later_selection':lambda r:r[100].update(playing=0),
      'skip_frame_position':lambda r:r.pop(3000),
      'backward_picture':lambda r:r[3000].update(program_shown=2998),
    }
    for name,mutate in mutations.items():
        rows=copy.deepcopy(base);mutate(rows);failed=run(rows)
        assert not failed['passed'],name
        cases.append(dict(name=name,passed=True,expected_refusals=failed['errors'][:3]))
    good=raw(base)
    malformed={
      'incomplete_final_line':good[:-1],
      'header_schema_loss':good.replace(b'owned_picture_credit',b'wrong_field',1),
      'nonfinite_fps':good.replace(b'60.0',b'nan',1),
      'incomplete_row':good.replace(b'\t60.0\t',b'\t\t',1),
    }
    for name,bad in malformed.items():
        try:parser.read_rows(bad)
        except ValueError as error:cases.append(dict(name=name,passed=True,expected_refusal=str(error)))
        else:raise AssertionError(name)
    historical=ROOT.parent/'cadence-reserve-gain-4k-26e2f631424046ddb7d5defae801c431/window-final.tsv'
    historic_result=parser.analyze(parser.read_rows(historical.read_bytes()))
    assert historic_result['passed'],historic_result['errors']
    assert historic_result['steady']['changed_picture_interval_seconds']==132.1706172
    assert abs(historic_result['steady']['pictures_per_second']-59.93767879597977)<1e-12
    cases.append(dict(name='historical_1A49_math_exact_no_current_acceptance',passed=True))
    receipt=dict(schema='genesis.native.menu-timing.parser-cpu.v1',passed=True,
      cases=len(cases),checks=cases,
      parser_sha256=hashlib.sha256((ROOT/'analyze_menu_trace.py').read_bytes()).hexdigest(),
      selftest_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
      historical_trace_sha256=hashlib.sha256(historical.read_bytes()).hexdigest(),
      historical=dict(app='1A49 historical only',steady_seconds=historic_result['steady']['changed_picture_interval_seconds'],
        pictures_per_second=historic_result['steady']['pictures_per_second']),
      current_native_acceptance=False,scope='Synthetic CPU parser proof and exact old-trace math only; no new app/device/window acceptance')
    with (ROOT/'parser-cpu-receipt-final-2.json').open('x',encoding='utf-8') as f:
        json.dump(receipt,f,indent=2);f.write('\n')
    print(json.dumps(dict(passed=True,cases=len(cases),receipt=str(ROOT/'parser-cpu-receipt-final-2.json'))))

if __name__=='__main__':main()
