"""Build-bound exclusive archive adapter; never alters the parser, gates, report or trace."""
import argparse,hashlib,json
from pathlib import Path
PARSER_SHA='5900d314c29b9e706eb793c7e60b3260ffe662b098a0682eb21a5e0acaf5de6e'
PAYLOAD_NAMES=dict(app='Genesis-AIR.exe',worker='genesis-gcompose.exe',audio_library='genesis-native-audio.dll')

def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for block in iter(lambda:f.read(1048576),b''):h.update(block)
 return h.hexdigest()
def load(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def require(value,message):
 if not value:raise ValueError(message)
def main():
 p=argparse.ArgumentParser(description=__doc__)
 p.add_argument('--run',type=Path,required=True);p.add_argument('--report',type=Path,required=True)
 p.add_argument('--output',type=Path,required=True);a=p.parse_args()
 run=a.run.resolve();report_path=a.report.resolve()
 require(not a.output.exists(),'Preserve prior archive acceptance summary')
 trace=run/'window-final.tsv';launch_path=run/'launch.json';identity_path=run/'identity.json';capture_path=run/'capture.json'
 bound_inputs={path:sha(path) for path in [launch_path,identity_path,capture_path,report_path,trace]}
 launch=load(launch_path);identity=load(identity_path);capture=load(capture_path);report=load(report_path)
 require(launch.get('schema')=='genesis.native.menu-run.capture.v1' and capture.get('schema')=='genesis.native.menu-run.closed-copy.v1','Require build-bound predeclared capture contract')
 build_path=Path(launch['build_receipt']).resolve()
 require(build_path.is_file() and not build_path.is_symlink(),'Actual ordinary build receipt required')
 build_sha=sha(build_path);bound_inputs[build_path]=build_sha
 require(build_sha==launch['build_receipt_sha256'],'Predeclared coherent build receipt changed')
 build=load(build_path)
 require(build.get('passed') is True,'Coherent build did not pass')
 expected={kind:build['payload_sha256'][name].lower() for kind,name in PAYLOAD_NAMES.items()}
 require(launch.get('expected_payload_sha256')==expected and capture.get('exact_payload_sha256')==expected,'Launch/capture exact coherent payload mismatch')
 for kind,digest in expected.items():
  payload=Path(launch[kind]).resolve()
  require(payload.is_file() and not payload.is_symlink() and sha(payload)==digest,'Actual build payload changed: '+kind)
  require(identity.get(kind+'_sha256')==launch.get(kind+'_sha256')==digest,'Exact build-bound run identity mismatch: '+kind)
  bound_inputs[payload]=digest
 require(report.get('schema')=='genesis.native.menu-timing.acceptance.v1' and report.get('passed') is True and report.get('errors')==[], 'Unchanged parser must pass with no errors')
 require(report.get('parser_sha256')==PARSER_SHA and sha(Path(__file__).with_name('analyze_menu_trace.py'))==PARSER_SHA,'Require exact frozen unchanged parser')
 require(report.get('identity')==identity and report.get('identity_sha256')==sha(identity_path),'Exact original nested identity mismatch')
 require(identity.get('launch_sha256')==sha(launch_path),'Predeclared launch identity mismatch')
 require(identity.get('intended_program_epoch')==0 and report.get('selected_program_epoch')==0,'First predetermined Program epoch only')
 for field in ['source_sha256','project_sha256']:
  require(identity[field]==launch[field],'Run asset identity mismatch: '+field)
 require(identity.get('fullscreen') is False and launch.get('fullscreen') is False and identity.get('monitor_size')==launch.get('monitor_size')==[480,270],'Ordinary fitted480x270 scope only')
 require(Path(report['raw_trace_path']).resolve()==trace and Path(identity['profile_path']).resolve()==trace,'Require actual exclusive window-final.tsv')
 trace_sha=sha(trace)
 require(report['raw_trace_sha256']==capture['window_final_sha256']==capture['original_trace_sha256']==trace_sha,'Closed raw trace identity mismatch')
 require(capture.get('captured') is True and capture.get('program_stopped_caller_observed') is True and capture.get('recorder_off_caller_observed') is True,'Actual caller Stop/off observations required')
 require(capture['launch_sha256']==sha(launch_path) and capture['identity_sha256']==sha(identity_path),'Closed capture metadata identity mismatch')
 original=Path(capture['original_profile'])
 require(original.resolve()==Path(launch['profile_path']).resolve() and sha(original)==trace_sha,'Original stopped trace must remain byte-identical')
 require(report.get('preserved_columns') and len(report['preserved_columns'])==46 and capture.get('columns')==46,'Full46-column schema required')
 selection=report['selection'];steady=report['steady']
 require(selection.get('startup_samples')==48000 and selection.get('terminal_samples_excluded')==24000 and selection.get('minimum_steady_seconds')==120 and selection.get('input_rows_excluded')==0,'Original predeclared selection contract must remain unchanged')
 require(steady['changed_picture_interval_seconds']>=120 and steady['device_sample_interval_seconds']>=120,'At least120 steady seconds in both native and device clocks')
 for field in ['skipped_frame_positions','repeated_picture_presentations','backwards_picture_jumps','early_picture_presentations','stale_picture_presentations_over_two_frames','clock_queue_zero_all_selected_rows','overwritten_packet_delta']:
  require(steady[field]==0,'Strict original cadence gate: '+field)
 require(steady['maximum_frame_jump']==1 and steady['program_lag_after_present_frames']['maximum']<=2,'Consecutive shown frame/<=2lag contract')
 require(report['credit']['max_total']<=8 and report['credit']['max_reserved']<=2,'Fixed8 owned+reserved and2window bound')
 original_hash=bound_inputs[report_path];bound_inputs[original.resolve()]=trace_sha
 summary=dict(schema='genesis.native.menu-timing.archive-summary.v1',accepted=True,passed=True,
  app_sha256=expected['app'],worker_sha256=expected['worker'],audio_library_sha256=expected['audio_library'],
  build_receipt_path=str(build_path),build_receipt_sha256=build_sha,expected_payload_sha256=expected,
  raw_profile_sha256=trace_sha,launch_sha256=sha(launch_path),identity_sha256=sha(identity_path),
  parser_report_sha256=original_hash,capture_sha256=sha(capture_path),
  parser_sha256=PARSER_SHA,adapter_sha256=sha(Path(__file__)),
  raw_profile_path=str(trace),launch_path=str(launch_path),parser_report_path=str(report_path),
  identity=identity,steady=steady,raw_selected_epoch=report['raw_selected_epoch'],
  original_parser_report=report,all_epochs_and_raw_rows_preserved=True,
  scope='Exact coherent-build-bound accepted unchanged menu parser result plus archive-compatible identity aliases only',
  acceptance_unchanged=True,fullscreen_4k_qualified=False,physical_av_synchronization_qualified=False,
  complete_professional_editing_acceptance=False)
 require(all(sha(path)==digest for path,digest in bound_inputs.items()),'Bound input changed during pure-file adaptation')
 with a.output.open('x',encoding='utf-8') as output:json.dump(summary,output,indent=2);output.write('\n')
 if not all(sha(path)==digest for path,digest in bound_inputs.items()):
  a.output.unlink()
  raise ValueError('Bound input changed while writing exclusive summary; output retired')
 print(json.dumps(dict(accepted=True,output=str(a.output.resolve()),app_sha256=expected['app'],raw_profile_sha256=trace_sha)))
if __name__=='__main__':main()
