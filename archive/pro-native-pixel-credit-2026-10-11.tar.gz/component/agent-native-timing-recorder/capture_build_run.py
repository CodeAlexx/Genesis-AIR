"""File-only native identity capture. Never queries/starts/stops processes or devices."""
import argparse,csv,datetime,hashlib,json,re,shutil
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
WORK=ROOT/'build-windows'
PAYLOAD_NAMES=dict(app='Genesis-AIR.exe',worker='genesis-gcompose.exe',audio_library='genesis-native-audio.dll')
PARSER_SHA='5900d314c29b9e706eb793c7e60b3260ffe662b098a0682eb21a5e0acaf5de6e'

def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for block in iter(lambda:f.read(1048576),b''):h.update(block)
 return h.hexdigest()
def load(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def write(p,value):
 with p.open('x',encoding='utf-8') as f:json.dump(value,f,indent=2);f.write('\n')
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def local(p):
 resolved=p.resolve()
 if not resolved.is_relative_to(WORK.resolve()) or p.is_symlink():raise ValueError('Output must be an ordinary private build-windows path')
 return resolved

def identities(a):
 if a.pid<=0 or a.window<=0:raise ValueError('Require actual observed process/window IDs')
 build_path=a.build_receipt.resolve()
 if build_path.is_symlink() or not build_path.is_file() or sha(build_path)!=a.build_receipt_sha256.lower():
  raise ValueError('Require predeclared exact coherent build receipt')
 build=load(build_path)
 if not build.get('passed'):raise ValueError('Coherent build did not pass')
 expected={kind:build['payload_sha256'][name].lower() for kind,name in PAYLOAD_NAMES.items()}
 result=dict(build_receipt=str(build_path),build_receipt_sha256=sha(build_path),expected_payload_sha256=expected)
 for kind in ['app','worker','audio_library','project','source']:
  p=getattr(a,kind).resolve()
  if p.is_symlink() or not p.is_file():raise ValueError('Require ordinary actual file: '+str(p))
  digest=sha(p)
  if kind in expected and digest!=expected[kind]:raise ValueError('Exact coherent build payload required: '+kind)
  result[kind]=str(p);result[kind+'_sha256']=digest
 if a.original_project:
  result['original_project']=str(a.original_project.resolve())
  result['original_project_sha256']=sha(a.original_project.resolve())
 return result

def prepare(a):
 data=identities(a);output=local(a.out);profile=a.profile.resolve()
 if profile.is_symlink() or not profile.is_file() or profile.suffix.lower()!='.tsv':raise ValueError('Require actual regular Help profile, including private LOCALAPPDATA session paths')
 parser=Path(__file__).with_name('analyze_menu_trace.py')
 if sha(parser)!=PARSER_SHA:raise ValueError('Acceptance parser changed')
 output.mkdir(exist_ok=False)
 launch=dict(schema='genesis.native.menu-run.capture.v1',**data,pid=a.pid,native_window_id=a.window,
  window=a.window,kind=a.kind,profile_path=str(profile),original_window_profile=str(profile),
  window_profile=str(output/'window-final.tsv'),intended_program_epoch=0,
  observed_utc=now(),monitor_size=[480,270],fullscreen=False,shell_window=False,
  launched_by_helper=False,trace_source='Help > Record playback timing',
  planned_selection='First uninterrupted Program epoch; first1s/final0.5s excluded, >=120steady native/device seconds',
  helper_sha256=sha(Path(__file__)),parser_sha256=PARSER_SHA,
  scope='Caller-observed native identity; no process or device observation performed by this file helper')
 write(output/'launch.json',launch)
 identity=dict(schema='genesis.native.menu-timing.identity.v1',intended_program_epoch=0,
  app_sha256=data['app_sha256'],worker_sha256=data['worker_sha256'],source_sha256=data['source_sha256'],
  project_sha256=data['project_sha256'],audio_library_sha256=data['audio_library_sha256'],
  pid=a.pid,native_window_id=a.window,fullscreen=False,monitor_size=[480,270],
  profile_path=str(output/'window-final.tsv'),predeclared_utc=launch['observed_utc'],
  launch_sha256=sha(output/'launch.json'))
 write(output/'identity.json',identity)
 print('Identity predeclared; no launch/recording or trace copy performed.')

def finish(a):
 output=local(a.out);launch=load(output/'launch.json')
 if not a.stopped or not a.recorder_off:raise ValueError('Caller must observe Program Stop and Help recording off first')
 if launch['helper_sha256']!=sha(Path(__file__)):raise ValueError('Capture helper changed during measurement')
 for kind in ['app','worker','audio_library','project','source','original_project','build_receipt']:
  if kind in launch and sha(Path(launch[kind]))!=launch[kind+'_sha256']:raise ValueError('Run asset changed: '+kind)
 source=Path(launch['profile_path'])
 if source.is_symlink() or not source.is_file():raise ValueError('Actual Help trace disappeared or changed file type')
 before=source.stat();raw=source.read_bytes();after=source.stat()
 if (before.st_size,before.st_mtime_ns)!=(after.st_size,after.st_mtime_ns):raise ValueError('Trace still changing: stop/off before capture')
 if not raw.endswith(b'\n'):raise ValueError('Incomplete final recorder row: preserve original')
 rows=raw.decode('utf-8-sig').splitlines()
 if len(rows)<2 or len(rows)>50001 or len(rows[0].split('\t'))!=46 or any(len(row.split('\t'))!=46 for row in rows[1:]):
  raise ValueError('Require complete46-column/<=50000-row trace; never discard raw rows')
 target=output/'window-final.tsv'
 with target.open('xb') as f:f.write(raw)
 digest=hashlib.sha256(raw).hexdigest()
 if sha(target)!=digest or sha(source)!=digest:raise ValueError('Stopped original/copy hash mismatch')
 write(output/'capture.json',dict(schema='genesis.native.menu-run.closed-copy.v1',captured=True,
  capture_utc=now(),original_profile=str(source),original_trace_sha256=digest,window_final_sha256=digest,
  raw_rows=len(rows)-1,columns=46,launch_sha256=sha(output/'launch.json'),identity_sha256=sha(output/'identity.json'),
  exact_payload_sha256=launch['expected_payload_sha256'],program_stopped_caller_observed=True,recorder_off_caller_observed=True,
  cadence_acceptance_pending=True,complete_professional_editing_acceptance=False))
 print('Closed raw trace copied exclusively. Run unchanged parser separately with identity.json -> analysis.json.')

def root_ready(a):
 data=identities(a)
 if Path(data['app'])!=ROOT/'Genesis-AIR.exe' or Path(data['worker'])!=ROOT/'genesis-gcompose.exe' or Path(data['audio_library'])!=ROOT/'genesis-native-audio.dll':
  raise ValueError('Root-ready must bind actual published root files')
 publication=load(a.publication)
 expected=data['expected_payload_sha256']
 if not publication.get('published') or any(publication['root_binary_sha256'].get(name)!=digest for name,digest in [
  ('Genesis-AIR.exe',expected['app']),('genesis-gcompose.exe',expected['worker']),('genesis-native-audio.dll',expected['audio_library'])]):
  raise ValueError('Exact qualified root publication required')
 observations=load(a.observations)
 if observations.get('pid')!=a.pid or observations.get('window',observations.get('native_window_id'))!=a.window:
  raise ValueError('Caller GUI observations must name exact root process/window')
 target=local(a.receipt)
 write(target,dict(schema='genesis.pro-native.root-ready.identity.v1',passed=True,
  **data,pid=a.pid,window=a.window,observed_utc=now(),publication_sha256=sha(a.publication),
  ui_observations_sha256=sha(a.observations),ui_observations_path=str(a.observations.resolve()),
  scope='Published root file identities and hash-bound caller GUI observations only',
  complete_professional_editing_acceptance=False,physical_av_synchronization_qualified=False,
  cadence_receipts_required_separately=True))
 print('Exclusive root identity receipt captured; no desktop/process/device operation performed.')

def identity_args(p):
 p.add_argument('--build-receipt',type=Path,required=True)
 p.add_argument('--build-receipt-sha256',required=True)
 p.add_argument('--pid',type=int,required=True);p.add_argument('--window',type=int,required=True)
 for name in ['app','worker','audio-library','project','source']:
  p.add_argument('--'+name,type=Path,required=True)
 p.add_argument('--original-project',type=Path)
def main():
 p=argparse.ArgumentParser(description=__doc__);s=p.add_subparsers(dest='operation',required=True)
 start=s.add_parser('prepare');identity_args(start);start.add_argument('--out',type=Path,required=True)
 start.add_argument('--profile',type=Path,required=True);start.add_argument('--kind',choices=['1080p60','4k5994'],required=True)
 stop=s.add_parser('finish');stop.add_argument('--out',type=Path,required=True)
 stop.add_argument('--stopped',action='store_true');stop.add_argument('--recorder-off',action='store_true')
 ready=s.add_parser('root-ready');identity_args(ready)
 for name in ['publication','observations','receipt']:ready.add_argument('--'+name,type=Path,required=True)
 a=p.parse_args();{'prepare':prepare,'finish':finish,'root-ready':root_ready}[a.operation](a)
if __name__=='__main__':main()
