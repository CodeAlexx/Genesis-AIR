"""Read a CLOSED Help timing trace; fixed prior reserve-gain rules, no interval fishing.

Acceptance requires the predetermined FIRST Program epoch. First 1.0 device
second / final 0.5 device second are excluded, exactly as the prior 1A49 gate.
At least 120 steady seconds are required. Input rows remain in acceptance.
This never launches a process or observes a speaker/display photon.
"""
import argparse
import csv
import hashlib
import json
import math
from pathlib import Path
import statistics

FIELDS = (
    "loop_begin_ns present_begin_ns present_end_ns loop_end_ns signature_ns paint_ns present_ns wait_ns "
    "program_shown source_shown heard_before heard_after samples_before samples_after queued_before queued_after "
    "audio_origin fps source_mode playing clock_ok present_ok document_revision media_revision width height "
    "prepared_frames snapshot_generation audio_cache_rebuilds strip_requests input_events diagnostic_previous_ns "
    "prepared_first_frame prepared_last_frame last_requested_frame in_flight_request received_request "
    "completed_packets overwritten_packets window_first_id window_last_id window_first_frame window_last_frame "
    "window_count owned_picture_credit reserved_picture_credit"
).split()
IDENTITY = ("source_mode", "audio_origin", "fps", "document_revision", "media_revision", "width", "height")
SR = 48000


def sha(data):
    return hashlib.sha256(data).hexdigest()


def stats(values):
    values = sorted(values)
    if not values:
        return dict(count=0, median=None, p95=None, maximum=None)
    return dict(count=len(values), median=statistics.median(values),
                p95=values[int((len(values)-1)*.95)], maximum=values[-1])


def measure(rows):
    shown = [r for r in rows if r["present_ok"] and r["present_ns"] > 0 and r["clock_ok"]
             and r["source_shown" if r["source_mode"] else "program_shown"] >= 0]
    def frame(r):
        return r["source_shown" if r["source_mode"] else "program_shown"]
    changed = []
    for r in shown:
        if not changed or frame(r) != frame(changed[-1]):
            changed.append(r)
    jumps = [frame(b)-frame(a) for a,b in zip(changed,changed[1:])]
    gaps = [(b["present_end_ns"]-a["present_end_ns"])/1e6 for a,b in zip(changed,changed[1:])]
    interval = (changed[-1]["present_end_ns"]-changed[0]["present_end_ns"])/1e9 if len(changed)>1 else 0
    before = [r["heard_before"]-frame(r) for r in shown]
    after = [r["heard_after"]-frame(r) for r in shown]
    return dict(rows=len(rows), presentations=len(shown), changed_pictures=len(changed),
        repeated_picture_presentations=len(shown)-len(changed),
        changed_picture_interval_seconds=interval,
        device_sample_interval_seconds=(shown[-1]["samples_after"]-shown[0]["samples_after"])/SR if len(shown)>1 else 0,
        pictures_per_second=(len(changed)-1)/interval if interval else None,
        first_frame=frame(changed[0]) if changed else None, last_frame=frame(changed[-1]) if changed else None,
        skipped_frame_positions=sum(max(0,j-1) for j in jumps), maximum_frame_jump=max(jumps,default=0),
        backwards_picture_jumps=sum(j<0 for j in jumps),
        stale_picture_presentations_over_two_frames=sum(x>2 for x in after),
        early_picture_presentations=sum(x<0 for x in before),
        program_lag_before_present_frames=stats(before), program_lag_after_present_frames=stats(after),
        picture_gap_ms=stats(gaps),
        clock_queue_zero_all_selected_rows=sum(r["queued_before"]==0 or r["queued_after"]==0 for r in rows if r["clock_ok"]),
        completed_packet_delta=rows[-1]["completed_packets"]-rows[0]["completed_packets"] if rows else 0,
        overwritten_packet_delta=max((r["overwritten_packets"] for r in rows),default=0)-min((r["overwritten_packets"] for r in rows),default=0),
        input_event_rows=sum(r["input_events"]>0 for r in rows), input_event_count=sum(r["input_events"] for r in rows),
        phases_ms={name:stats([r[name]/1e6 for r in shown]) for name in
            ("signature_ns","paint_ns","present_ns","wait_ns","diagnostic_previous_ns")},
        frame_gap_events=[dict(row=a["_row"],next_row=b["_row"],from_frame=frame(a),to_frame=frame(b),
             gap_ms=(b["present_end_ns"]-a["present_end_ns"])/1e6)
             for a,b in zip(changed,changed[1:]) if frame(b)-frame(a)>1],
        late_events=[dict(row=r["_row"],shown=frame(r),heard_before=r["heard_before"],heard_after=r["heard_after"],
             present_ms=r["present_ns"]/1e6,prepared=r["prepared_frames"],requested=r["last_requested_frame"])
             for r in shown if r["heard_after"]-frame(r)>2])


def read_rows(raw):
    if not raw.endswith(b"\n"):
        raise ValueError("Trace lacks final newline; stop the recorder and preserve the incomplete trace")
    reader=csv.DictReader(raw.decode("utf-8-sig").splitlines(),delimiter="\t")
    if reader.fieldnames != FIELDS:
        raise ValueError("Require the exact ordered 46-column native schema")
    rows=[]
    for index,values in enumerate(reader):
        if None in values or any(v in (None,"") for v in values.values()):
            raise ValueError(f"Incomplete/extra fields at row {index}; no row is silently discarded")
        row={k:float(v) if k=="fps" else int(v) for k,v in values.items()}
        if not math.isfinite(row["fps"]) or row["fps"]<0:
            raise ValueError(f"Nonfinite/negative fps at row {index}")
        if any(row[k] not in (0,1) for k in ("playing","source_mode","clock_ok","present_ok")):
            raise ValueError(f"Invalid flag at row {index}")
        row["_row"]=index
        rows.append(row)
    if not rows or len(rows)>50000:
        raise ValueError("Require 1..50,000 complete rows")
    return rows


def segments(rows):
    result=[]
    current=[]
    last_samples=None
    for r in rows:
        signature=(r["playing"],)+tuple(r[k] for k in IDENTITY)
        old=(current[-1]["playing"],)+tuple(current[-1][k] for k in IDENTITY) if current else None
        reset=bool(r["clock_ok"] and last_samples is not None and r["samples_before"]<last_samples)
        if current and (signature!=old or reset):
            result.append(current)
            current=[]
            last_samples=None
        current.append(r)
        if r["clock_ok"]:
            last_samples=r["samples_before"]
    if current:
        result.append(current)
    return result


def credit_errors(rows):
    errors=[]
    issued={}
    previous_id=0
    for r in rows:
        n=r["_row"]
        owned,reserved=r["owned_picture_credit"],r["reserved_picture_credit"]
        if owned<0 or reserved<0 or owned+reserved>8 or reserved>2 or not 0<=r["prepared_frames"]<=8:
            errors.append(f"row {n}: fixed eight owned+reserved/two reservation bound violated")
        count=r["window_count"]
        if count:
            first,last=r["window_first_id"],r["window_last_id"]
            start,end=r["window_first_frame"],r["window_last_frame"]
            if count not in (1,2) or first<=0 or last-first+1!=count or end-start+1!=count:
                errors.append(f"row {n}: nonconsecutive individual IDs/frames in a producer window")
                continue
            if first<=previous_id:
                errors.append(f"row {n}: issued window identity reused/backward")
            previous_id=last
            for offset in range(count):
                issued[first+offset]=(r["source_mode"],r["document_revision"],r["media_revision"],start+offset,n)
    return errors,issued


def analyze(rows):
    errors=[]
    for i,r in enumerate(rows):
        if r["loop_begin_ns"]<=0 or r["loop_end_ns"]<r["loop_begin_ns"]:
            errors.append(f"row {i}: invalid loop timestamp (including first newly enabled row)")
        if i and r["loop_begin_ns"]<rows[i-1]["loop_begin_ns"]:
            errors.append(f"row {i}: backwards loop timestamp")
        if r["present_ok"] and (r["present_end_ns"]<r["present_begin_ns"] or
                r["present_ns"]!=r["present_end_ns"]-r["present_begin_ns"]):
            errors.append(f"row {i}: inconsistent actual EndDraw duration")
        if r["clock_ok"] and r["samples_after"]<r["samples_before"]:
            errors.append(f"row {i}: device clock moved backward inside a presentation")
    credit,issued=credit_errors(rows)
    errors.extend(credit)
    epochs=segments(rows)
    all_epochs=[]
    for index,epoch in enumerate(epochs):
        all_epochs.append(dict(segment=index,first_row=epoch[0]["_row"],end_row_exclusive=epoch[-1]["_row"]+1,
            identity={k:epoch[0][k] for k in IDENTITY},playing=bool(epoch[0]["playing"]),
            wall_seconds=(epoch[-1]["loop_end_ns"]-epoch[0]["loop_begin_ns"])/1e9,raw=measure(epoch)))
    candidates=[(index,epoch) for index,epoch in enumerate(epochs) if epoch[0]["playing"] and not epoch[0]["source_mode"]]
    if not candidates:
        return dict(errors=errors+["No Program playback epoch"],all_raw_epochs=all_epochs,passed=False)
    index,epoch=candidates[0]  # Fixed BEFORE seeing its failures; never choose a later epoch.
    maximum=max((r["samples_after"] for r in epoch if r["clock_ok"]),default=0)
    cutoff=maximum-24000
    steady=[r for r in epoch if r["clock_ok"] and r["samples_before"]>=48000 and r["samples_after"]<cutoff]
    full,body=measure(epoch),measure(steady)
    if body["changed_picture_interval_seconds"]<120 or body["device_sample_interval_seconds"]<120:
        errors.append("First predetermined Program epoch has fewer than 120 steady native/device seconds")
    for field in ("skipped_frame_positions","backwards_picture_jumps","early_picture_presentations",
            "stale_picture_presentations_over_two_frames","clock_queue_zero_all_selected_rows","overwritten_packet_delta"):
        if body[field]:
            errors.append(f"Steady {field} = {body[field]}")
    if body["maximum_frame_jump"]>1:
        errors.append("Steady changed pictures are not consecutive")
    if full["backwards_picture_jumps"] or full["early_picture_presentations"] or full["overwritten_packet_delta"]:
        errors.append("Raw selected epoch contains backwards/early/overwritten pictures")
    if steady:
        region=[r for r in epoch if steady[0]["_row"]<=r["_row"]<=steady[-1]["_row"]]
        if any(r["present_ok"] and not r["clock_ok"] for r in region):
            errors.append("Unclocked native presentation inside steady region cannot be excluded")
        if any(not r["present_ok"] and r["present_ns"]>0 for r in region):
            errors.append("Native presenter failure inside steady region")
        if any(b["overwritten_packets"]<a["overwritten_packets"] or b["completed_packets"]<a["completed_packets"]
               for a,b in zip(region,region[1:])):
            errors.append("Transport counters reset inside steady region")
        owned={}
        for value in issued.values():
            owned[value[:4]]=min(owned.get(value[:4],value[4]),value[4])
        for r in steady:
            if r["present_ok"] and owned.get((0,r["document_revision"],r["media_revision"],r["program_shown"]),r["_row"]+1)>r["_row"]:
                errors.append(f"row {r['_row']}: shown steady frame has no matching issued Program/document identity")
            received=r["received_request"]
            if received and (received not in issued or issued[received][:3] !=
                    (0,r["document_revision"],r["media_revision"]) or issued[received][4]>r["_row"]):
                errors.append(f"row {r['_row']}: received packet has no current Program/document issued identity")
    intervals=[]
    for r in steady:
        has_input=bool(r["input_events"])
        if not intervals or bool(intervals[-1][0]["input_events"])!=has_input:
            intervals.append([])
        intervals[-1].append(r)
    return dict(passed=not errors,errors=errors,all_raw_epochs=all_epochs,
        selected_program_epoch=0,selected_segment=index,raw_selected_epoch=full,steady=body,
        selection=dict(startup_samples=48000,terminal_samples_excluded=24000,cutoff_samples=cutoff,
            exact="clock_ok and samples_before >= 48000 and samples_after < max_epoch_samples_after - 24000",
            first_row=steady[0]["_row"] if steady else None,last_row=steady[-1]["_row"] if steady else None,
            minimum_steady_seconds=120,input_rows_excluded=0),
        input_intervals=[dict(first_row=part[0]["_row"],end_row_exclusive=part[-1]["_row"]+1,
            has_input=bool(part[0]["input_events"]),measurement=measure(part)) for part in intervals],
        input_active=measure([r for r in steady if r["input_events"]]),
        input_idle=measure([r for r in steady if not r["input_events"]]),
        credit=dict(max_owned=max(r["owned_picture_credit"] for r in rows),
            max_reserved=max(r["reserved_picture_credit"] for r in rows),
            max_total=max(r["owned_picture_credit"]+r["reserved_picture_credit"] for r in rows),
            issued_individual_ids=len(issued)))


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("trace",type=Path)
    p.add_argument("--identity",type=Path,required=True)
    p.add_argument("--report",type=Path,required=True)
    args=p.parse_args()
    raw=args.trace.read_bytes()
    identity_raw=args.identity.read_bytes()
    identity=json.loads(identity_raw.decode("utf-8-sig"))
    if identity.get("schema")!="genesis.native.menu-timing.identity.v1" or identity.get("intended_program_epoch")!=0:
        raise ValueError("Require predeclared first Program epoch identity receipt")
    for key in ("app_sha256","worker_sha256","source_sha256","project_sha256"):
        value=identity.get(key,"")
        if len(value)!=64 or any(c not in "0123456789abcdefABCDEF" for c in value):
            raise ValueError(f"Missing/invalid {key}")
    if identity.get("fullscreen") is not False or identity.get("monitor_size")!=[480,270]:
        raise ValueError("This acceptance is ordinary fitted480x270 only; fullscreen4K is deferred")
    if identity.get("pid",0)<=0 or identity.get("native_window_id",0)<=0:
        raise ValueError("Require observed native process/window identity")
    if Path(identity.get("profile_path","")).resolve()!=args.trace.resolve():
        raise ValueError("Identity must name this exact stopped trace")
    result=analyze(read_rows(raw))
    result.update(schema="genesis.native.menu-timing.acceptance.v1",identity=identity,
        identity_sha256=sha(identity_raw),raw_trace_path=str(args.trace.resolve()),raw_trace_sha256=sha(raw),
        raw_trace_bytes=len(raw),parser_sha256=sha(Path(__file__).read_bytes()),
        preserved_columns=FIELDS,scope="Actual native handoff/EndDraw plus real device sample clock; all trace rows retained",
        limitations=["No independent source-pixel identity oracle for every displayed frame.",
            "No physical speaker/photon synchronization acceptance.",
            "No fullscreen4K, compound4K60, whole-source-duration or complete professional editing acceptance.",
            "Input-active/idle aggregates may cross noncontiguous intervals; separate contiguous interval reports are retained."])
    with args.report.open("x",encoding="utf-8") as output:
        json.dump(result,output,indent=2)
        output.write("\n")
    print(json.dumps(dict(passed=result["passed"],errors=result["errors"],
        steady=result.get("steady"),raw_trace_sha256=result["raw_trace_sha256"]),indent=2))
    return int(not result["passed"])


if __name__=="__main__":
    raise SystemExit(main())
