"""Exclusive archive adapter; never alters the parser, acceptance gates, report or trace."""
import argparse,hashlib,json
from pathlib import Path
PARSER_SHA='5900d314c29b9e706eb793c7e60b3260ffe662b098a0682eb21a5e0acaf5de6e'
APP_SHA='f7185c70a51025c04b9ee33c490bbbf9c65418ccb619a067faba3ca98cc65292'
WORKER_SHA='aa40b96c631c82cfc834d027678e95a00bd8d5f61db54f15e7c7ecefcf74228c'
AUDIO_SHA='342dc9ae62327f98a90b6387697e69dce37cce5414be821afe9a560472b816e6'

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def load(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def require(value,message):
 if not value:raise ValueError(message)
def main():
 p=argparse.ArgumentParser(description=__doc__)
 p.add_argument('--run',type=Path,required=True);p.add_argument('--report',type=Path,required=True)
 p.add_argument('--output',type=Path,required=True);a=p.parse_args()
 run=a.run.resolve();report_path=a.report.resolve()
 require(not a.output.exists(),'Preserve prior archive acceptance summary')
 trace=run/'window-final.tsv';launch_path=run/'launch.json';identity_path=run/'identity.json';capture_path=run/'capture.json'
 launch=load(launch_path);identity=load(identity_path);capture=load(capture_path);report=load(report_path)
 require(report.get('schema')=='genesis.native.menu-timing.acceptance.v1' and report.get('passed') is True and report.get('errors')==[], 'Unchanged parser must pass with no errors')
 require(report.get('parser_sha256')==PARSER_SHA and sha(Path(__file__).with_name('analyze_menu_trace.py'))==PARSER_SHA,'Require exact frozen unchanged parser')
 require(report.get('identity')==identity and report.get('identity_sha256')==sha(identity_path),'Exact original nested identity mismatch')
 require(identity.get('launch_sha256')==sha(launch_path),'Predeclared launch identity mismatch')
 require(identity.get('intended_program_epoch')==0 and report.get('selected_program_epoch')==0,'First predetermined Program epoch only')
 require(identity.get('app_sha256')==launch.get('app_sha256')==APP_SHA and identity.get('worker_sha256')==launch.get('worker_sha256')==WORKER_SHA and identity.get('audio_library_sha256')==launch.get('audio_library_sha256')==AUDIO_SHA,'Exact F718/AA40/342D run required')
 for field in ['source_sha256','project_sha256']:
  require(identity[field]==launch[field],'Run asset identity mismatch: '+field)
 require(identity.get('fullscreen') is False and launch.get('fullscreen') is False and identity.get('monitor_size')==launch.get('monitor_size')==[480,270],'Ordinary fitted480x270 scope only')
 require(Path(report['raw_trace_path']).resolve()==trace and Path(identity['profile_path']).resolve()==trace,'Require actual exclusive window-final.tsv')
 trace_sha=sha(trace)
 require(report['raw_trace_sha256']==capture['window_final_sha256']==capture['original_trace_sha256']==trace_sha,'Closed raw trace identity mismatch')
 require(capture.get('captured') is True and capture.get('program_stopped_caller_observed') is True and capture.get('recorder_off_caller_observed') is True,'Actual caller Stop/off observations required')
 require(capture['launch_sha256']==sha(launch_path) and capture['identity_sha256']==sha(identity_path),'Closed capture metadata identity mismatch')
 original=Path(capture['original_profile'])
 require(original.resolve()==Path(launch['profile_path']).resolve() and sha(original)==trace_sha,'Original stopped trace must remain byte-identical')
 require(report.get('preserved_columns') and len(report['preserved_columns'])==46 and capture.get('columns')==46,'Full46-column schema required')
 selection=report['selection'];steady=report['steady']
 require(selection.get('startup_samples')==48000 and selection.get('terminal_samples_excluded')==24000 and selection.get('minimum_steady_seconds')==120 and selection.get('input_rows_excluded')==0,'Original predeclared selection contract must remain unchanged')
 require(steady['changed_picture_interval_seconds']>=120 and steady['device_sample_interval_seconds']>=120,'At least120 steady seconds in both native and device clocks')
 for field in ['skipped_frame_positions','backwards_picture_jumps','early_picture_presentations','stale_picture_presentations_over_two_frames','clock_queue_zero_all_selected_rows','overwritten_packet_delta']:
  require(steady[field]==0,'Strict original cadence gate: '+field)
 require(steady['maximum_frame_jump']==1 and steady['program_lag_after_present_frames']['maximum']<=2,'Consecutive shown frame/<=2lag contract')
 require(report['credit']['max_total']<=8 and report['credit']['max_reserved']<=2,'Fixed8 owned+reserved and2window bound')
 original_hash=sha(report_path)
 summary=dict(schema='genesis.native.menu-timing.archive-summary.v1',accepted=True,passed=True,
  app_sha256=APP_SHA,worker_sha256=WORKER_SHA,audio_library_sha256=AUDIO_SHA,
  raw_profile_sha256=trace_sha,launch_sha256=sha(launch_path),identity_sha256=sha(identity_path),
  parser_report_sha256=original_hash,capture_sha256=sha(capture_path),
  parser_sha256=PARSER_SHA,adapter_sha256=sha(Path(__file__)),
  raw_profile_path=str(trace),launch_path=str(launch_path),parser_report_path=str(report_path),
  identity=identity,steady=steady,raw_selected_epoch=report['raw_selected_epoch'],
  original_parser_report=report,all_epochs_and_raw_rows_preserved=True,
  scope='Exact accepted unchanged menu parser result plus archive-compatible identity aliases only',
  acceptance_unchanged=True,fullscreen_4k_qualified=False,physical_av_synchronization_qualified=False,
  complete_professional_editing_acceptance=False)
 with a.output.open('x',encoding='utf-8') as output:json.dump(summary,output,indent=2);output.write('\n')
 require(sha(report_path)==original_hash and sha(trace)==trace_sha,'Input changed during pure-file adaptation')
 print(json.dumps(dict(accepted=True,output=str(a.output.resolve()),app_sha256=APP_SHA,raw_profile_sha256=trace_sha)))
if __name__=='__main__':main()
