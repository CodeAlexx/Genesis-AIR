from pathlib import Path
import datetime, hashlib, json, shutil, subprocess, sys, os

ROOT = Path(__file__).resolve().parent.parent
WORK = ROOT / 'build-windows'
PREFIX = os.environ.get('GENESIS_PRO_PREFIX','pro-native-title-timing-2026-10-11')

def sha(p):
    h = hashlib.sha256()
    with Path(p).open('rb') as f:
        for block in iter(lambda: f.read(1048576), b''): h.update(block)
    return h.hexdigest()

def read(p): return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def write(p, data):
    with Path(p).open('x', encoding='utf-8') as f: json.dump(data, f, indent=2)

def repository_path(value):
    path = Path(value)
    if not path.is_absolute(): path = ROOT/path
    path = path.resolve()
    assert path.is_relative_to(ROOT), ('Expected repository evidence',value)
    return path

def evidence_path(value):
    path=repository_path(value)
    assert path.is_file(), ('Expected existing repository evidence',value)
    return path

def accepted_background(build):
    # Only publish consults this opt-in. prepare/verify/build-receipt remain unchanged.
    original_log=WORK/(PREFIX+'-background.log')
    original_exit=WORK/(PREFIX+'-background.exit')
    selected=os.environ.get('GENESIS_PRO_BACKGROUND_RECEIPT')
    if not selected:
        assert original_exit.read_text().strip()=='0'
        return {'log':original_log,'exit':original_exit,'receipt':None,'bound':{}}
    receipt=evidence_path(selected);report=read(receipt)
    assert report.get('passed') is True and report.get('exit')==0, 'Selected background receipt not accepted'
    assert report['build_receipt_sha256'].lower()==sha(WORK/(PREFIX+'-build-receipt.json'))
    assert report['app_sha256'].lower()==build['payload_sha256']['Genesis-AIR.exe'].lower()
    assert report['worker_sha256'].lower()==build['payload_sha256']['genesis-gcompose.exe'].lower()
    assert build['native_binary_sha256']['Genesis-AIR.exe'].lower()==report['app_sha256'].lower()
    suffix='-background-receipt.json'
    assert receipt.name.endswith(suffix), 'Use standard accepted attempt receipt name'
    stem=receipt.name[:-len(suffix)]
    log=evidence_path(report.get('log_path',receipt.with_name(stem+'-background.log')))
    status=evidence_path(report.get('exit_path',receipt.with_name(stem+'-background.exit')))
    assert status.read_text().strip()=='0' and sha(log)==report['log_sha256'].lower()
    evidence=report.get('evidence');origins=report.get('evidence_origins')
    assert isinstance(evidence,dict) and evidence and isinstance(origins,dict), 'Accepted attempt requires immutable evidence/origins'
    bound={receipt:sha(receipt),log:sha(log),status:sha(status)}
    for name,expected in evidence.items():
        path=evidence_path(name);assert sha(path)==expected.lower(), ('Background evidence drift',name)
        bound[path]=expected.lower()
    for path in (log,status):
        assert any(repository_path(origin)==path and evidence[name].lower()==sha(path)
                   for name,origin in origins.items() if name in evidence), ('Accepted log/exit not bound by receipt',str(path))
    # Keep the failed original's identity in publication; never rewrite it.
    history={}
    for name,path in [('log',original_log),('exit',original_exit)]:
        if path.exists():
            history[name+'_path']=path.relative_to(ROOT).as_posix()
            history[name+'_sha256']=sha(path);bound[path]=sha(path)
            if name=='exit':history['exit_value']=path.read_text().strip()
    return {'log':log,'exit':status,'receipt':receipt,'bound':bound,'history':history}

def prepare():
    old = read(WORK/'linked-lanes-contract-final-frozen.json')
    baseline_name = os.environ.get('GENESIS_PRO_BASE_PREFIX','linked-lanes-contract-final')+'-publication.json'
    publication = read(WORK/baseline_name)
    for base, pin in [(WORK/'AIR-SDK', old['sdk_pin']), (WORK/'gcompose-source/gcompose', old['worker_pin'])]:
        assert subprocess.check_output(['git','rev-parse','HEAD'], cwd=base, text=True).strip() == pin
    for n,h in publication['root_binary_sha256'].items(): assert sha(ROOT/n) == h, n
    names = subprocess.check_output(['git','ls-files','-z','--','src','tests','windows','patches','build-windows.ps1','build.sh'],cwd=ROOT).decode().split('\0')
    sources = sorted(set(n for n in names if n))
    sdk_names = subprocess.check_output(['git','ls-files','-z','--','runtime','stdlib','toolkits/desktop'],
      cwd=WORK/'AIR-SDK').decode().split('\0')
    sdk_sources = sorted(set(old['sdk_source_sha256']) | set(n for n in sdk_names if n))
    protected = [ROOT/'Costa Rica 4K.air',ROOT/'Regular 1080p60.air']
    protected += [Path(r'<PRIVATE_PATH:86df8e29ecb4>','Which is The Best Qwen3.8-27B_.mp4']]
    frozen = {'schema':'genesis.pro-native.frozen.v1','captured_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
      'baseline_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),
      'sdk_pin':old['sdk_pin'],'worker_pin':old['worker_pin'],
      'source_sha256':{n:sha(ROOT/n) for n in sources},
      'sdk_source_sha256':{n:sha(WORK/'AIR-SDK'/n) for n in sdk_sources},
      'worker_source_sha256':{n:sha(WORK/'gcompose-source/gcompose'/n) for n in old['worker_source_sha256']},
      'baseline_payload':publication['root_binary_sha256'],
      'protected_assets':{str(p):sha(p) for p in protected},
      'runtime_sha256':sha(ROOT/'genesis-media-runtime.txt'),
      'baseline_publication_path':baseline_name,
      'baseline_publication_sha256':sha(WORK/baseline_name)}
    stage=WORK/(PREFIX+'-runtime'); stage.mkdir()
    snapshot=WORK/(PREFIX+'-source'); snapshot.mkdir()
    prior=WORK/(PREFIX+'-prior-reports'); prior.mkdir()
    for p in WORK.iterdir():
        if p.is_file() and p.suffix in ('.json','.log','.txt','.tsv'): shutil.copyfile(p,prior/p.name)
    for n in frozen['baseline_payload']: shutil.copyfile(ROOT/n,stage/n)
    shutil.copyfile(ROOT/'genesis-media-runtime.txt',stage/'genesis-media-runtime.txt')
    shutil.copytree(ROOT/'fonts',stage/'fonts')
    for n in sources:
        target=snapshot/n; target.parent.mkdir(parents=True,exist_ok=True); shutil.copyfile(ROOT/n,target)
    write(WORK/(PREFIX+'-frozen.json'),frozen)
    print('New candidate frozen against verified installed baseline; prior reports and original media preserved.')

def verify():
    frozen=read(WORK/(PREFIX+'-frozen.json'))
    for key,base in [('source_sha256',ROOT),('sdk_source_sha256',WORK/'AIR-SDK'),('worker_source_sha256',WORK/'gcompose-source/gcompose')]:
        for n,h in frozen[key].items(): assert sha(base/n)==h,(key,n)
    for n,h in frozen['protected_assets'].items(): assert sha(n)==h,n
    assert sha(ROOT/'genesis-media-runtime.txt')==frozen['runtime_sha256']
    assert sha(WORK/frozen.get('baseline_publication_path','linked-lanes-contract-final-publication.json'))==frozen['baseline_publication_sha256']
    print('Frozen source, shared runtime and protected originals verified.')

def build_receipt():
    verify()
    native=WORK/(PREFIX+'-native/bin/Release');stage=WORK/(PREFIX+'-runtime')
    for n in ['Genesis-AIR.exe','air-native-shell.dll','air-native-dialogs.dll','air-ui-host.dll','genesis-native-audio.dll']: assert sha(native/n)==sha(stage/n),n
    write(WORK/(PREFIX+'-build-receipt.json'),{'passed':True,'source_frozen_sha256':sha(WORK/(PREFIX+'-frozen.json')),
      'native_binary_sha256':{p.name:sha(p) for p in sorted(native.glob('*.exe'))},
      'payload_sha256':{p.name:sha(p) for p in stage.iterdir() if p.is_file()},
      'generated_sha256':{p.name:sha(p) for p in sorted((WORK/(PREFIX+'-generated')).glob('*.c'))}})
    print('Coherent native build verified against frozen source.')

def publish():
    verify()
    assert (WORK/(PREFIX+'-build.exit')).read_text().strip()=='0'
    frozen=read(WORK/(PREFIX+'-frozen.json'));build=read(WORK/(PREFIX+'-build-receipt.json'))
    assert build.get('passed') is True and build['source_frozen_sha256'].lower()==sha(WORK/(PREFIX+'-frozen.json'))
    gate=accepted_background(build)
    for n,h in frozen['baseline_payload'].items(): assert sha(ROOT/n)==h,n
    stage=WORK/(PREFIX+'-runtime')
    for n,h in build['payload_sha256'].items(): assert sha(stage/n)==h.lower(), ('Candidate payload drift',n)
    for p,h in gate['bound'].items(): assert sha(p)==h, ('Accepted background evidence changed before publication',str(p))
    backup=WORK/'runtime-backups'/PREFIX;backup.mkdir()
    names=list(frozen['baseline_payload'])
    for n in names:
        assert sha(stage/n)==build['payload_sha256'][n],n
        shutil.copyfile(ROOT/n,backup/n)
    for n in names:
        if sha(ROOT/n)==sha(stage/n):continue
        temporary=ROOT/('.'+PREFIX+'-'+n); assert not temporary.exists()
        shutil.copyfile(stage/n,temporary);temporary.replace(ROOT/n)
    for n in names: assert sha(ROOT/n)==build['payload_sha256'][n],n
    verify()
    record={'published':True,'root_binary_sha256':{n:sha(ROOT/n) for n in names},
      'build_receipt_sha256':sha(WORK/(PREFIX+'-build-receipt.json')),
      'background_gate_log_sha256':sha(gate['log']),'background_gate_exit':0,
      'background_gate_log_path':gate['log'].relative_to(ROOT).as_posix(),
      'background_gate_exit_path':gate['exit'].relative_to(ROOT).as_posix(),
      'background_gate_exit_sha256':sha(gate['exit']),
      'protected_assets_unchanged':True,'shared_mm_air_runtime':True,'no_separate_ffmpeg_bundle':True,
      'native_workflow_acceptance_reported_separately':True,'complete_professional_editing_acceptance':False}
    for p,h in gate['bound'].items(): assert sha(p)==h, ('Accepted background evidence changed during publication',str(p))
    if gate['receipt'] is not None:
        record['background_gate_receipt_path']=gate['receipt'].relative_to(ROOT).as_posix()
        record['background_gate_receipt_sha256']=sha(gate['receipt'])
        record['original_background_attempt']=gate['history']
        record['accepted_background_override']=True
    write(WORK/(PREFIX+'-publication.json'),record)
    print('Qualified background candidate published to repository root.')

if __name__=='__main__': {'prepare':prepare,'verify':verify,'build-receipt':build_receipt,'publish':publish}[sys.argv[1]]()
