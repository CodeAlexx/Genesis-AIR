"""Archive an exactly qualified pro-native candidate; never test, publish or launch.

The old title/timing archive plan is immutable. This builder reuses its pinned
pure sanitization/index helpers, but requires new candidate receipts and preserves
F718 cadence failures as history. Run --plan only while final acceptance is absent.
"""
from pathlib import Path
import argparse
import gzip
import hashlib
import importlib.util
import io
import json
import os
import re
import tarfile

ROOT = Path(__file__).resolve().parents[2]
WORK = ROOT / "build-windows"
OLD_HELPER = WORK / "pro-native-acceptance-2026-10-11/archive_checkpoint.py"
OLD_HELPER_SHA = "c31c1155b475f810b1c8b343cc06af70ccdb6d3b0f45531acbef4fa3ff4ccac8"


def require(value, message):
    if not value:
        raise ValueError(message)


require(hashlib.sha256(OLD_HELPER.read_bytes()).hexdigest() == OLD_HELPER_SHA,
        "Pinned original archive helper changed")
spec = importlib.util.spec_from_file_location("historical_archive_helpers", OLD_HELPER)
common = importlib.util.module_from_spec(spec)
spec.loader.exec_module(common)
digest, load, local = common.digest, common.load, common.local
sha, sanitize, eligible, staged_source = common.sha, common.sanitize, common.eligible, common.staged_source


def evidence_path(value, receipt):
    candidate = local(value)
    return candidate if candidate.exists() else local(receipt.parent / value)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--prefix", default=os.environ.get("GENESIS_PRO_PREFIX", "pro-native-pixel-credit-2026-10-11"))
    for flag in ("frozen", "build", "background", "publication", "root-ready"):
        parser.add_argument("--" + flag, type=Path)
    parser.add_argument("--accepted-background-log", type=Path,
                        help="Accepted attempt's immutable log; required with an alternate background receipt")
    parser.add_argument("--accepted-background-exit", type=Path,
                        help="Accepted attempt's immutable exit file; never replaces the original failed attempt")
    parser.add_argument("--native-ui", type=Path)
    parser.add_argument("--device", type=Path)
    parser.add_argument("--cadence", type=Path, action="append", default=[],
                        help="Repeat for separately qualified sources; exact accepted summary with raw/launch bindings")
    parser.add_argument("--evidence", action="append", default=[], help="Extra individual text proof/driver, never runtime/media")
    parser.add_argument("--history-directory", action="append", default=[], help="Extra owned component proof directory under build-windows")
    parser.add_argument("--plan", action="store_true")
    args = parser.parse_args()
    prefix = args.prefix
    require(re.fullmatch(r"pro-native-[a-z0-9-]+-20\d\d-\d\d-\d\d", prefix), "Unsafe checkpoint prefix")
    output, receipt = (ROOT / "archive" / (prefix + suffix) for suffix in (".tar.gz", ".json"))
    if args.plan:
        print(json.dumps({"schema": "genesis.pro_native.generic_archive_plan.v1", "prefix": prefix,
            "archive": str(output), "receipt": str(receipt), "will_test_or_publish": False,
            "requires": ["matching frozen/build/background/publication/root-ready",
                         "explicit exact device and native UI receipts", "at least one accepted unchanged cadence summary",
                         "original parser/raw/launch/capture/identity hashes", "staged source/docs equality"],
            "cadence_sources_are_separately_scoped": True, "historical_f718_failures_required": ["1080", "4k"],
            "production_equality_required_for_new_candidate": False, "outputs_exclusive": True,
            "alternate_background": "--background RECEIPT --accepted-background-log LOG --accepted-background-exit EXIT; original files archived as history"}, indent=2))
        return
    require(args.native_ui and args.device and args.cadence, "Final UI/device/cadence acceptance pending")
    suffixes = {"frozen": "frozen", "build": "build-receipt", "background": "background-receipt",
                "publication": "publication", "root-ready": "root-ready"}
    paths = {key: local(getattr(args, key.replace("-", "_")) or WORK / (prefix + "-" + suffix + ".json"))
             for key, suffix in suffixes.items()}
    paths.update({"native-ui": local(args.native_ui), "device": local(args.device)})
    reports = {key: load(path) for key, path in paths.items()}
    frozen, build, background = (reports[key] for key in ("frozen", "build", "background"))
    require(build.get("passed") is True and build["source_frozen_sha256"].lower() == digest(paths["frozen"]),
            "Accepted build/frozen binding missing")
    app, worker, audio = (build["payload_sha256"][name].lower() for name in
                         ("Genesis-AIR.exe", "genesis-gcompose.exe", "genesis-native-audio.dll"))
    original_log = WORK / (prefix + "-background.log")
    original_exit = WORK / (prefix + "-background.exit")
    alternate = paths["background"] != local(WORK / (prefix + "-background-receipt.json"))
    require(bool(args.accepted_background_log) == bool(args.accepted_background_exit),
            "Accepted background log/exit must be provided together")
    require(not alternate or args.accepted_background_log is not None,
            "Alternate background receipt requires explicit accepted log/exit paths")
    log = local(args.accepted_background_log or original_log)
    background_exit = local(args.accepted_background_exit or original_exit)
    require((WORK / (prefix + "-build.exit")).read_text().strip() == "0", "Build exit not zero")
    require(background_exit.read_text().strip() == "0", "Accepted background exit not zero")
    paths.update({"accepted-background-log": log, "accepted-background-exit": background_exit})
    for key in ("background", "native-ui", "root-ready"):
        common.accepted(reports[key], app, key)
    ui = reports["native-ui"]
    # v4 binds the worker through the full coherent payload rather than a
    # duplicated top-level worker field. Keep the original receipt immutable.
    ui_worker = ui.get("worker_sha256", "")
    if ui.get("schema") == "genesis.native-live.observed.v4":
        require(ui.get("payload_sha256") == build["payload_sha256"], "Native v4 coherent payload mismatch")
        payload_worker = ui["payload_sha256"]["genesis-gcompose.exe"]
        require(not ui_worker or ui_worker.lower() == payload_worker.lower(), "Native worker fields disagree")
        ui_worker = payload_worker
    require(ui.get("audio_dll_sha256", "").lower() == audio and ui_worker.lower() == worker
            and ui.get("build_receipt_sha256", "").lower() == digest(paths["build"]),
            "Native workflow adapter/worker/build mismatch")
    require(background.get("exit") == 0 and background["build_receipt_sha256"].lower() == digest(paths["build"])
            and background["log_sha256"].lower() == digest(log), "Background build/log mismatch")
    require(background.get("evidence"), "Background evidence not hash-bound")
    if alternate or log != local(original_log) or background_exit != local(original_exit):
        origins = background.get("evidence_origins", {})
        require(isinstance(origins, dict) and origins, "Accepted repeat requires immutable evidence origins")
        for selected in (log, background_exit):
            require(any(local(origin) == selected and background["evidence"][name].lower() == digest(selected)
                        for name, origin in origins.items() if name in background["evidence"]),
                    "Selected accepted log/exit not bound by background receipt")
    publication = reports["publication"]
    require(publication.get("published") is True and publication["build_receipt_sha256"].lower() == digest(paths["build"]),
            "Final publication/build pending or mismatched")
    require(publication["background_gate_exit"] == 0 and publication["background_gate_log_sha256"].lower() == digest(log),
            "Publication background mismatch")
    if alternate or log != local(original_log) or background_exit != local(original_exit):
        require(publication.get("background_gate_receipt_sha256", "").lower() == digest(paths["background"])
                and local(publication["background_gate_log_path"]) == log
                and local(publication["background_gate_exit_path"]) == background_exit
                and publication["background_gate_exit_sha256"].lower() == digest(background_exit),
                "Publication did not bind the explicitly accepted background attempt")
    require(publication.get("shared_mm_air_runtime") is True and publication.get("no_separate_ffmpeg_bundle") is True
            and publication.get("protected_assets_unchanged") is True, "Runtime/protected-assets contract not established")
    payload = publication["root_binary_sha256"]
    for name, expected in (("Genesis-AIR.exe", app), ("genesis-gcompose.exe", worker), ("genesis-native-audio.dll", audio)):
        require(payload.get(name, "").lower() == expected, "Published payload mismatch: " + name)
    bound, entries, provenance = {}, {}, {}

    def bind(path, expected=None):
        path = local(path)
        actual = digest(path)
        require(expected is None or actual == expected.lower(), "Evidence drift: " + str(path))
        require(path not in bound or bound[path] == actual, "Previously bound input drift: " + str(path))
        bound[path] = actual
        return path

    def add(name, path, role):
        path = bind(path)
        require(eligible(path), "Excluded non-text archive input: " + str(path))
        require(name not in entries and not name.startswith("/") and ".." not in Path(name).parts,
                "Unsafe/duplicate archive member")
        raw = path.read_bytes()
        require(sha(raw) == bound[path], "Read changed during archive: " + str(path))
        clean = sanitize(path, raw)
        entries[name] = clean
        provenance[name] = {"original_sha256": sha(raw), "sanitized_sha256": sha(clean),
                            "original_bytes": len(raw), "sanitized_bytes": len(clean), "role": role}

    def witnesses(report, path, namespace, required=False):
        evidence = report.get("evidence", {})
        require(isinstance(evidence, dict) and (not required or evidence), "Missing witness hash map: " + namespace)
        for name, expected in evidence.items():
            witness = bind(evidence_path(name, path), expected)
            if eligible(witness):
                add(namespace + "/" + witness.relative_to(ROOT).as_posix(), witness, "Hash-bound " + namespace + " witness")

    for path in paths.values():
        bind(path)
    for key, base in (("source_sha256", ROOT), ("sdk_source_sha256", WORK / "AIR-SDK"),
                      ("worker_source_sha256", WORK / "gcompose-source/gcompose")):
        for name, expected in frozen[key].items():
            bind(base / name, expected)
    for name, expected in payload.items():
        bind(ROOT / name, expected)  # Verify only: never include binaries/runtime copies.
    for key in ("background", "native-ui", "root-ready"):
        witnesses(reports[key], paths[key], key, required=(key == "background"))
    # New candidate device proof must name its actual loaded adapter and exact app.
    device, device_path = reports["device"], paths["device"]
    require(device_path.parent.is_relative_to(WORK), "Device proof outside owned evidence")
    db = device["bindings"]
    require(device.get("passed") is True and device["clock_exit"] == device["device_exit"] == 0, "Device gate failed")
    require(db["app_sha256"].lower() == app and db["dll_sha256"].lower() == db["adjacent_dll_sha256"].lower() == audio
            and device["loaded_module"]["sha256"].lower() == audio, "Device exact loaded identity mismatch")
    device_build_path = bind(device["build_receipt_path"], db["build_receipt_sha256"])
    device_build = load(device_build_path)
    require(device_build["payload_sha256"]["Genesis-AIR.exe"].lower() == app and
            device_build["payload_sha256"]["genesis-native-audio.dll"].lower() == audio,
            "Device original build does not match final app/adapter")
    witnesses(device, device_path, "device", required=True)
    for path, field in ((device_path.parent / "run.ps1", "driver_sha256"),
                        (device_path.parent / "fixtures.py", "fixtures_script_sha256"),
                        (ROOT / "tests/audio_clock.py", "clock_script_sha256"),
                        (ROOT / "tests/audio_device.ai", "device_source_sha256")):
        bind(path, db[field])
    cadences = []
    for index, value in enumerate(args.cadence):
        path = bind(value)
        report = load(path)
        require(report.get("passed") is True and report.get("accepted") is True and
                report.get("acceptance_unchanged") is True and report.get("all_epochs_and_raw_rows_preserved") is True,
                "Require unchanged accepted menu-parser archive summary")
        require(report["app_sha256"].lower() == app and report["worker_sha256"].lower() == worker and
                report["audio_library_sha256"].lower() == audio, "Cadence exact app/worker/audio mismatch")
        original_path = bind(evidence_path(report["parser_report_path"], path), report["parser_report_sha256"])
        original = load(original_path)
        require(original == report["original_parser_report"] and original.get("passed") is True
                and original.get("errors") == [], "Original parser acceptance not preserved")
        require(original["steady"] == report["steady"] and original["identity"] == report["identity"],
                "Cadence adapter changed measurements/identity")
        require(original["parser_sha256"] == report["parser_sha256"], "Parser provenance mismatch")
        bind(WORK / "agent-native-timing-recorder/analyze_menu_trace.py", report["parser_sha256"])
        for field, filename in (("raw_profile_sha256", "window-final.tsv"), ("launch_sha256", "launch.json"),
                                ("identity_sha256", "identity.json"), ("capture_sha256", "capture.json")):
            explicit = report.get("raw_profile_path" if filename == "window-final.tsv" else "launch_path" if filename == "launch.json" else "")
            source = bind(evidence_path(explicit, path) if explicit else path.parent / filename, report[field])
            add("cadence/" + str(index) + "/" + filename, source, "Qualified immutable native cadence; source scope retained")
        require(original["raw_trace_sha256"].lower() == report["raw_profile_sha256"].lower(), "Raw parser identity mismatch")
        identity, capture = load(path.parent / "identity.json"), load(path.parent / "capture.json")
        require(identity == original["identity"] and original["identity_sha256"] == report["identity_sha256"],
                "Predeclared original identity mismatch")
        require(identity["app_sha256"].lower() == app and identity["worker_sha256"].lower() == worker
                and identity["audio_library_sha256"].lower() == audio and identity["intended_program_epoch"] == 0
                and original["selected_program_epoch"] == 0, "Wrong native epoch/payload identity")
        require(identity.get("fullscreen") is False and identity.get("monitor_size") == [480, 270],
                "Only ordinary fitted 480x270 cadence qualified")
        require(capture.get("captured") is True and capture.get("program_stopped_caller_observed") is True
                and capture.get("recorder_off_caller_observed") is True and capture.get("columns") == 46,
                "Raw trace must be complete after native Stop/off")
        require(capture["window_final_sha256"] == capture["original_trace_sha256"] == report["raw_profile_sha256"]
                and capture["launch_sha256"] == report["launch_sha256"] == identity["launch_sha256"]
                and capture["identity_sha256"] == report["identity_sha256"], "Capture identity mismatch")
        # Help traces are produced in Genesis' private LOCALAPPDATA session,
        # while the exclusive closed copy lives in the repository. Verify the
        # actual original read-only; only archive the already-bound closed copy.
        original_trace = Path(capture["original_profile"])
        original_parts = [part.lower() for part in original_trace.parts]
        require(original_trace.is_absolute() and not original_trace.is_symlink()
                and original_trace.is_file() and original_trace.suffix.lower() == ".tsv"
                and original_trace.parent.name == "playback-timing"
                and any(original_parts[i:i+2] == ["genesisair", "media"] for i in range(len(original_parts)-1)),
                "Original trace must be a regular Genesis private Help recording")
        launch = load(path.parent / "launch.json")
        require(Path(launch["original_window_profile"]) == original_trace
                and digest(original_trace) == report["raw_profile_sha256"], "Original Help trace identity mismatch")
        bound[original_trace] = report["raw_profile_sha256"]
        steady, selection = original["steady"], original["selection"]
        require(selection["startup_samples"] == 48000 and selection["terminal_samples_excluded"] == 24000
                and selection["input_rows_excluded"] == 0 and selection["minimum_steady_seconds"] == 120,
                "Predeclared cadence selection changed")
        require(steady["changed_picture_interval_seconds"] >= 120 and steady["device_sample_interval_seconds"] >= 120,
                "Cadence duration not qualified")
        for field in ("skipped_frame_positions", "repeated_picture_presentations", "backwards_picture_jumps", "early_picture_presentations",
                      "stale_picture_presentations_over_two_frames", "clock_queue_zero_all_selected_rows", "overwritten_packet_delta"):
            require(steady[field] == 0, "Strict cadence failed: " + field)
        require(steady["maximum_frame_jump"] == 1 and steady["program_lag_after_present_frames"]["maximum"] <= 2,
                "Cadence consecutive-picture/late contract failed")
        require(original["credit"]["max_total"] <= 8 and original["credit"]["max_reserved"] <= 2,
                "Cadence exceeds fixed transport credit")
        add("cadence/" + str(index) + "/archive-acceptance.json", path, "Accepted unchanged archive summary")
        add("cadence/" + str(index) + "/analysis.json", original_path, "Original unchanged native parser report")
        cadences.append({"summary_sha256": digest(path), "original_analysis_sha256": digest(original_path),
                         "identity": report["identity"], "steady": steady, "raw_selected_epoch": original["raw_selected_epoch"]})
    index_state = staged_source()
    for name in index_state:
        add("source/" + name, ROOT / name, "Current Git-index-equal maintained source/docs")
    for key, path in paths.items():
        add("final/" + key + "/" + path.name, path, "Exactly qualified final " + key)
    for suffix in ("build.log", "build.exit"):
        add("final/" + prefix + "-" + suffix, WORK / (prefix + "-" + suffix), "Final coherent build/background driver")
    for original, accepted_path in ((original_log, log), (original_exit, background_exit)):
        if original.exists() and local(original) != accepted_path:
            add("candidate-history/" + original.name, original, "Original failed/unaccepted attempt retained; not final gate")
    # Failed F718 measurements are mandatory history, never final acceptance.
    historical = WORK / "pro-native-acceptance-2026-10-11"
    for kind in ("1080", "4k"):
        base = historical / ("cadence-" + kind)
        analysis = load(base / "analysis.json")
        require(analysis.get("passed") is False and analysis["identity"]["app_sha256"].lower().startswith("f7185c70"),
                "Historical F718 strict failure missing or relabeled")
        bind(base / "window-final.tsv", analysis["raw_trace_sha256"])
        bind(base / "identity.json", analysis["identity_sha256"])
        bind(base / "launch.json", analysis["identity"]["launch_sha256"])
        for filename in ("analysis.json", "window-final.tsv", "identity.json", "launch.json", "capture.json"):
            add("historical-f718/cadence-" + kind + "/" + filename, base / filename, "Failed strict F718 native cadence, not qualified")
    # Explicit owned component directories only; no complete SDK/runtime copies.
    folders = {
        WORK / "agent-modal-title": "Original title controller/raster evidence",
        WORK / "agent-modal-title-control-return": "Ctrl+Shift+Return before/after controller proof",
        WORK / "agent-native-timing-recorder": "Recorder component and unchanged parser/adapter sources",
        WORK / "agent-native-timing-stop": "Recorder Stop-order component proof",
        WORK / "agent-native-headless-modal": "Modal headless fixture before/after and failed original suite",
        historical / "device": "Historical 06AF/BC5C actual-device proof",
        historical / "device-stop-final": "Historical 056E/5A0048 actual-device proof",
        historical / "device-verified": "Historical F718/342D device and 056E-to-F718 equality provenance",
        historical / "export-stop-final": "Historical 056E export and original font-mask failure",
        device_path.parent: "Exact final app/adapter device proof",
    }
    for value in args.history_directory:
        directory = local(value)
        require(directory.is_relative_to(WORK) and directory.is_dir(), "Component directory must be owned build-windows evidence")
        folders[directory] = "Root-supplied component proof, original scope retained"
    excluded = {"inspector.c", "before-inspector.c", "main.c", "headless.c", "window-cache.c", "profile-only.c"}
    for directory, role in folders.items():
        require(directory.is_dir(), "Missing component history: " + str(directory))
        for path in sorted(directory.rglob("*")):
            rel = path.relative_to(directory)
            if any(part in {"native", "__pycache__", "fonts", "xdg-cache"} for part in rel.parts) or path.name in excluded or path.suffix == ".c":
                continue
            if eligible(path):
                name = "component/" + path.relative_to(WORK).as_posix()
                if name not in entries:
                    add(name, path, role)
    for filename in ("live-06af-receipt.json", "loaded-modules-06af.json", "native-ui-stop-final.json", "native-ui-verified.json",
                     "recorder-stop-close.tsv"):
        add("historical-native/" + filename, historical / filename, "Historical native workflow, exact original binary scope")
    for prior in ("pro-native-title-timing-2026-10-11", "pro-native-title-timing-stop-final-2026-10-11",
                  "pro-native-title-timing-verified-2026-10-11"):
        for suffix in ("frozen.json", "build-receipt.json", "build.log", "build.exit", "background.log", "background.exit",
                       "background-receipt.json", "publication.json"):
            path = WORK / (prior + "-" + suffix)
            if path.exists():
                add("candidate-history/" + path.name, path, "Earlier candidate; passed components and failures retain distinct scope")
        previous = load(WORK / (prior + "-frozen.json"))
        for name, expected in previous["source_sha256"].items():
            path = bind(WORK / (prior + "-source") / name, expected)
            if eligible(path):
                add("candidate-history/" + prior + "-source/" + name, path, "Frozen earlier source, not final source")
    for value in args.evidence:
        path = local(value)
        add("additional/" + path.relative_to(ROOT).as_posix(), path, "Explicit root-supplied text proof/driver")
    for path in (Path(__file__), OLD_HELPER, WORK / "pro-native-checkpoint.py"):
        add("helpers/" + path.parent.name + "/" + path.name, path, "Exact archive/publication helper source")
    manifest = {"schema": "genesis.pro_native.generic_acceptance_archive.v1", "prefix": prefix,
        "app_sha256": app, "worker_sha256": worker, "audio_adapter_sha256": audio,
        "published_payload": payload, "frozen_source_sha256": frozen["source_sha256"],
        "source_index": index_state, "git_index_filtered_equality_verified": True,
        "receipt_bindings": {key: digest(path) for key, path in paths.items()}, "qualified_cadences": cadences,
        "entries": provenance, "historical_f718_failures_preserved": True,
        "historical_component_scope_preserved": True,
        "production_equality_is_historical_only": True, "complete_professional_editing_acceptance": False,
        "limitations": ["Each source/native/device/background proof retains its own scope",
                        "No physical speaker/photon or fullscreen4K/compound4K60/whole-media acceptance",
                        "No binaries, media, private projects/images or complete SDK/runtime trees"]}
    entries["manifest.json"] = (json.dumps(common.clean_json(manifest), indent=2) + "\n").encode()
    require(sum(map(len, entries.values())) <= 536870912, "Archive text budget exceeded")
    require(not output.exists() and not receipt.exists(), "Exclusive public archive/receipt already exists")
    with output.open("xb") as target:
        with gzip.GzipFile(fileobj=target, mode="wb", filename="", mtime=0) as compressed:
            with tarfile.open(fileobj=compressed, mode="w") as bundle:
                for name, raw in sorted(entries.items()):
                    item = tarfile.TarInfo(name)
                    item.size, item.mtime, item.mode = len(raw), 0, 0o644
                    bundle.addfile(item, io.BytesIO(raw))
    with tarfile.open(output, "r:gz") as bundle:
        require(sorted(bundle.getnames()) == sorted(entries), "Archive inventory mismatch")
        for item in bundle:
            raw = bundle.extractfile(item).read()
            require(raw == entries[item.name], "Archive readback mismatch: " + item.name)
            if item.name != "manifest.json":
                require(sha(raw) == provenance[item.name]["sanitized_sha256"], "Sanitized member digest mismatch")
    require(staged_source() == index_state, "Git-index/source changed while archiving")
    for path, expected in bound.items():
        require(digest(path) == expected, "Input changed while archiving: " + str(path))
    result = {"schema": "genesis.pro_native.generic_acceptance_archive_receipt.v1", "passed": True,
        "prefix": prefix, "archive": output.relative_to(ROOT).as_posix(), "archive_sha256": digest(output),
        "app_sha256": app, "worker_sha256": worker, "audio_adapter_sha256": audio,
        "entries": len(entries), "all_members_read_back": True, "sanitized": True,
        "git_index_filtered_equality": True, "published_payload_verified": True,
        "acceptance_receipt_sha256": {key: digest(path) for key, path in paths.items()},
        "qualified_cadence_summary_sha256": [item["summary_sha256"] for item in cadences],
        "historical_f718_failures_preserved": True, "helper_sha256": digest(Path(__file__)),
        "pinned_sanitization_helper_sha256": OLD_HELPER_SHA, "complete_professional_editing_acceptance": False}
    with receipt.open("x", encoding="utf-8") as target:
        json.dump(common.clean_json(result), target, indent=2)
        target.write("\n")
    print(json.dumps(result))


if __name__ == "__main__":
    main()
