"""Archive a completed pro-native checkpoint. Never runs tests, deploys, or launches apps.

Required final receipts must exist and agree before any public output is created.
Use --plan to inspect the contract while native acceptance is still pending.
"""
from pathlib import Path
import argparse
import gzip
import hashlib
import io
import json
import re
import subprocess
import tarfile

ROOT = Path(__file__).resolve().parents[2]
WORK = ROOT / "build-windows"
PREFIX = "pro-native-title-timing-verified-2026-10-11"
OUTPUT = ROOT / "archive" / (PREFIX + ".tar.gz")
RECEIPT = ROOT / "archive" / (PREFIX + ".json")
AUDIO = "5a004885dfff4604a6826e9500f2cfcb640240db57f195d23cbfe84bef8ced85"
TEXT = {".ai", ".c", ".cpp", ".h", ".rs", ".py", ".ps1", ".sh", ".cmake",
        ".json", ".md", ".log", ".txt", ".tsv", ".exit", ".patch", ".toml", ".lock"}


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def digest(path):
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1048576), b""):
            h.update(block)
    return h.hexdigest()


def local(value):
    p = Path(str(value).replace("\\", "/"))
    p = p.resolve() if p.is_absolute() else (ROOT / p).resolve()
    require(p.is_relative_to(ROOT), "Evidence outside repository: " + str(value))
    return p


def load(path):
    require(path.is_file(), "Missing acceptance receipt: " + str(path))
    return json.loads(path.read_text(encoding="utf-8-sig"))


def anonymous(value, category):
    return "<" + category + ":" + sha(value.encode("utf-8"))[:12] + ">"


def clean_string(value):
    # Root replacement precedes generic user replacement, including escaped JSON.
    spellings = {str(ROOT), ROOT.as_posix(), "/mnt/c" + ROOT.as_posix()[2:]}
    for spelling in sorted(spellings, key=len, reverse=True):
        for variant in (json.dumps(spelling)[1:-1], spelling):
            value = re.sub(re.escape(variant), "<ROOT>", value, flags=re.I)
    value = re.sub(r"(?i)[a-z]:[/\\]+users[/\\]+[^/\\\"\r\n]+", "<USER>", value)
    value = re.sub(r"(?i)/mnt/[a-z]/users/[^/\"\r\n]+", "<USER>", value)
    value = re.sub(r"<USER>/\"\r\n]+", "<USER>", value)
    # Preserve anonymous project/source identity and their separately stored hashes.
    # Do not publish private authored filenames or absolute media paths.
    extension = r"(?:air|mp4|mov|mkv|nut|avi|webm|mp3|wav|flac|aac|m4a|pcm|rgba|f32)"
    absolute = r"(?:[a-z]:[/\\]|/mnt/[a-z]/|<ROOT>[/\\]|<USER>[/\\])[^\r\n\"<>]*?\." + extension
    value = re.sub(absolute, lambda m: anonymous(m.group(0), "PRIVATE_PATH"), value, flags=re.I)
    if re.fullmatch(r"[^/\\\r\n]+\.air", value, flags=re.I):
        value = anonymous(value, "PROJECT")
    require(not re.search(r"(?i)[a-z]:[/\\]+users[/\\]+|/mnt/[a-z]/users/|<USER>/]+/", value),
            "Unredacted user path")
    return value


def clean_json(value):
    if isinstance(value, dict):
        out = {}
        for key, item in value.items():
            new_key = clean_string(key)
            require(new_key not in out, "Sanitization collapsed distinct receipt keys")
            out[new_key] = clean_json(item)
        return out
    if isinstance(value, list):
        return [clean_json(item) for item in value]
    return clean_string(value) if isinstance(value, str) else value


def sanitize(path, raw):
    text = raw.decode("utf-8-sig")
    if path.suffix == ".json":
        return (json.dumps(clean_json(json.loads(text)), ensure_ascii=False, indent=2) + "\n").encode()
    return clean_string(text).encode("utf-8")


def eligible(path):
    # Caller selects individual proof/source files; never recursively copy runtime trees.
    if not path.is_file():
        return False
    if path.suffix in TEXT or path.name in {"CMakeLists.txt", ".gitignore", ".gitattributes"}:
        return True
    return path.suffix == ".before" and Path(path.stem).suffix in {".ai", ".py", ".c", ".cpp"}


def staged_source():
    names = subprocess.check_output(["git", "ls-files", "-z"], cwd=ROOT).decode().split("\0")
    result = {}
    for name in sorted(n for n in names if n):
        path = local(name)
        if not (name.startswith(("src/", "tests/", "windows/", "patches/", "docs/"))
                or "/" not in name) or not eligible(path):
            continue
        if name == "genesis-media-runtime.txt":
            continue
        raw = path.read_bytes()
        actual = subprocess.check_output(["git", "hash-object", "--path=" + name, "--stdin"],
                                         input=raw, cwd=ROOT).decode().strip()
        expected = subprocess.check_output(["git", "rev-parse", ":" + name], cwd=ROOT).decode().strip()
        require(actual == expected, "Source/docs differ from Git index: " + name)
        indexed = subprocess.check_output(["git", "show", ":" + name], cwd=ROOT)
        result[name] = {"git_blob": expected, "indexed_sha256": sha(indexed), "worktree_sha256": sha(raw)}
    require("src/input.ai" in result and "README.md" in result, "Maintained source/docs not staged")
    return result


def accepted(report, app, label):
    require(report.get("passed") is True, label + " is not accepted")
    require(str(report.get("app_sha256", "")).lower() == app, label + " app mismatch")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for flag, suffix in {"frozen": "frozen", "build": "build-receipt", "background": "background-receipt",
                         "publication": "publication", "root-ready": "root-ready"}.items():
        parser.add_argument("--" + flag, type=Path, default=WORK / (PREFIX + "-" + suffix + ".json"))
    parser.add_argument("--native-ui", type=Path)
    parser.add_argument("--cadence", type=Path)
    parser.add_argument("--device", type=Path,
        default=WORK / "pro-native-acceptance-2026-10-11/device-verified/receipt.json",
        help="Exact final app/adapter device receipt; historical5A0048 remains separately archived")
    parser.add_argument("--production-equality", type=Path,
        default=WORK / "pro-native-acceptance-2026-10-11/device-verified/production-equality.json")
    parser.add_argument("--evidence", action="append", default=[], help="Additional repo-relative text proof")
    parser.add_argument("--plan", action="store_true")
    args = parser.parse_args()
    if args.plan:
        print(json.dumps({"schema": "genesis.pro_native.archive_plan.v1", "archive": str(OUTPUT),
            "receipt": str(RECEIPT), "prefix": PREFIX, "will_execute_tests_or_publish": False,
            "required": ["frozen", "build passed", "background passed/exit0/app/build/log + evidence[path:sha]",
                         "native-ui passed/app", "cadence accepted/app/worker/raw/launch", "publication", "root-ready",
                         "device passed/app/DLL/loaded-module/original-build; --device if binaries changed"],
            "stage_source_docs_before_archiving": True, "outputs_exclusive": True}, indent=2))
        return
    require(args.native_ui is not None and args.cadence is not None,
            "Native UI/cadence pending: pass their final accepted report paths")
    paths = {key: local(getattr(args, key.replace("-", "_")))
             for key in ("frozen", "build", "background", "publication", "root-ready", "native-ui", "cadence")}
    paths["device"] = local(args.device)
    paths["production-equality"] = local(args.production_equality)
    data = {key: load(path) for key, path in paths.items()}
    frozen, build, background = data["frozen"], data["build"], data["background"]
    require(build.get("passed") is True, "Build not accepted")
    require(build["source_frozen_sha256"].lower() == digest(paths["frozen"]), "Build/frozen binding mismatch")
    app = build["payload_sha256"]["Genesis-AIR.exe"].lower()
    worker = build["payload_sha256"]["genesis-gcompose.exe"].lower()
    audio = build["payload_sha256"]["genesis-native-audio.dll"].lower()
    equality = data["production-equality"]
    require(equality["app_new_sha256"].lower() == app and equality["dll_new_sha256"].lower() == audio,
            "Production equality receipt names different final binaries")
    require(equality["build_receipt_new_sha256"].lower() == digest(paths["build"]), "Equality build mismatch")
    old_frozen_path = WORK / "pro-native-title-timing-stop-final-2026-10-11-frozen.json"
    old_frozen = load(old_frozen_path)
    old_source = old_frozen["source_sha256"]
    new_source = frozen["source_sha256"]
    require(set(old_source) == set(new_source), "Production equality source inventory differs")
    differences = [{"path": name, "old": old_source[name].lower(), "new": new_source[name].lower()}
                   for name in sorted(new_source) if old_source[name].lower() != new_source[name].lower()]
    require(differences == equality["source_differences"] and
            {item["path"] for item in differences} == {"tests/headless.ai", "tests/headless.expected.tsv"},
            "Equality must preserve all production and overlays; only documented headless fixture correction allowed")
    require(equality["application_source_identical"] is True and equality["production_adapter_overlay_identical"] is True,
            "Equality receipt does not establish source/overlay equality")
    require(frozen["sdk_source_sha256"] == old_frozen["sdk_source_sha256"] and
            frozen["worker_source_sha256"] == old_frozen["worker_source_sha256"] and
            frozen["runtime_sha256"] == old_frozen["runtime_sha256"], "SDK/worker/shared runtime changed between equality builds")
    require(equality["generated_main_old_sha256"].lower() == equality["generated_main_new_sha256"].lower() ==
            build["generated_sha256"]["main.c"].lower(), "Generated main source equality mismatch")
    log = WORK / (PREFIX + "-background.log")
    require((WORK / (PREFIX + "-build.exit")).read_text().strip() == "0", "Build exit missing/nonzero")
    require((WORK / (PREFIX + "-background.exit")).read_text().strip() == "0", "Background exit missing/nonzero")
    accepted(background, app, "Background gate")
    require(background.get("exit") == 0, "Background receipt exit not zero")
    require(background["build_receipt_sha256"].lower() == digest(paths["build"]), "Background build mismatch")
    require(background["log_sha256"].lower() == digest(log), "Background log mismatch")
    evidence = background.get("evidence")
    require(isinstance(evidence, dict) and evidence, "Background reports not hash-bound")
    accepted(data["native-ui"], app, "Native workflow")
    accepted(data["root-ready"], app, "Installed root readiness")
    cadence = data["cadence"]
    require(cadence.get("passed_clock_queue_invariants") is True or cadence.get("passed") is True,
            "Native cadence not accepted")
    require(cadence.get("app_sha256", "").lower() == app and cadence.get("worker_sha256", "").lower() == worker,
            "Cadence app/worker mismatch")
    publication = data["publication"]
    require(publication.get("published") is True, "Publication pending")
    require(publication["build_receipt_sha256"].lower() == digest(paths["build"]), "Publication build mismatch")
    require(publication["background_gate_exit"] == 0 and publication["background_gate_log_sha256"].lower() == digest(log),
            "Publication background mismatch")
    require(publication["shared_mm_air_runtime"] is True and publication["no_separate_ffmpeg_bundle"] is True,
            "Shared MM-AIR runtime contract not recorded")
    require(publication.get("protected_assets_unchanged") is True, "Protected asset preservation not recorded")
    payload = publication["root_binary_sha256"]
    require(payload.get("Genesis-AIR.exe", "").lower() == app, "Published app mismatch")
    bound = {}
    def bind(path, expected=None):
        path = local(path)
        current = digest(path)
        if expected is not None:
            require(current == expected.lower(), "Evidence drift: " + str(path))
        bound[path] = current
        return path
    for path in paths.values():
        bind(path)
    old_build_path = bind(WORK / "pro-native-title-timing-stop-final-2026-10-11-build-receipt.json",
                          equality["build_receipt_old_sha256"])
    old_build = load(old_build_path)
    require(old_build["payload_sha256"]["Genesis-AIR.exe"].lower() == equality["app_old_sha256"].lower() and
            old_build["payload_sha256"]["genesis-native-audio.dll"].lower() == equality["dll_old_sha256"].lower(),
            "Equality old binary provenance mismatch")
    bind(WORK / "pro-native-title-timing-stop-final-2026-10-11-generated/main.c",
         equality["generated_main_old_sha256"])
    bind(WORK / (PREFIX + "-generated/main.c"), equality["generated_main_new_sha256"])
    for name, expected in frozen["source_sha256"].items():
        bind(ROOT / name, expected)
    for key, base in (("sdk_source_sha256", WORK / "AIR-SDK"),
                      ("worker_source_sha256", WORK / "gcompose-source/gcompose")):
        for name, expected in frozen[key].items():
            bind(base / name, expected)  # Identity only; no complete SDK/runtime copy.
    for name, expected in payload.items():
        bind(ROOT / name, expected)  # Identity only; binaries never archived.
    for name, expected in evidence.items():
        bind(name, expected)
    # Native/root-ready image witnesses may be hash-checked but are never archived.
    for label in ("native-ui", "root-ready"):
        witnesses = data[label].get("evidence", {})
        require(isinstance(witnesses, dict), label + " evidence must be a hash map")
        for name, expected in witnesses.items():
            candidate = local(name)
            if not candidate.exists():
                candidate = paths[label].parent / name
            bind(candidate, expected)
    for field, filename in (("raw_profile_sha256", "window-final.tsv"), ("launch_sha256", "launch.json")):
        require(field in cadence, "Cadence missing " + field)
        candidate = paths["cadence"].parent / filename
        if not candidate.exists() and filename == "window-final.tsv":
            candidate = paths["cadence"].parent / "window.tsv"
        bind(candidate, cadence[field])
    device_dir = paths["device"].parent
    require(device_dir.is_relative_to(WORK), "Final device proof must be in owned build-windows evidence")
    device = data["device"]
    require(device["passed"] is True and device["clock_exit"] == device["device_exit"] == 0, "Device proof not accepted")
    bindings = device["bindings"]
    require(bindings["dll_sha256"].lower() == bindings["adjacent_dll_sha256"].lower() == audio,
            "Device module is not exact final adapter")
    require(bindings["app_sha256"].lower() == app, "Device app bytes differ from final candidate")
    # Headless-only fixture correction creates a new whole-build receipt. Keep the
    # original device run tied to its actual old build, with identical app/DLL bytes.
    device_build_path = bind(device["build_receipt_path"], bindings["build_receipt_sha256"])
    device_build = load(device_build_path)
    require(device_build["payload_sha256"]["Genesis-AIR.exe"].lower() == app and
            device_build["payload_sha256"]["genesis-native-audio.dll"].lower() == audio,
            "Original device build does not match final app/adapter bytes")
    require(device["loaded_module"]["sha256"].lower() == audio, "Loaded device module not exact final adapter")
    for filename, expected in device["evidence"].items():
        bind(device_dir / filename, expected)
    for path, field in ((device_dir / "run.ps1", "driver_sha256"),
                        (device_dir / "fixtures.py", "fixtures_script_sha256"),
                        (ROOT / "tests/audio_clock.py", "clock_script_sha256"),
                        (ROOT / "tests/audio_device.ai", "device_source_sha256")):
        bind(path, bindings[field])
    index = staged_source()
    entries, provenance = {}, {}
    def add(name, path, role):
        path = local(path)
        require(eligible(path), "Excluded/non-text archive input: " + str(path))
        require(name not in entries and not name.startswith("/") and ".." not in Path(name).parts,
                "Invalid/duplicate archive entry")
        raw = path.read_bytes()
        if path in bound:
            require(sha(raw) == bound[path], "Previously bound input changed before archive: " + str(path))
        bound[path] = sha(raw)
        clean = sanitize(path, raw)
        entries[name] = clean
        provenance[name] = {"original_sha256": sha(raw), "sanitized_sha256": sha(clean),
                            "original_bytes": len(raw), "sanitized_bytes": len(clean), "role": role}
    for name in index:
        add("source/" + name, ROOT / name, "Current staged maintained source/docs")
    for key, path in paths.items():
        add("final/" + path.name, path, "Final accepted " + key)
    for suffix in ("build.log", "build.exit", "background.log", "background.exit"):
        add("final/" + PREFIX + "-" + suffix, WORK / (PREFIX + "-" + suffix), "Final coherent build/background driver")
    for name in evidence:
        path = local(name)
        add("background/" + path.relative_to(ROOT).as_posix(), path, "Hash-bound final BackgroundOnly report")
    for label in ("native-ui", "root-ready"):
        for name in data[label].get("evidence", {}):
            path = local(name)
            if not path.exists():
                path = paths[label].parent / name
            if eligible(path):
                add(label + "-witnesses/" + path.relative_to(ROOT).as_posix(), path, "Hash-bound native witness")
    for filename in ("window-final.tsv", "window.tsv", "launch.json", "window-credit.json"):
        path = paths["cadence"].parent / filename
        if path in bound:
            add("native-cadence/" + filename, path, "Immutable native cadence evidence")
    # Explicit historical directories, not recursive private projects/runtime/media copies.
    folders = {
        "agent-modal-title": "Historical title component/oracle corrections",
        "agent-modal-title-control-return": "Ctrl+Shift+Return failed-before/passed-after controller proof",
        "agent-native-timing-recorder": "Recorder original CPU lifecycle proof",
        "agent-native-timing-stop": "Recorder after Stop-order CPU lifecycle proof",
        "agent-native-headless-modal": "Headless before/after modal fixture correction,154facts+3platformdrops",
        "pro-native-acceptance-2026-10-11/device": "Historical06AF/BC5C waveOut proof, separate binary scope",
        "pro-native-acceptance-2026-10-11/device-stop-final": "Historical exact5A0048 waveOut clock/meters/Stop proof",
        "pro-native-acceptance-2026-10-11/export-stop-final": "Historical056E independent native retry/export and prior font-mask failure",
    }
    folders.setdefault(device_dir.relative_to(WORK).as_posix(), "Exact final app/adapter device proof")
    excluded = {"inspector.c", "before-inspector.c", "main.c", "headless.c", "window-cache.c", "profile-only.c"}
    for folder, role in folders.items():
        base = WORK / folder
        require(base.is_dir(), "Missing component proof: " + folder)
        for path in sorted(base.rglob("*")):
            rel = path.relative_to(base)
            if any(part in {"native", "__pycache__", "fonts", "xdg-cache"} for part in rel.parts) or path.name in excluded:
                continue
            if eligible(path):
                add("component/" + folder + "/" + rel.as_posix(), path, role)
    historical = WORK / "pro-native-acceptance-2026-10-11"
    for name in ("live-06af-receipt.json", "loaded-modules-06af.json"):
        add("historical-06af/" + name, historical / name, "Earlier06AF native workflow, not final app acceptance")
    prior_ui_path = historical / "native-ui-stop-final.json"
    prior_ui = load(prior_ui_path)
    require(prior_ui["passed"] is True, "Historical056E native workflow not accepted")
    add("historical-056e/native-ui-stop-final.json", prior_ui_path, "Earlier056E native workflow; separate app/module scope")
    for name, expected in prior_ui.get("evidence", {}).items():
        path = bind(name, expected)
        if eligible(path):
            add("historical-056e/" + path.relative_to(WORK).as_posix(), path, "056E native recorder Stop/close witness")
    prior_device = load(historical / "device-stop-final/receipt.json")
    require(prior_device["passed"] is True and prior_device["bindings"]["dll_sha256"].lower() == AUDIO and
            prior_device["loaded_module"]["sha256"].lower() == AUDIO, "Historical5A0048 proof identity changed")
    for prefix in ("pro-native-title-timing-2026-10-11", "pro-native-title-timing-stop-final-2026-10-11"):
        role = "Earlier candidate, original build/failed or unqualified BackgroundOnly scope preserved"
        for suffix in ("frozen.json", "build-receipt.json", "build.log", "build.exit", "background.log", "background.exit"):
            path = WORK / (prefix + "-" + suffix)
            if path.exists():
                add("candidate-history/" + path.name, path, role)
        prior_frozen = load(WORK / (prefix + "-frozen.json"))
        for name, expected in prior_frozen["source_sha256"].items():
            path = WORK / (prefix + "-source") / name
            bind(path, expected)
            if eligible(path):
                add("candidate-history/" + prefix + "-source/" + name, path, role)
    for value in args.evidence:
        path = local(value)
        add("additional/" + path.relative_to(ROOT).as_posix(), path, "Explicit root-supplied proof/driver")
    add("helpers/archive_checkpoint.py", Path(__file__), "Exact archive builder; no runtime actions")
    add("helpers/pro-native-checkpoint.py", WORK / "pro-native-checkpoint.py", "Frozen/build/publication driver")
    manifest = {"schema": "genesis.pro_native.acceptance_archive.v1", "prefix": PREFIX,
        "app_sha256": app, "worker_sha256": worker, "audio_adapter_sha256": audio,
        "historical_audio_adapter_sha256": AUDIO,
        "production_source_and_generated_main_equality_verified": True,
        "binary_difference_cause": "Not classified; source equality is provenance, not a PE section proof",
        "published_payload": payload, "frozen_source_sha256": frozen["source_sha256"],
        "git_index_filtered_equality_verified": True, "source_index": index,
        "receipt_bindings": {key: digest(path) for key, path in paths.items()}, "entries": provenance,
        "historical_component_scope_preserved": True, "complete_professional_editing_acceptance": False,
        "limitations": ["BackgroundOnly gate and separate native acceptance retain distinct scope",
            "waveOut clock/meters proof does not establish physical sound or A/V perception",
            "Bounded ordinary fitted-editor cadence does not establish fullscreen4K or whole-media duration",
            "No media, private project files, images, EXE/DLLs or complete SDK/runtime trees included"]}
    entries["manifest.json"] = (json.dumps(clean_json(manifest), indent=2) + "\n").encode()
    require(sum(map(len, entries.values())) <= 536870912, "Archive text budget exceeded")
    require(not OUTPUT.exists() and not RECEIPT.exists(), "Exclusive archive/receipt already exists")
    # No public output before the entire acceptance/input preflight completes.
    with OUTPUT.open("xb") as target:
        with gzip.GzipFile(fileobj=target, mode="wb", filename="", mtime=0) as compressed:
            with tarfile.open(fileobj=compressed, mode="w") as bundle:
                for name, raw in sorted(entries.items()):
                    item = tarfile.TarInfo(name)
                    item.size, item.mtime, item.mode = len(raw), 0, 0o644
                    bundle.addfile(item, io.BytesIO(raw))
    with tarfile.open(OUTPUT, "r:gz") as bundle:
        require(sorted(bundle.getnames()) == sorted(entries), "Archive member inventory mismatch")
        for item in bundle:
            raw = bundle.extractfile(item).read()
            require(raw == entries[item.name], "Archive readback mismatch: " + item.name)
            if item.name != "manifest.json":
                require(sha(raw) == provenance[item.name]["sanitized_sha256"], "Member digest mismatch")
    require(staged_source() == index, "Staged source changed during archive")
    for path, expected in bound.items():
        require(digest(path) == expected, "Input changed during archive: " + str(path))
    receipt = {"schema": "genesis.pro_native.acceptance_archive_receipt.v1", "passed": True,
        "archive": OUTPUT.relative_to(ROOT).as_posix(), "archive_sha256": digest(OUTPUT),
        "entries": len(entries), "all_members_read_back": True, "sanitized": True,
        "git_index_filtered_equality": True, "published_payload_verified": True,
        "app_sha256": app, "worker_sha256": worker, "audio_adapter_sha256": audio,
        "historical_audio_adapter_sha256": AUDIO,
        "production_source_and_generated_main_equality_verified": True,
        "acceptance_receipt_sha256": {key: digest(path) for key, path in paths.items()},
        "helper_sha256": digest(Path(__file__)), "complete_professional_editing_acceptance": False}
    with RECEIPT.open("x", encoding="utf-8") as stream:
        json.dump(receipt, stream, indent=2)
        stream.write("\n")
    print(json.dumps(receipt))


if __name__ == "__main__":
    main()
