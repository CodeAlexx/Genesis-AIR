param([string]$Prefix='linked-lanes-controls-final')
$ErrorActionPreference='Stop'
$project=Split-Path -Parent $PSScriptRoot
$python='C:\Users\Alexn\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe'
$env:GENESIS_LINKED_PREFIX=$Prefix
$log=Join-Path $PSScriptRoot ($prefix+'-background.log')
$status=Join-Path $PSScriptRoot ($prefix+'-background.exit')
if((Test-Path -LiteralPath $log) -or (Test-Path -LiteralPath $status)){throw 'Existing gate receipts must be preserved.'}
try {
 & $python (Join-Path $PSScriptRoot 'linked-lanes-checkpoint.py') verify
 if($LASTEXITCODE -ne 0){throw 'Source verification failed.'}
 if((Get-Content -LiteralPath (Join-Path $PSScriptRoot ($prefix+'-build.exit')) -Raw).Trim() -ne '0'){throw 'Successful coherent build required.'}
 $env:PATH='C:\MM-Air;'+(Split-Path -Parent $python)+';'+$env:PATH
 & (Join-Path $project 'tests/windows.ps1') -Bin (Join-Path $PSScriptRoot ($prefix+'-native/bin/Release')) -Worker (Join-Path $PSScriptRoot ($prefix+'-runtime/genesis-gcompose.exe')) -BackgroundOnly *> $log
 if($LASTEXITCODE -ne 0){throw 'Background Windows acceptance failed.'}
 & $python (Join-Path $PSScriptRoot 'linked-lanes-checkpoint.py') verify >> $log
 if($LASTEXITCODE -ne 0){throw 'Source drift during acceptance.'}
 Set-Content -LiteralPath $status -Value '0' -NoNewline
} catch {$_ | Out-File -LiteralPath $log -Append;Set-Content -LiteralPath $status -Value '1' -NoNewline;throw}
