from pathlib import Path
import hashlib,json,shutil,subprocess,sys,datetime,os
ROOT=Path(__file__).resolve().parent.parent
WORK=ROOT/'build-windows'
PREFIX=os.environ.get('GENESIS_LINKED_PREFIX','linked-lanes-contract-final')
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for block in iter(lambda:f.read(1048576),b''):h.update(block)
 return h.hexdigest()
def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def write(p,v):
 with Path(p).open('x',encoding='utf-8') as f:json.dump(v,f,indent=2)
def prepare():
 old=read(WORK/'cadence-reserve-gain-frozen.json')
 publication=read(WORK/'cadence-reserve-gain-publication.json')
 for base,pin in [(WORK/'AIR-SDK',publication['sdk_pin']),(WORK/'gcompose-source/gcompose',publication['worker_pin'])]:
  assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=base,text=True).strip()==pin
 for n,h in publication['root_binaries'].items():assert sha(ROOT/n)==h,n
 sources=set(old['source_sha256'])
 listed=subprocess.check_output(['git','ls-files','-z','--','src','tests','windows','patches'],cwd=ROOT).decode().split('\0')
 sources.update(n for n in listed if n)
 sources.update(['src/linked_media.ai','tests/linked_media.ai','tests/audio_plan_preflight.ai','tests/audio_plan_preflight.py','tests/channel_deadlines.ai','tests/channel_deadlines.py','tests/channel_deadlines_native.c','patches/air-editor-io.patch','patches/air-channel-deadlines.patch','build-windows.ps1','build.sh'])
 sources={n for n in sources if not n.startswith('docs/') and n!='README.md'}
 protected=['Costa Rica 4K.air','Regular 1080p60.air']
 downloads=Path(r'C:\Users\Alexn\Downloads\AirFetch')
 assets={str(ROOT/n):sha(ROOT/n) for n in protected}
 for n in ['COSTA RICA IN 4K 60fps HDR (ULTRA HD).mp4','Which is The Best Qwen3.8-27B_.mp4']:assets[str(downloads/n)]=sha(downloads/n)
 frozen={'schema':'genesis.linked-lanes.frozen.v1','captured_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
  'baseline_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),
  'sdk_pin':publication['sdk_pin'],'worker_pin':publication['worker_pin'],
  'source_sha256':{n:sha(ROOT/n) for n in sorted(sources)},
  'sdk_source_sha256':{n:sha(WORK/'AIR-SDK'/n) for n in old['sdk_source_sha256']},
  'worker_source_sha256':{n:sha(WORK/'gcompose-source/gcompose'/n) for n in old['worker_source_sha256']},
  'baseline_payload':publication['root_binaries'],'protected_assets':assets,
  'runtime_sha256':sha(ROOT/'genesis-media-runtime.txt'),
  'baseline_publication_sha256':sha(WORK/'cadence-reserve-gain-publication.json')}
 frozen['sdk_source_sha256']['stdlib/editor_io.ai']=sha(WORK/'AIR-SDK/stdlib/editor_io.ai')
 frozen['sdk_source_sha256']['stdlib/channel.ai']=sha(WORK/'AIR-SDK/stdlib/channel.ai')
 stage=WORK/(PREFIX+'-runtime');stage.mkdir()
 snapshot=WORK/(PREFIX+'-source');snapshot.mkdir()
 for n in frozen['baseline_payload']:shutil.copyfile(ROOT/n,stage/n)
 shutil.copyfile(ROOT/'genesis-media-runtime.txt',stage/'genesis-media-runtime.txt')
 shutil.copytree(ROOT/'fonts',stage/'fonts')
 for n in frozen['source_sha256']:
  target=snapshot/n;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(ROOT/n,target)
 write(WORK/(PREFIX+'-frozen.json'),frozen)
 print('Fresh linked-lanes candidate frozen; root and user media preserved.')
def verify():
 frozen=read(WORK/(PREFIX+'-frozen.json'))
 for key,base in [('source_sha256',ROOT),('sdk_source_sha256',WORK/'AIR-SDK'),('worker_source_sha256',WORK/'gcompose-source/gcompose')]:
  for n,h in frozen[key].items():assert sha(base/n)==h,(key,n)
 for n,h in frozen['protected_assets'].items():assert sha(n)==h,n
 assert sha(ROOT/'genesis-media-runtime.txt')==frozen['runtime_sha256']
 assert sha(WORK/'cadence-reserve-gain-publication.json')==frozen['baseline_publication_sha256']
 print('Frozen source, shared runtime and original media verified.')
def build_receipt():
 verify()
 native=WORK/(PREFIX+'-native/bin/Release');stage=WORK/(PREFIX+'-runtime')
 for n in ['Genesis-AIR.exe','air-native-shell.dll','air-native-dialogs.dll','air-ui-host.dll','genesis-native-audio.dll']:assert sha(native/n)==sha(stage/n),n
 write(WORK/(PREFIX+'-build-receipt.json'),{'passed':True,'source_frozen_sha256':sha(WORK/(PREFIX+'-frozen.json')),
  'native_binary_sha256':{p.name:sha(p) for p in sorted(native.glob('*.exe'))},
  'payload_sha256':{p.name:sha(p) for p in stage.iterdir() if p.is_file()},
  'generated_sha256':{p.name:sha(p) for p in sorted((WORK/(PREFIX+'-generated')).glob('*.c'))}})
 print('Coherent native build bound to frozen source and staged payload.')
def publish():
 verify()
 assert (WORK/(PREFIX+'-build.exit')).read_text().strip()=='0'
 assert (WORK/(PREFIX+'-background.exit')).read_text().strip()=='0'
 frozen=read(WORK/(PREFIX+'-frozen.json'));build=read(WORK/(PREFIX+'-build-receipt.json'))
 for n,h in frozen['baseline_payload'].items():assert sha(ROOT/n)==h,n
 audio=read(WORK/'audio-plan-preflight.json');linked=read(WORK/'linked-media-tests.json')
 channel=read(WORK/'channel-deadlines-tests.json')
 assert channel['passed'] and channel['cases']==4 and channel['checks']==18 and channel['exact_wire_cases']==4
 assert channel['binary_sha256']==build['native_binary_sha256']['genesis-channel-deadlines.exe']
 assert audio['passed'] and not audio['failures'] and audio['cases']==61
 assert linked['payload']['status']=='pass' and linked['payload']['cases']['failed']==0
 assert audio['binary_sha256']==build['native_binary_sha256']['genesis-audio-plan-preflight.exe']
 real=read(WORK/(PREFIX+'-1080-acceptance.json'))
 assert real['passed'] and real['source_media_unchanged'] and real['background_only']
 assert real['frozen_manifest_sha256']==sha(WORK/(PREFIX+'-frozen.json'))
 assert real['report']['payload']['status']=='pass' and real['report']['payload']['cases']['failed']==0
 assert real['worker_sha256']==build['payload_sha256']['genesis-gcompose.exe']
 review=read(WORK/(PREFIX+'-1080-raster-review.json'))
 assert review['passed'] and review['acceptance_sha256']==sha(WORK/(PREFIX+'-1080-acceptance.json'))
 for n,h in review['png_sha256'].items():assert real['outputs_sha256'][n]==h
 stage=WORK/(PREFIX+'-runtime')
 names=list(frozen['baseline_payload'])
 for n in names:assert sha(stage/n)==build['payload_sha256'][n],n
 backup=WORK/'runtime-backups'/PREFIX;backup.mkdir()
 for n in names:shutil.copyfile(ROOT/n,backup/n)
 preserved={}
 for n in names:
  if sha(ROOT/n)==sha(stage/n):continue
  temporary=ROOT/('.'+PREFIX+'-'+n);assert not temporary.exists()
  shutil.copyfile(stage/n,temporary)
  try:temporary.replace(ROOT/n)
  except PermissionError:
   loaded=backup/('loaded-'+n);(ROOT/n).rename(loaded);preserved[n]=str(loaded);temporary.replace(ROOT/n)
 for n in names:assert sha(ROOT/n)==build['payload_sha256'][n],n
 verify()
 write(WORK/(PREFIX+'-publication.json'),{'published':True,'root_binary_sha256':{n:sha(ROOT/n) for n in names},
  'build_receipt_sha256':sha(WORK/(PREFIX+'-build-receipt.json')),'background_gate_log_sha256':sha(WORK/(PREFIX+'-background.log')),
  'audio_report_sha256':sha(WORK/'audio-plan-preflight.json'),'linked_report_sha256':sha(WORK/'linked-media-tests.json'),
  'channel_report_sha256':sha(WORK/'channel-deadlines-tests.json'),
  'real_1080_acceptance_sha256':sha(WORK/(PREFIX+'-1080-acceptance.json')),
  'background_gate_exit':0,'desktop_clipboard_and_speaker_tests_deferred':True,'interactive_ui_and_cadence_not_requalified':True,
  'protected_assets_unchanged':True,'no_user_process_terminated':True,'preserved_loaded_images':preserved,
  'shared_mm_air_runtime':True,'no_separate_ffmpeg_bundle':True,'complete_professional_editing_acceptance':False})
 print('Qualified background candidate published in repository root; user windows preserved.')
if __name__=='__main__':{'prepare':prepare,'verify':verify,'build-receipt':build_receipt,'publish':publish}[sys.argv[1]]()
