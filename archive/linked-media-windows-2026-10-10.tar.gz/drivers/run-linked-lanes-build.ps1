param([string]$Prefix='linked-lanes-controls-final')
$ErrorActionPreference='Stop'
$project=Split-Path -Parent $PSScriptRoot
$python='C:\Users\Alexn\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe'
$env:GENESIS_LINKED_PREFIX=$Prefix
$log=Join-Path $PSScriptRoot ($prefix+'-build.log')
$status=Join-Path $PSScriptRoot ($prefix+'-build.exit')
if((Test-Path -LiteralPath $log) -or (Test-Path -LiteralPath $status)){throw 'Existing candidate receipts must be preserved.'}
try {
 & $python (Join-Path $PSScriptRoot 'linked-lanes-checkpoint.py') prepare
 if($LASTEXITCODE -ne 0){throw 'Source freeze failed.'}
 & (Join-Path $project 'build-windows.ps1') -AirSdk (Join-Path $PSScriptRoot 'AIR-SDK') -Destination (Join-Path $PSScriptRoot ($prefix+'-runtime')) -NativeBuild (Join-Path $PSScriptRoot ($prefix+'-native')) -GeneratedDirectory (Join-Path $PSScriptRoot ($prefix+'-generated')) -Worker (Join-Path $PSScriptRoot ($prefix+'-runtime/genesis-gcompose.exe')) -RunTests -SkipSmoke -SkipTestRun *> $log
 if($LASTEXITCODE -ne 0){throw 'Native candidate compilation failed.'}
 & $python (Join-Path $PSScriptRoot 'linked-lanes-checkpoint.py') build-receipt >> $log
 if($LASTEXITCODE -ne 0){throw 'Frozen native build verification failed.'}
 Set-Content -LiteralPath $status -Value '0' -NoNewline
} catch {$_ | Out-File -LiteralPath $log -Append;Set-Content -LiteralPath $status -Value '1' -NoNewline;throw}
