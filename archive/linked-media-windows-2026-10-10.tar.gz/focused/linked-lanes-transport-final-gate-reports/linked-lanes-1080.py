from pathlib import Path
import hashlib,json,os,subprocess
ROOT=Path(__file__).resolve().parent.parent
WORK=ROOT/'build-windows'
PREFIX='linked-lanes-transport-final'
HELPER=WORK/'agent-linked-streams-transport-final'
OUTPUT=HELPER/'check-final'
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
assert (WORK/(PREFIX+'-background.exit')).read_text().strip()=='0'
frozen=read(WORK/(PREFIX+'-frozen.json'));proof=read(HELPER/'build-receipt.json')
assert proof['build_passed'] and proof['frozen_manifest_sha256']==sha(WORK/(PREFIX+'-frozen.json'))
for n,h in proof['production_sha256'].items():assert sha(ROOT/n)==h==frozen['source_sha256'][n]
for n,h in proof['helper_sha256'].items():assert sha(HELPER/n)==h
for n,h in proof['sdk_sources_sha256'].items():assert sha(WORK/'AIR-SDK/stdlib'/n)==h
media=Path(r'C:\Users\Alexn\Downloads\AirFetch\Which is The Best Qwen3.8-27B_.mp4')
assert sha(media)==proof['source_expected_sha256']
OUTPUT.mkdir()
worker=WORK/(PREFIX+'-runtime/genesis-gcompose.exe')
binary=HELPER/'native/Release/genesis-linked-1080.exe'
env=os.environ.copy();env.pop('GENESIS_FAKE_PROVIDER',None)
env.update(GENESIS_GCOMPOSE=str(worker),GENESIS_SCRATCH=str(OUTPUT),GENESIS_FONT=str(ROOT/'fonts/NotoSansJP.ttf'),GENESIS_NATIVE_HDR_COLOR='0')
with (OUTPUT/'execution.log').open('wb') as log:
 child=subprocess.Popen([str(binary),str(OUTPUT),str(worker),str(media)],cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT)
 try:code=child.wait(timeout=180)
 except subprocess.TimeoutExpired:
  subprocess.run(['taskkill','/PID',str(child.pid),'/T','/F'],stdout=log,stderr=subprocess.STDOUT,check=False)
  raise
assert code==0,code
report=read(OUTPUT/'linked-1080-tests.json')
assert report['payload']['status']=='pass' and report['payload']['cases']['failed']==0
assert sha(media)==proof['source_expected_sha256']
receipt={'passed':True,'helper_build_receipt_sha256':sha(HELPER/'build-receipt.json'),
 'frozen_manifest_sha256':sha(WORK/(PREFIX+'-frozen.json')),
 'binary_sha256':sha(binary),'worker_sha256':sha(worker),'source_media_sha256':sha(media),
 'source_media_unchanged':True,'background_only':True,'no_device_playback':True,
 'report':report,'outputs_sha256':{n:sha(OUTPUT/n) for n in proof['outputs']},
 'private_output_directory':str(OUTPUT),'execution_log_sha256':sha(OUTPUT/'execution.log')}
target=WORK/(PREFIX+'-1080-acceptance.json');assert not target.exists()
target.write_text(json.dumps(receipt,indent=2),encoding='utf-8')
print(json.dumps({'passed':True,'report':report,'private_output':str(OUTPUT)}))
