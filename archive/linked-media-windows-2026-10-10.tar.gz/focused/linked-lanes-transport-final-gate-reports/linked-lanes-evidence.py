from pathlib import Path
import datetime, hashlib, io, json, sys, tarfile

ROOT = Path(__file__).resolve().parent.parent
WORK = ROOT / 'build-windows'
PREFIX = 'linked-lanes-transport-final'
BASELINE = WORK / (PREFIX + '-reports-before.json')
STAT_BEFORE = WORK / (PREFIX + '-reports-stat-before.json')

def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for b in iter(lambda: f.read(1048576), b''): h.update(b)
    return h.hexdigest()

def read(path): return json.loads(Path(path).read_text(encoding='utf-8-sig'))

def sanitize(value):
    if isinstance(value, dict): return {sanitize(k): sanitize(v) for k,v in value.items()}
    if isinstance(value, list): return [sanitize(v) for v in value]
    if not isinstance(value, str): return value
    for a,b in [(str(ROOT).replace('\\','\\\\'), '<repo>'), (str(ROOT), '<repo>'), (ROOT.as_posix(), '<repo>'),
                ('/mnt/c/Users/Alexn/Documents/Codex/2026-09-28/Genesis-AIR-windows-native', '<repo>'),
                (r'C:\\Users\\Alexn\\Downloads\\AirFetch', '<media>'), (r'C:\Users\Alexn\Downloads\AirFetch', '<media>'),
                (r'C:\Users\Alexn', '<user>'), ('C:/Users/Alexn', '<user>')]:
        value = value.replace(a, b)
    return value

def capture():
    assert not BASELINE.exists()
    data = {p.name: sha(p) for p in WORK.iterdir() if p.is_file() and p.suffix in ('.json', '.txt', '.png', '.log')}
    BASELINE.write_text(json.dumps(data, indent=2), encoding='utf-8')
    print('Prior report digests captured; background gate can run.')

def capture_stat():
    assert not STAT_BEFORE.exists()
    data = {p.name:p.stat().st_mtime_ns for p in WORK.iterdir() if p.is_file() and p.suffix in ('.json','.txt','.png','.log')}
    STAT_BEFORE.write_text(json.dumps(data,indent=2),encoding='utf-8')
    print('Prior report timestamps captured, including deterministic reports.')

def archive(helper_dir):
    helper_dir = Path(helper_dir).resolve()
    assert helper_dir.is_relative_to(WORK)
    pub = read(WORK / (PREFIX + '-publication.json'))
    assert pub['published'] and pub['background_gate_exit'] == 0
    assert (WORK/(PREFIX+'-build.exit')).read_text().strip() == '0'
    assert (WORK/(PREFIX+'-background.exit')).read_text().strip() == '0'
    baseline = read(BASELINE)
    before_stat = read(STAT_BEFORE)
    chosen = {}
    for p in WORK.iterdir():
        if p.is_file() and p.suffix in ('.json', '.txt', '.log') and not p.name.startswith(PREFIX):
            if baseline.get(p.name) != sha(p) or before_stat.get(p.name) != p.stat().st_mtime_ns:
                chosen['gate/' + p.name] = p
    for p in WORK.glob(PREFIX + '*'):
        if p.is_file() and p.suffix in ('.json', '.log', '.exit'): chosen['checkpoint/' + p.name] = p
    for old in ['linked-lanes-final', 'linked-lanes-controls-final', 'linked-lanes-controls-retry']:
        for p in WORK.glob(old + '*'):
            if p.is_file() and p.suffix in ('.json','.log','.exit','.interrupted'):
                chosen['prior-candidates/' + p.name] = p
        for p in (WORK/(old+'-source')).rglob('*'):
            if p.is_file(): chosen['prior-candidates/' + old + '/source/' + p.relative_to(WORK/(old+'-source')).as_posix()] = p
    for p in (WORK/'linked-lanes-controls-final-track-scroll-failure').glob('*.json'):
        chosen['prior-candidates/track-scroll-failure/' + p.name] = p
    for p in (WORK/(PREFIX+'-source')).rglob('*'):
        if p.is_file(): chosen['source/' + p.relative_to(WORK/(PREFIX+'-source')).as_posix()] = p
    for folder in [WORK/'agent-linked-controls', WORK/'agent-stream-lanes', WORK/'agent-linked-streams',
                   WORK/'agent-audio-plan-preflight', WORK/'agent-channel-deadlines',
                   WORK/'agent-preview-credit-deadline',
                   WORK/'linked-lanes-controls-retry-track-scroll-check',
                   WORK/'linked-lanes-controls-retry-preview-diagnostic',
                   WORK/'linked-lanes-controls-retry-preview-repeat-1',
                   WORK/'linked-lanes-controls-retry-preview-repeat-2', helper_dir]:
        for p in folder.rglob('*'):
            if p.is_file() and p.suffix in ('.json', '.log', '.ai', '.py', '.tsv', '.c', '.h', '.cpp') and 'native' not in p.parts:
                chosen['focused/' + p.relative_to(WORK).as_posix()] = p
    for n in ['linked-lanes-checkpoint.py','linked-lanes-evidence.py','linked-lanes-1080.py',
              'run-linked-lanes-build.ps1','run-linked-lanes-background.ps1']:
        chosen['drivers/' + n] = WORK/n
    for n in ['editor.ai','editor_io.ai']:
        chosen['sdk-overlay/stdlib/' + n] = WORK/'AIR-SDK/stdlib'/n
    chosen['sdk-overlay/stdlib/channel.ai'] = WORK/'AIR-SDK/stdlib/channel.ai'
    for p in WORK.glob('linked-lanes-controls-retry-preview-*.log'):
        chosen['prior-candidates/' + p.name] = p
    # Test-created pictures remain private. Their hashes are retained in bound receipts.
    payloads = {}
    manifest = []
    for name,p in sorted(chosen.items()):
        raw = p.read_bytes()
        if p.suffix == '.json': data = json.dumps(sanitize(read(p)), indent=2).encode()
        elif p.suffix in ('.log', '.txt', '.tsv'): data = sanitize(raw.decode('utf-8-sig', errors='replace')).encode()
        else: data = raw
        payloads[name] = data
        manifest.append({'path': name, 'original_sha256': sha(p), 'archived_sha256': hashlib.sha256(data).hexdigest()})
    payloads['manifest.json'] = json.dumps({'schema':'genesis.linked-media.archive.v1', 'entries':manifest,
        'source_and_receipt_hashes_are_original':True, 'logs_and_json_paths_redacted':True,
        'no_executables_dlls_original_projects_or_source_media':True},indent=2).encode()
    target = ROOT/'archive/linked-media-windows-2026-10-10.tar.gz'
    assert not target.exists()
    target.parent.mkdir(exist_ok=True)
    with tarfile.open(target, 'w:gz') as tar:
        for name,data in sorted(payloads.items()):
            info = tarfile.TarInfo(name); info.size=len(data); info.mtime=0
            tar.addfile(info, io.BytesIO(data))
    audio=read(WORK/'audio-plan-preflight.json')
    linked=read(WORK/'linked-media-tests.json')
    receipt = {'schema':'genesis.linked-media.windows.acceptance.v1',
        'captured_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'published':pub, 'source_freeze':read(WORK/(PREFIX+'-frozen.json')),
        'audio_preflight':audio, 'linked_commands':linked,
        'channel_deadlines':read(WORK/'channel-deadlines-tests.json'),
        'real_1080':read(WORK/(PREFIX+'-1080-acceptance.json')),
        'real_1080_helper_directory':str(helper_dir),
        'archive':{'path':target.relative_to(ROOT).as_posix(),'sha256':sha(target),'members':len(payloads)},
        'background_only':True, 'interactive_ui_device_and_sustained_cadence_deferred':True}
    output=ROOT/'docs/validation/linked-media-windows-2026-10-10.json'
    assert not output.exists(); output.parent.mkdir(exist_ok=True)
    output.write_text(json.dumps(sanitize(receipt),indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'archive_sha256':sha(target),'members':len(payloads),'receipt':str(output)}))

if __name__ == '__main__':
    if sys.argv[1]=='capture': capture()
    elif sys.argv[1]=='capture-stat': capture_stat()
    elif sys.argv[1]=='archive': archive(sys.argv[2])
