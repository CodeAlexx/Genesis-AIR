from pathlib import Path
p=Path('tests/audio_plan_preflight.ai'); s=p.read_text(encoding='utf-8-sig')
needle='''    row(output,name,"source",match media.source_audio_range'''
s=s.replace(needle,'''    // Inspect the actual adapter wire plan without a GPU/decoder call. Audio-only
    // clips on a V lane must neither add picture paths nor visit picture effects.
    var picture_fonts: array<string> = array.new()
    var picture_cache: media.RenderCache = media.render_cache(picture_fonts)
    row(output,name,"picture",match media.frame_plan(doc,first,"PREVIEW",path.join(work,"picture.rgba"),
        path.join(work,"picture-plan"),picture_cache) {
      ok(lines)=>match files.write_text(path.join(work,"picture-plan.txt"),text.join(lines,"\\n")) {
        ok(_)=>string.copy("OK"),err(_)=>string.copy("WRITE ERROR"),},err(problem)=>problem,})
    row(output,name,"filmstrip",match media.clip_picture_plan(doc,clip,first,"PREVIEW",path.join(work,"strip.rgba"),
        path.join(work,"strip-plan"),picture_cache) {
      ok(_)=>string.copy("OK"),err(problem)=>problem,})
    row(output,name,"source",match media.source_audio_range''',1)
p.write_text(s,encoding='utf-8',newline='\n')
p=Path('tests/audio_plan_preflight.py'); s=p.read_text(encoding='utf-8')
s=s.replace('def cases(source):','def cases(source, av=None):')
s=s.replace('''    add("valid-after",copy.deepcopy(base),export=True,peak="ACCEPT")''','''    if av is not None:
        legacy=copy.deepcopy(base)
        legacy["sources"][0].update(path=str(av),has_video=True,width=16,height=16)
        legacy["tracks"][0]["kind"]=0
        add("mask-legacy-both",legacy,export=True,peak="ACCEPT")
        result[-1]["picture_rgb"]=(45,90,135)
        paired=copy.deepcopy(legacy)
        paired["clips"][0].update(streams=1,group=99)
        paired["tracks"].append(dict(paired["tracks"][0],id=4,kind=1,name="A1"))
        paired["clips"].append(dict(paired["clips"][0],id=21,track=4,streams=2))
        add("mask-paired-once",paired,clip=21,export=True,peak="ACCEPT")
        result[-1]["picture_rgb"]=(45,90,135)
        muted=copy.deepcopy(paired); muted["tracks"][1]["muted"]=True
        add("mask-paired-audio-muted",muted,clip=21,pcm="silence",export=True)
        result[-1]["picture_rgb"]=(45,90,135)
        audioonly=copy.deepcopy(legacy); audioonly["clips"][0]["streams"]=2
        add("mask-audio-only-on-video-lane",audioonly,export=True,peak="ACCEPT")
        result[-1].update(picture_rgb=(0,0,0),picture_empty=True,filmstrip="GA_VIDEO_NESTED_PROTOCOL")
        picturebad=copy.deepcopy(audioonly)
        effect(picturebad,20,"lut3d",{})
        picturebad["filter_text_params"].append(dict(filter=50,name="path",value=str(source)+".missing.cube"))
        add("mask-audio-only-dormant-picture-lut",picturebad,peak="ACCEPT",export=True)
        result[-1].update(picture_rgb=(0,0,0),picture_empty=True,filmstrip="GA_VIDEO_NESTED_PROTOCOL")
        masked=copy.deepcopy(pan); masked["clips"][0]["streams"]=1
        add("mask-video-only-audio-key",masked,pcm="silence",peak="GA_AUDIO_CLIP_ENV")
        masked=copy.deepcopy(offline); masked["clips"][0]["streams"]=1
        add("mask-video-only-offline-audio",masked,pcm="silence",peak="GA_AUDIO_CLIP_ENV",source_status=OFFLINE)
        splitnested=copy.deepcopy(nest)
        splitnested["clips"][0]["streams"]=1
        splitnested["clips"].insert(1,dict(splitnested["clips"][0],id=21,streams=2,track=12))
        add("mask-nested-child-pair-once",splitnested,clip=30,peak="ACCEPT",export=True)
        result[-1]["picture_rgb"]=(0,0,0)
        parentoff=copy.deepcopy(noff); parentoff["clips"][-1]["streams"]=1
        add("mask-nested-video-parent-offline-leaf",parentoff,clip=30,pcm="silence",peak="GA_AUDIO_CLIP_ENV",source_status=OFFLINE)
        leafoff=copy.deepcopy(noff); leafoff["clips"][0]["streams"]=1
        add("mask-nested-video-leaf-offline",leafoff,clip=30,pcm="silence",peak="ACCEPT",source_status=OFFLINE)
    add("valid-after",copy.deepcopy(base),export=True,peak="ACCEPT")''',1)
s=s.replace('''    sourcehash=sha(source); authored_cases=cases(source); originals={}; manifest=[]; sentinels={}''','''    sourcehash=sha(source)
    av=root/"independent AV 日本語.mkv"
    raw=root/"independent RGB.rgb"
    raw.write_bytes(bytes((45,90,135))*16*16*12)
    encoded=subprocess.run([str(tool(a.worker,"ffmpeg")),"-nostdin","-v","error","-f","rawvideo","-pixel_format","rgb24",
                            "-video_size","16x16","-framerate","30","-i",str(raw),"-i",str(source),
                            "-map","0:v:0","-map","1:a:0","-c:v","ffv1","-pix_fmt","gbrp16le","-c:a","pcm_s16le",
                            str(av)],capture_output=True,timeout=30,creationflags=FLAGS)
    assert encoded.returncode==0,encoded.stderr
    avhash=sha(av); rawhash=sha(raw)
    authored_cases=cases(source,av); originals={}; manifest=[]; sentinels={}''',1)
s=s.replace('''        if case["expected"]!="ACCEPT" and case["expected"]==case.get("whole",case["expected"]):''','''        if case.get("picture_empty"):
            check(states["picture"]=="OK",name+" masked picture plan")
            commands=(work/"picture-plan.txt").read_text(encoding="utf-8")
            check("independent" not in commands and "CANVAS" not in commands,name+" no masked picture source/group")
        if case.get("filmstrip"):
            check("["+case["filmstrip"]+"]" in states["filmstrip"],name+" audio-only filmstrip refused")
        if case["expected"]!="ACCEPT" and case["expected"]==case.get("whole",case["expected"]):''',1)
s=s.replace('''                expected=[v/32768 for v in stereo[:38400]]''','''                expected=[0.]*38400 if case["pcm"]=="silence" else [v/32768 for v in stereo[:38400]]''',1)
s=s.replace('''                check(error<=2e-6,name+" independent PCM24 master "+str(error))''','''                check(error<=2e-6,name+" independent PCM24 master "+str(error))
                if "picture_rgb" in case:
                    picture=subprocess.run([str(tool(a.worker,"ffmpeg")),"-nostdin","-v","error","-i",str(output),
                                            "-map","0:v:0","-f","rawvideo","-pix_fmt","rgb48le","pipe:1"],
                                           capture_output=True,timeout=30,creationflags=FLAGS)
                    check(picture.returncode==0,name+" independent video decode")
                    pixels=array("H"); pixels.frombytes(picture.stdout)
                    check(len(pixels)==12*16*16*3,name+" exact masked picture frame count")
                    worst=max((abs(value-case["picture_rgb"][n%3]*257) for n,value in enumerate(pixels)),default=0.)
                    check(worst<=5,name+" authored picture coverage "+str(worst))''',1)
s=s.replace('''    check(sha(source)==sourcehash,"source unchanged")''','''    check(sha(source)==sourcehash and sha(av)==avhash and sha(raw)==rawhash,"sources unchanged")''',1)
s=s.replace('''worker_sha256=sha(a.worker),source_sha256=sourcehash,''','''worker_sha256=sha(a.worker),source_sha256=sourcehash,av_sha256=avhash,raw_rgb_sha256=rawhash,''',1)
p.write_text(s,encoding='utf-8',newline='\n')
