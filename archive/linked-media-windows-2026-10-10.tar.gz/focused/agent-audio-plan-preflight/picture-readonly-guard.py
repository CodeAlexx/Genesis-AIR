from pathlib import Path
p=Path('src/timeline_media.ai'); s=p.read_text()
s=s.replace('editor.clip_value_at(doc,','picture_clip_value_at(doc,')
a=s.index('fn fade(')
helper='''// Picture inspection must not intern absent default parameter names. A stored
// curve already owns its name; an unanimated row simply uses its neutral value.
fn picture_clip_value_at(doc: ref<editor.Document>, clip: u64, param: str,
    frame: i64, fallback: f64) -> f64 effects {alloc} {
  if not filter_keys.has(doc,clip,param) {return fallback}
  editor.clip_value_at(doc,clip,param,frame,fallback)
}

'''
s=s[:a]+helper+s[a:]
p.write_text(s,encoding='utf-8',newline='\n')
