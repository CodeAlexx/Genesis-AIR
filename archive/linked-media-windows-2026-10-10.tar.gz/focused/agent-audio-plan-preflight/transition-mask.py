from pathlib import Path
p=Path('src/timeline_media.ai'); s=p.read_text(encoding='utf-8')
s=s.replace('editor.transition_at(doc,','picture_transition_at(doc,')
a=s.index('fn composited_clip(')
helper='''// Stream routing can leave an authored audio-only pair on a V lane. It must
// not activate picture transitions; unresolved legacy pairs keep their errors.
fn picture_transition_at(doc: ref<editor.Document>, track: u64, frame: i64)
    -> option<u64> effects {alloc} {
  let id: u64 = match editor.transition_at(doc,track,frame) {none=>{return option.none()},some(value)=>value,}
  match editor.transition(doc,id) {
    none=>{},some(transition)=>{match editor.boundary_at(doc,track,transition.center) {
      none=>{},some(boundary)=>{
        match editor.clip(doc,boundary.outgoing) {
          none=>{},some(clip)=>{if not editor.clip_has_video(clip) {return option.none()}},
        }
        match editor.clip(doc,boundary.incoming) {
          none=>{},some(clip)=>{if not editor.clip_has_video(clip) {return option.none()}},
        }
      },
    }},
  }
  option.some(id)
}

'''
s=s[:a]+helper+s[a:]
p.write_text(s,encoding='utf-8',newline='\n')
