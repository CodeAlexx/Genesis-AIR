from pathlib import Path
p=Path('tests/audio_plan_preflight.py');s=p.read_text()
s=s.replace('''        masked=copy.deepcopy(pan); masked["clips"][0]["streams"]=1''','''        transition_only=copy.deepcopy(audioonly)
        transition_only["clips"][0]["length"]=6
        transition_only["clips"].append(dict(transition_only["clips"][0],id=21,start=6,source_in=6))
        transition_only["names"].append("unsupported-picture-transition")
        transition_only["transitions"].append(dict(id=60,owner=2,track=3,center=6,duration=12,kind=1))
        add("mask-audio-only-picture-transition",transition_only,export=True,peak="ACCEPT")
        result[-1].update(picture_rgb=(0,0,0),picture_empty=True,filmstrip="GA_VIDEO_NESTED_PROTOCOL")
        masked=copy.deepcopy(pan); masked["clips"][0]["streams"]=1''',1)
p.write_text(s,encoding='utf-8',newline='\n')
p=Path('tests/audio_plan_preflight.ai'); s=p.read_text()
s=s.replace('''    row(output,name,"immutable",string.copy(if encoded(doc) == before {"OK"}else{"CHANGED"}))''','''    let after: string = encoded(doc)
    if after != before {
      let _ = files.write_text(path.join(work,"before.air"),before)
      let _ = files.write_text(path.join(work,"after.air"),after)
    }
    row(output,name,"immutable",string.copy(if after == before {"OK"}else{"CHANGED"}))''',1)
p.write_text(s,encoding='utf-8',newline='\n')
