from pathlib import Path
p=Path('src/timeline_media.ai'); s=p.read_text(encoding='utf-8')
helper='''// Only contributing clip contexts reach this preflight. Gain/fade curves have
// exact sample envelopes; the remaining active audio curves cannot yet retain
// their DSP/time history. Dormant instance curves do not affect audible output.
fn audio_automation_preflight(doc: ref<editor.Document>, clip: editor.Clip)
    -> result<unit,string> effects {alloc} {
  var at: u64 = 0
  loop {if at >= array.len(struct.borrow(doc,field=keys)) {break}
    let key: editor.Key = array.get(struct.borrow(doc,field=keys),at)
    at=at+1
    if key.clip != clip.id {continue}
    let name: string = editor.name_text(doc,key.param)
    if str.eq(name,"pan") or str.eq(name,"speed") {
      return result.err("[GA_AUDIO_AUTOMATION_UNSUPPORTED] Animated clip pan or speed needs preserved audio history")
    }
    let canonical: string = filter_keys.canonical(name)
    var family: array<string> = text.split(canonical,".")
    if array.len(family) != 2 {continue}
    let kind: str = array.borrow(family,0)
    if not str.eq(kind,"speed") and not chrome.is_audio_kind(kind) {continue}
    var parts: array<string> = text.split(name,".")
    let scoped: u64 = if array.len(parts) == 4 and not str.eq(name,canonical) {
      match text.parse_u64(array.borrow(parts,1)) {some(value)=>value,none=>0,}
    }else{0}
    var filter_at: u32 = 0
    loop {match editor.filter_at(doc,clip.id,filter_at) {
      none=>{break},some(filter)=>{
        if (scoped == 0 or filter == scoped) and editor.filter_enabled(doc,filter) and
            str.eq(editor.filter_kind(doc,filter),kind) {
          return result.err("[GA_AUDIO_AUTOMATION_UNSUPPORTED] Animated enabled audio filter needs preserved graph history")
        }
      },}
      filter_at=filter_at+1
    }
  }
  result.ok(())
}

'''
s=s.replace('fn flat_audio_lines(',helper+'fn flat_audio_lines(',1)
s=s.replace('if not source.audio or not source.online { continue }','if not source.audio { continue }',1)
s=s.replace('''    if not source_range_ok(doc, clip) {
      return result.err("audio clip speed and length exceed its source frames")
    }
    let speed: f64 = effective_speed(doc, clip)''','''    let speed: f64 = effective_speed(doc, clip)''',1)
s=s.replace('''    if speed == 0.0 { continue }
    if not math.is_finite(speed)''','''    if speed == 0.0 { continue }
    if not source.online {return result.err("[GA_AUDIO_SOURCE_OFFLINE] Audible clip source is offline")}
    try audio_automation_preflight(doc,clip)
    if not source_range_ok(doc, clip) {
      return result.err("audio clip speed and length exceed its source frames")
    }
    if not math.is_finite(speed)''',1)
s=s.replace('''  if bounds.speed == 0.0 {return result.ok(())}
  let chain: string''','''  if bounds.speed == 0.0 {return result.ok(())}
  if clip.nested == 0 {
    let slot: u64 = match editor.source_slot(doc,clip.source) {
      some(value)=>value,none=>{return result.err("[GA_AUDIO_NESTED_PROTOCOL] Nested leaf source is missing")},
    }
    let source: SourceInfo = source_info(doc,slot)
    if not source.audio {return result.ok(())}
    if not source.online {return result.err("[GA_AUDIO_SOURCE_OFFLINE] Audible nested leaf source is offline")}
  }
  try audio_automation_preflight(doc,clip)
  let chain: string''',1)
s=s.replace('if not source.audio or not source.online {continue}','if not source.audio {continue}',1)
a=s.index('  // The current audio graph accepts complete gain/fade curves.')
b=s.index('  let bounds: NestedAudioBounds',a)
s=s[:a]+'''  // Retain the public direct-envelope context while exposing the shared cause.
  match audio_automation_preflight(doc,clip) {
    ok(_)=>{},err(problem)=>{return result.err(text.concat("[GA_AUDIO_CLIP_ENV] ",problem))},
  }
'''+s[b:]
s=s.replace('''  if not source.audio or not source.online {
    return result.err("[GA_AUDIO_CLIP_ENV] Processed clip source is offline or has no audio")
  }''','''  if not source.audio {return result.err("[GA_AUDIO_CLIP_ENV] Processed clip source has no audio")}
  if not source.online {return result.err("[GA_AUDIO_CLIP_ENV] [GA_AUDIO_SOURCE_OFFLINE] Processed clip source is offline")}''',1)
s=s.replace('''  let has_audio: bool = source.has_audio
  var audition:''','''  let has_audio: bool = source.has_audio
  // Source audition deliberately ignores Program mixer state, but its original
  // selected asset's availability must survive the fresh audition graph.
  if has_audio and not source.online {
    return result.err("[GA_AUDIO_SOURCE_OFFLINE] Selected sound source is offline")
  }
  var audition:''',1)
# The one private export executor now receives a successfully resolved descriptor.
s=s.replace('''               cancel: str, progress: str, profile: u32)
               -> result<unit, string> effects''','''               cancel: str, progress: str, profile: u32, sounds: ref<array<string>>)
               -> result<unit, string> effects''',1)
a=s.index('  // Resolve the complete recursive audio descriptor before starting an encoder')
b=s.index('  let cache:',a)
s=s[:a]+s[b:]
a=s.index('  match render_into(doc, worker, str.view(partial), fonts, cancel, progress, profile)')
s=s[:a]+'''  // Pure audio rejection owns neither output nor sidecars. Resolve before
  // entering the executor's cleanup boundary; preserve foreign sidecars.
  let range: editor.Transport = editor.export_range(doc)
  try export_current(cancel)
  if range.mark_out <= range.mark_in {return result.err("[GA_EXPORT_RANGE] the export range is empty")}
  match editor.sequence_slot(doc,doc.active) {
    none=>{return result.err("[GA_EXPORT_SEQUENCE] the project has no active sequence")},some(_)=>{},
  }
  let fps: f64 = editor.sequence_fps(doc,doc.active)
  if not (fps > 0.0) {return result.err("[GA_EXPORT_FPS] the sequence frame rate is invalid")}
  var sounds: array<string> = try audio_lines(doc,range.mark_in,range.mark_out,fps,false)
'''+s[a:]
s=s.replace('match render_into(doc, worker, str.view(partial), fonts, cancel, progress, profile) {','match render_into(doc, worker, str.view(partial), fonts, cancel, progress, profile,sounds) {',1)
p.write_text(s,encoding='utf-8',newline='\n')
