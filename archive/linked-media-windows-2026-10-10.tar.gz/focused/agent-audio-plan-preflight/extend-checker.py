from pathlib import Path
p=Path('tests/audio_plan_preflight.py'); s=p.read_text(encoding='utf-8-sig')
s=s.replace('    offline=copy.deepcopy(base)','''    compressor=copy.deepcopy(base)
    effect(compressor,20,"compressor",dict(threshold=-14,ratio=4,attack=3,release=80))
    keys(compressor,20,2,"filter.50.compressor.threshold",[(-12,-30,2),(30,-6,2)])
    add("direct-compressor-curve",compressor,AUTO,peak=AUTO)
    offline=copy.deepcopy(base)''',1)
s=s.replace('for suffix in (".nested-count",".title-count",".fx-count"):','for suffix in (".nested-count",".prepared-count",".preclip0.rgba"):')
s=s.replace('    failures=[]; maximum=0.; compared=0','    failures=[]; maximum=0.; master_maximum=0.; compared=0; master_compared=0')
s=s.replace('check(err<=1.01,','check(err<=1.0,')
s=s.replace('''            check((work/"refusal.mkv").is_file(),name+" valid export recovery")''','''            output=work/"refusal.mkv"
            check(output.is_file(),name+" valid export recovery")
            if output.is_file():
                decoded=subprocess.run([str(tool(a.worker,"ffmpeg")),"-nostdin","-v","error","-i",str(output),
                                        "-map","0:a:0","-f","f32le","pipe:1"],capture_output=True,
                                       timeout=30,creationflags=FLAGS)
                check(decoded.returncode==0,name+" independent lossless master decode")
                actual=array("f"); actual.frombytes(decoded.stdout)
                expected=[v/32768 for v in stereo[:38400]]
                if case["pcm"]=="gain-fades":
                    expected=[v*(.25+.5*min(n//2,9600)/9600)*min(1,(n//2)/4800)*min(1,(19200-n//2)/4800)
                              for n,v in enumerate(expected)]
                check(len(actual)==len(expected),name+" exact master sample count")
                error=max((abs(x-y) for x,y in zip(actual,expected)),default=0.)
                master_maximum=max(master_maximum,error); master_compared+=len(actual)
                check(error<=2e-6,name+" independent PCM24 master "+str(error))''')
s=s.replace('''                maximum_pcm_error=maximum,sentinels_preserved=sentinel_ok,failures=failures,observations=observed)''','''                maximum_pcm_error=maximum,compared_master_values=master_compared,maximum_master_error=master_maximum,
                sentinels_preserved=sentinel_ok,failures=failures,passed=not failures,observations=observed)''')
s=s.replace("print(f'Audio preflight PASS {len(authored_cases)} cases; {compared} PCM values; maximum {maximum:.9f} codes')", "print(f'Audio preflight PASS {len(authored_cases)} cases; {compared} PCM16 values max {maximum:.9f} codes; {master_compared} PCM24 values max {master_maximum:.12g}')")
p.write_text(s,encoding='utf-8',newline='\n')
