from pathlib import Path
p=Path('src/timeline_media.ai'); s=p.read_text(encoding='utf-8')
s=s.replace('''fn source_path(doc: ref<editor.Document>, clip: editor.Clip) -> option<string> effects {alloc} {
  match''','''fn source_path(doc: ref<editor.Document>, clip: editor.Clip) -> option<string> effects {alloc} {
  if not editor.clip_has_video(clip) {return option.none()}
  match''',1)
s=s.replace('''if value.track == track and value.owner == doc.active and value.enabled and
           value.start''','''if value.track == track and value.owner == doc.active and value.enabled and
           editor.clip_has_video(value) and value.start''',1)
s=s.replace('''not outgoing.enabled or not incoming.enabled { return option.none() }''','''not outgoing.enabled or not incoming.enabled or
     not editor.clip_has_video(outgoing) or not editor.clip_has_video(incoming) { return option.none() }''',1)
s=s.replace('''if clip.owner == doc.active and clip.enabled and clip.start <= frame and
           editor.clip_end(clip) > frame and editor.track_visible(doc, clip.track)''','''if clip.owner == doc.active and clip.enabled and editor.clip_has_video(clip) and clip.start <= frame and
           editor.clip_end(clip) > frame and editor.track_kind(doc,clip.track) == editor.track_video() and
           editor.track_visible(doc, clip.track)''',1)
s=s.replace('''if clip.owner == doc.active and clip.nested != 0 and clip.enabled and
       editor.track_kind''','''if clip.owner == doc.active and clip.nested != 0 and clip.enabled and editor.clip_has_video(clip) and
       editor.track_kind''',1)
s=s.replace('''a.gain == b.gain and a.pan == b.pan and a.speed == b.speed and a.reverse == b.reverse''','''a.gain == b.gain and a.pan == b.pan and a.speed == b.speed and a.reverse == b.reverse and a.streams == b.streams''',1)
s=s.replace('''if clip.nested == 0 or clip.source != 0 or clip.length <= 0 or clip.source_in < 0 {''','''if not editor.clip_has_video(clip) or clip.nested == 0 or clip.source != 0 or clip.length <= 0 or clip.source_in < 0 {''',1)
s=s.replace('''if clip.owner != sequence or not clip.enabled or
       editor.track_kind''','''if clip.owner != sequence or not clip.enabled or not editor.clip_has_video(clip) or
       editor.track_kind''')
s=s.replace('''owner_frame < clip.start or owner_frame >= editor.clip_end(clip) or
     editor.track_kind''','''owner_frame < clip.start or owner_frame >= editor.clip_end(clip) or
     not editor.clip_has_video(clip) or editor.track_kind''',1)
s=s.replace('''if clip.owner != doc.active or not clip.enabled or
       not editor.track_audible''','''if clip.owner != doc.active or not clip.enabled or not editor.clip_has_audio(clip) or
       not editor.track_audible''',1)
s=s.replace('''  if array.len(ancestors) > 16 or str.len(instance) > 256 {''','''  if not editor.clip_has_audio(clip) {return result.ok(())}
  if array.len(ancestors) > 16 or str.len(instance) > 256 {''',1)
s=s.replace('''if child.owner != clip.nested or not child.enabled or not editor.track_audible''','''if child.owner != clip.nested or not child.enabled or not editor.clip_has_audio(child) or not editor.track_audible''',1)
s=s.replace('''if clip.owner != doc.active or not clip.enabled or clip.nested == 0 or
        not editor.track_audible''','''if clip.owner != doc.active or not clip.enabled or clip.nested == 0 or not editor.clip_has_audio(clip) or
        not editor.track_audible''',1)
s=s.replace('''  if clip.nested != 0 {return compound_envelope_plan(doc,clip,buckets,output)}''','''  if not editor.clip_has_audio(clip) {return result.err("[GA_AUDIO_CLIP_ENV] Clip audio stream is disabled")}
  if clip.nested != 0 {return compound_envelope_plan(doc,clip,buckets,output)}''',1)
s=s.replace('''  if clip.nested == 0 or clip.source != 0 or buckets == 0 or buckets > 65536 {''','''  if not editor.clip_has_audio(clip) or clip.nested == 0 or clip.source != 0 or buckets == 0 or buckets > 65536 {''',1)
# Native preview policy must ignore picture-disabled clips' spatial operators.
s=s.replace('''    if filter.enabled and not monitor_independent(str.view(struct.borrow(filter,field=kind))) {
      native = true
      break
    }''','''    if filter.enabled and not monitor_independent(str.view(struct.borrow(filter,field=kind))) {
      match editor.clip(doc,filter.clip) {
        none=>{},some(clip)=>{if editor.clip_has_video(clip) {
          native = true
          break
        }},
      }
    }''',1)
p.write_text(s,encoding='utf-8',newline='\n')
