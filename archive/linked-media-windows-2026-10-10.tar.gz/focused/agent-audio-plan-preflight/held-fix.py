from pathlib import Path
p=Path('src/timeline_media.ai'); s=p.read_text(encoding='utf-8')
s=s.replace('fn audio_automation_preflight(doc: ref<editor.Document>, clip: editor.Clip)','fn audio_automation_preflight(doc: ref<editor.Document>, clip: editor.Clip, held: bool)')
s=s.replace('if str.eq(name,"pan") or str.eq(name,"speed") {','if (not held and str.eq(name,"pan")) or str.eq(name,"speed") {',1)
s=s.replace('    if not str.eq(kind,"speed") and not chrome.is_audio_kind(kind) {continue}','    if (held and not str.eq(kind,"speed")) or\n        (not str.eq(kind,"speed") and not chrome.is_audio_kind(kind)) {continue}',1)
s=s.replace('''    // A held picture has no progressing audio samples. Other audible clips can still mix.
    if speed == 0.0 { continue }
    if not source.online {return result.err("[GA_AUDIO_SOURCE_OFFLINE] Audible clip source is offline")}
    try audio_automation_preflight(doc,clip)''','''    // A static held picture is silent, except that an active Rate curve could
    // make it progress. Refuse that unsupported time context before skipping it.
    try audio_automation_preflight(doc,clip,speed == 0.0)
    if speed == 0.0 { continue }
    if not source.online {return result.err("[GA_AUDIO_SOURCE_OFFLINE] Audible clip source is offline")}''',1)
s=s.replace('''  if bounds.speed == 0.0 {return result.ok(())}
  if clip.nested == 0 {''','''  if clip.nested == 0 {''',1)
s=s.replace('''    if not source.online {return result.err("[GA_AUDIO_SOURCE_OFFLINE] Audible nested leaf source is offline")}
  }
  try audio_automation_preflight(doc,clip)''','''    if bounds.speed != 0.0 and not source.online {
      return result.err("[GA_AUDIO_SOURCE_OFFLINE] Audible nested leaf source is offline")
    }
  }
  try audio_automation_preflight(doc,clip,bounds.speed == 0.0)
  if bounds.speed == 0.0 {return result.ok(())}''',1)
s=s.replace('audio_automation_preflight(doc,clip) {','audio_automation_preflight(doc,clip,false) {',1)
# Parent and child entry loops previously skipped zero rate before definition.
s=s.replace('''      if child_bounds.speed == 0.0 or child_bounds.last <= child_first or child_bounds.first >= child_last {continue}''','''      if child_bounds.last <= child_first or child_bounds.first >= child_last {continue}''',1)
s=s.replace('''    if bounds.speed == 0.0 or bounds.last <= origin or bounds.first >= finish_sample {continue}
    let instance:''','''    if bounds.last <= origin or bounds.first >= finish_sample {continue}
    if bounds.speed == 0.0 {
      try audio_automation_preflight(doc,clip,true)
      continue
    }
    let instance:''',1)
p.write_text(s,encoding='utf-8',newline='\n')
p=Path('tests/audio_plan_preflight.py'); s=p.read_text(encoding='utf-8')
s=s.replace('''    offline=copy.deepcopy(base)''','''    for spelling in ("speed","filter.50.speed.rate","speed.rate"):
        doc=copy.deepcopy(base); doc["clips"][0]["speed"]=0
        if spelling!="speed": effect(doc,20,"speed",{"rate":1})
        keys(doc,20,2,spelling,[(0,0,4),(6,1,4)])
        add("held-"+spelling.replace(".","-"),doc,AUTO,peak=AUTO)
    held_muted=copy.deepcopy(result[-1]["doc"]); held_muted["tracks"][0]["muted"]=True
    add("held-speed-muted",held_muted,pcm="silence")
    held_noaudio=copy.deepcopy(result[-2]["doc"]); held_noaudio["sources"][0]["has_audio"]=False
    add("held-speed-noaudio",held_noaudio,pcm="silence")
    held_dormant=copy.deepcopy(result[-3]["doc"]); held_dormant["filters"][0]["enabled"]=False
    add("held-speed-disabled-filter",held_dormant,pcm="silence")
    offline=copy.deepcopy(base)''',1)
s=s.replace('''    noff=copy.deepcopy(nest);''','''    for scope in ("parent","child"):
        doc=copy.deepcopy(nest)
        target=doc["clips"][-1] if scope=="parent" else doc["clips"][0]
        target["speed"]=0
        keys(doc,target["id"],target["owner"],"speed",[(0,0,4),(6,1,4)])
        add("nested-held-"+scope+"-speed",doc,AUTO,clip=30,peak=AUTO)
    noff=copy.deepcopy(nest);''',1)
p.write_text(s,encoding='utf-8',newline='\n')
