from pathlib import Path
import sys,json,array,subprocess
sys.path.insert(0,'tests')
from media_runtime import tool
r=Path('build-windows/agent-audio-plan-preflight/masks-cases')
f=tool('build-windows/cadence-reserve-gain-runtime/genesis-gcompose.exe','ffmpeg')
done=subprocess.run([str(f),'-nostdin','-v','error','-i',str(r/'independent AV 日本語.mkv'),'-map','0:v:0','-f','rawvideo','-pix_fmt','rgb48le','pipe:1'],capture_output=True)
a=array.array('H'); a.frombytes(done.stdout)
out={'schema':'genesis.independent-rgb-authoring-specification','source_decoded_first':list(a[:3]),'declared_rgb8_to_full_unorm16':[45*257,90*257,135*257],'actual_rgb24_to_planar16':[45*256,90*256,135*256],'full_source_maximum_error_vs_bitshift':max(abs(v-(45,90,135)[i%3]*256) for i,v in enumerate(a)), 'correction':'Author rgb48le values independently at rgb8*257, preserve exact5code masterthreshold; no output-derived reference'}
Path('build-windows/agent-audio-plan-preflight/rgb-authoring-correction.json').write_text(json.dumps(out,indent=2)); print(out)
p=Path('tests/audio_plan_preflight.py'); s=p.read_text()
s=s.replace('raw.write_bytes(bytes((45,90,135))*16*16*12)','raw.write_bytes(array("H",(45*257,90*257,135*257)).tobytes()*16*16*12)')
s=s.replace('"-pixel_format","rgb24"','"-pixel_format","rgb48le"')
s=s.replace('''    avhash=sha(av); rawhash=sha(raw)''','''    decoded_source=subprocess.run([str(tool(a.worker,"ffmpeg")),"-nostdin","-v","error","-i",str(av),
                                  "-map","0:v:0","-f","rawvideo","-pix_fmt","rgb48le","pipe:1"],
                                 capture_output=True,timeout=30,creationflags=FLAGS)
    assert decoded_source.returncode==0 and decoded_source.stdout==raw.read_bytes(), "Independent native16 source authoring must be exact"
    avhash=sha(av); rawhash=sha(raw)''')
p.write_text(s,encoding='utf-8',newline='\n')
