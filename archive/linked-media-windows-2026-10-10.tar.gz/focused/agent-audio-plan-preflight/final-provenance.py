from pathlib import Path
import json,hashlib
r=Path('build-windows/agent-audio-plan-preflight')
h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
files=['src/timeline_media.ai','tests/audio_plan_preflight.ai','tests/audio_plan_preflight.py']
receipt={'schema':'genesis.audio-plan-preflight-stream-final-provenance','base_head':'2d13fdc',
'sources':{p:h(p) for p in files},'sdk':{p:h(p) for p in ['build-windows/AIR-SDK/stdlib/editor.ai','build-windows/AIR-SDK/stdlib/editor_io.ai']},
'client_sha256':h(r/'masks-final.exe'),'generated_c_sha256':h(r/'generated/masks-final.c'),
'worker_sha256':h('build-windows/cadence-reserve-gain-runtime/genesis-gcompose.exe'),
'runtime_sha256':h('build-windows/cadence-reserve-gain-native/runtime/Release/air_rt.lib'),
'reports':{p:h(r/p) for p in ['baseline.json','final.json','held.json','masks.json','rgb-authoring-correction.json','masks-final.json']},
'counts':{'baseline':41,'preflight_first_fixed':42,'held_speed':50,'stream_masks_final':61},
'evidence':{'independent_pcm16_values':1536000,'maximum_pcm16_codes':.7355208333328846,
'independent_pcm24_master_values':384000,'maximum_pcm24_error':1.207934485492057e-7,
'pcm16_threshold_codes':1,'pcm24_threshold':2e-6,'picture_threshold_codes16':5,
'authored_native16_source_exact_full_decode':True,'foreign_sidecars_preserved':True,'originals_unchanged':True,'cache_and_partial_cleanup':True},
'limits':['No native GUI/device integration performed; root full Windows gate still required',
'Unsupported active audible automation refuses; this does not implement those curves',
'Mask3 legacy compatibility and explicit1/2 adapter behavior proven; actual UI insertion/linked editing belongs to root/SDK tests',
'Direct and nested processed peak runtime compatibility uses existing full suite; this fixture checks peak planning eligibility',
'Picture read-only getter scope is absent-name guard; authored curves retain existing evaluation'],
'active_jobs':False}
(r/'stream-final-provenance.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8')
print(json.dumps(receipt,indent=2))
