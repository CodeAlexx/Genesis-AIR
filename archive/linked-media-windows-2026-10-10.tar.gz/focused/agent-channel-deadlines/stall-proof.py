from pathlib import Path
import hashlib,json,socket,subprocess,threading,time
ROOT=Path(__file__).resolve().parents[2]
WORK=Path(__file__).resolve().parent
CLIENT=WORK/'stall-native/Release/genesis-channel-deadlines.exe'
PAYLOAD=bytes((i*17+3)%256 for i in range(262144))
def line(sock):
    out=bytearray()
    while not out.endswith(b'\n'):
        data=sock.recv(1)
        if not data:return bytes(out)
        out+=data
        if len(out)>96:raise ValueError('oversized header')
    return bytes(out)
def frame(sock):
    head=line(sock)
    fields=head.strip().split()
    if len(fields)!=5 or fields[0]!=b'A1':return {'header':head.decode(errors='replace'),'complete':False,'data':b''}
    wanted=int(fields[4]); data=bytearray()
    while len(data)<wanted:
        try:chunk=sock.recv(wanted-len(data))
        except ConnectionResetError:break
        if not chunk:break
        data+=chunk
    return {'header':head.decode().strip(),'kind':int(fields[1]),'sequence':int(fields[2]),'dropped':int(fields[3]),'wanted':wanted,'data':bytes(data),'complete':len(data)==wanted}
def run(mode):
    out=WORK/f'stall-{mode}';out.mkdir(exist_ok=True)
    listener=socket.socket(); listener.setsockopt(socket.SOL_SOCKET,socket.SO_RCVBUF,4096)
    listener.bind(('127.0.0.1',0));listener.listen(1);listener.settimeout(5)
    port=listener.getsockname()[1]; result={'mode':mode,'frames':[]}; error=[]
    def consume():
        try:
            sock,_=listener.accept()
            with sock:
                sock.settimeout(5)
                result['receive_buffer']=sock.getsockopt(socket.SOL_SOCKET,socket.SO_RCVBUF)
                assert line(sock)==b'deadline-test\n'
                if mode=='credit':
                    first=frame(sock);assert first['data']==b'first';result['frames'].append(first)
                    time.sleep(.2);sock.sendall(b'C')
                else:time.sleep(.2)
                result['frames'].append(frame(sock))
                if mode in ('long','credit'):result['frames'].append(frame(sock))
        except Exception as exc:error.append(repr(exc))
        finally:listener.close()
    thread=threading.Thread(target=consume);thread.start()
    proc=subprocess.run([str(CLIENT),mode,str(port),str(out)],capture_output=True,text=True,timeout=8)
    thread.join(6);assert not thread.is_alive()
    (out/'stdout.txt').write_text(proc.stdout);(out/'stderr.txt').write_text(proc.stderr)
    result['exit_code']=proc.returncode;result['peer_errors']=error
    if (out/'timing.tsv').exists():result['write_elapsed_ns'],result['code']=map(int,(out/'timing.tsv').read_text().split('\t'))
    if (out/'report.json').exists():result['test']=json.loads((out/'report.json').read_text())['payload']
    frames=result['frames']
    exact=not error
    if mode=='credit':exact=exact and [(f.get('sequence'),f.get('data')) for f in frames]==[(1,b'first'),(2,b'second'),(3,b'done')]
    elif mode=='long':exact=exact and len(frames)==2 and frames[0].get('sequence')==1 and frames[0].get('data')==PAYLOAD and frames[1].get('data')==b'done' and frames[1].get('sequence')==2
    else:exact=exact and len(frames)==1 and frames[0].get('sequence')==1 and 0<len(frames[0].get('data',b''))<len(PAYLOAD) and PAYLOAD.startswith(frames[0].get('data',b''))
    result['exact_wire']=exact;result['passed']=proc.returncode==0 and exact
    for f in frames:
        data=f.pop('data');f['received_bytes']=len(data);f['sha256']=hashlib.sha256(data).hexdigest()
    (out/'wire.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2));return result
results=[run(mode) for mode in ('credit','long','legacy','fatal')]
(WORK/'real-tcp-stall-proof.json').write_text(json.dumps({'passed':all(x['passed'] for x in results),'results':results},indent=2)+'\n')
raise SystemExit(0 if all(x['passed'] for x in results) else 1)
