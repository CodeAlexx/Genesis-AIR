from pathlib import Path
import difflib, hashlib,json,subprocess
r=Path.cwd(); work=r/'build-windows/agent-channel-deadlines'; sdk=r/'build-windows/AIR-SDK'
def git(where,*args):return subprocess.run(['git','-c','core.autocrlf=false','-C',str(where),*args],check=True,stdout=subprocess.PIPE).stdout
pin=git(sdk,'rev-parse','HEAD').decode().strip(); assert pin=='df80f270dd28af76674b6e80a4f08970c081be3e'
base=git(sdk,'show','HEAD:stdlib/channel.ai').replace(b'\r\n',b'\n')
original=(work/'channel-before.ai').read_bytes(); assert original.replace(b'\r\n',b'\n')==base
assert hashlib.sha256(original).hexdigest()=='2637684d32186ffd329d28eebf70c0314d30992e7c3e171ca0e6ae0ba8f351aa'
target=(sdk/'stdlib/channel.ai').read_bytes().replace(b'\r\n',b'\n')
patch=r/'patches/air-channel-deadlines.patch'
diff='diff --git a/stdlib/channel.ai b/stdlib/channel.ai\n'+''.join(difflib.unified_diff(base.decode().splitlines(keepends=True),target.decode().splitlines(keepends=True),fromfile='a/stdlib/channel.ai',tofile='b/stdlib/channel.ai'))
patch.write_text(diff,encoding='utf-8',newline='\n')
proof=work/'overlay-base'; (proof/'stdlib').mkdir(parents=True,exist_ok=True)
if not(proof/'.git').exists():git(proof,'init')
source=proof/'stdlib/channel.ai';source.write_bytes(base)
git(proof,'apply','--check',str(patch));git(proof,'apply',str(patch)); assert source.read_bytes()==target
git(proof,'apply','--reverse','--check',str(patch));git(proof,'apply','--reverse',str(patch));assert source.read_bytes()==base
git(sdk,'apply','--reverse','--check',str(patch))
receipt={'sdk_pin':pin,'original_sha256':hashlib.sha256(original).hexdigest(),'source_sha256':hashlib.sha256((sdk/'stdlib/channel.ai').read_bytes()).hexdigest(),'source_lf_sha256':hashlib.sha256(target).hexdigest(),'patch_sha256':hashlib.sha256(patch.read_bytes()).hexdigest(),'forward_check':True,'reverse_check':True,'pinned_source_roundtrip':True}
(work/'overlay-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))
