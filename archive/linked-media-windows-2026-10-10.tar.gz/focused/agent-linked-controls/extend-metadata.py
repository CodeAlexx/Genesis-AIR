from pathlib import Path
p=Path('tests/linked_media.ai');s=p.read_text()
needle='  let audio_lane:u64=app.default_audio_track(state)\n  let _=editor.set_track_lock(struct.borrow(state,field=document),audio_lane,true)'
replacement='''  let _=commands.nudge(state,first,1)
  let _=commands.undo(state)
  let _=test.eq_u64(suite,editor.redo_depth(struct.borrow(state,field=history)),1,"Grouping refusal ledger contains a real redo snapshot")
  let audio_lane:u64=app.default_audio_track(state)
  let _=editor.set_track_lock(struct.borrow(state,field=document),audio_lane,true)'''
assert needle in s;s=s.replace(needle,replacement)
end='  test.conclude(suite,path.join(root,"linked-media-tests.json"),27)'
more='''  let _=test.start(suite,"Properties audio controls reflect metadata, not temporary playback suppression")
  var picture_only:app.App=app.app(provider.fake(root))
  let src:u64=source(picture_only,false,true)
  let placed:commands.Result=commands.append_source(picture_only,src,0,30)
  let _=commands.select_only(picture_only,placed.value)
  rows=chrome.properties_panel(frame,picture_only)
  let no_audio:bool=match row(rows,chrome.act_param_set(),"","gain") {none=>true,some(_)=>false,}
  let no_eq:bool=match row(rows,chrome.act_param_set(),"eq_3band","low") {none=>true,some(_)=>false,}
  let no_compressor:bool=match row(rows,chrome.act_filter_add(),"compressor","") {none=>true,some(_)=>false,}
  let _=test.check(suite,no_audio and no_eq and no_compressor,"Pure picture source exposes no misleading Audio/EQ/Dynamics controls")
  operation=0
  loop {if operation==2 {break}
    var unavailable:app.App=fixture(root)
    let video:u64=app.current_clip(unavailable)
    let audio:u64=linked.mate(struct.borrow(unavailable,field=document),video)
    let doc:ref<editor.Document> =struct.borrow(unavailable,field=document)
    if operation==0 {let slot:u64=option.unwrap(editor.clip_slot(doc,audio))
      struct.set(array.borrow(struct.borrow(doc,field=clips),slot),false,field=enabled)}else{
      let source_id:u64=option.unwrap(editor.clip(doc,video)).source
      let slot:u64=option.unwrap(editor.source_slot(doc,source_id))
      struct.set(array.borrow(struct.borrow(doc,field=sources),slot),false,field=online)}
    rows=chrome.properties_panel(frame,unavailable)
    let gain:option<u64> =row(rows,chrome.act_param_set(),"","gain")
    let retained:bool=match gain {none=>false,some(index)=>struct.get(array.borrow(rows,index),field=target)==audio,}
    let _=test.check(suite,retained,"Disabled clip or temporarily offline media keeps editable original A controls")
    operation=operation+1}
  let _=test.done(suite)
'''
assert end in s;s=s.replace(end,more+'  test.conclude(suite,path.join(root,"linked-media-tests.json"),28)');p.write_text(s,newline='\n')
