from pathlib import Path
p=Path('tests/linked_media.ai');s=p.read_text()
s=s.replace('import "../src/app.ai" as app','import "../src/app.ai" as app\nimport "../src/chrome.ai" as chrome\nimport "../src/input.ai" as input\nimport "../src/layout.ai" as layout')
s=s.replace('fs.write,io.write,time} {','fs.write,io.write,process,time} {')
helper='''// Locate the same shared controls that the native Properties painter and hit test use.
fn row(controls:ref<array<chrome.Control>>,action:u32,kind:str,name:str) -> option<u64> effects {alloc} {
  var i:u64=0
  loop {if i>=array.len(controls) {break}
    let c:ref<chrome.Control> =array.borrow(controls,i)
    if c.action==action and str.eq(chrome.kind_of(c),kind) and str.eq(chrome.name_of(c),name) {return option.some(i)}
    i=i+1}
  option.none()
}
fn click_property(state:ref<app.App>,action:u32,kind:str,name:str) -> bool effects {alloc,fs.meta,fs.read,fs.write,process,time} {
  let frame:layout.Frame=layout.frame(1600.0,980.0)
  app.set_dock_tab(state,chrome.tab_properties())
  let _=app.set_dock_scroll(state,0.0)
  var initial:array<chrome.Control> =chrome.properties_panel(frame,state)
  let old:u64=match row(initial,action,kind,name) {none=>{return false},some(i)=>i,}
  let top:f64=struct.get(array.borrow(initial,old),field=area).top
  let _=app.set_dock_scroll(state,math.max(0.0,top-frame.dock_body.top-70.0))
  var visible:array<chrome.Control> =chrome.properties_panel(frame,state)
  let at:u64=match row(visible,action,kind,name) {none=>{return false},some(i)=>i,}
  let c:ref<chrome.Control> =array.borrow(visible,at)
  if not c.enabled {return false}
  let box:layout.Rect=c.area
  if box.top<frame.dock_body.top or box.bottom>frame.dock_body.bottom {return false}
  let x:f64=(box.left+box.right)*0.5
  let y:f64=(box.top+box.bottom)*0.5
  let _=input.pointer_down(state,1600.0,980.0,x,y)
  let _=input.pointer_up(state,1600.0,980.0,x,y)
  true
}
'''
s=s.replace('pub fn main(args:view<str>)',helper+'pub fn main(args:view<str>)')
end='  test.conclude(suite,path.join(root,"linked-media-tests.json"),23)'
more='''  let _=test.start(suite,"Properties Audio rows display and edit the actual mate while V stays selected")
  let _=ref.swap(state,fixture(root))
  let selected:u64=app.current_clip(state)
  let sound:u64=linked.mate(struct.borrow(state,field=document),selected)
  let _=editor.set_clip_gain(struct.borrow(state,field=document),selected,1.7)
  let _=editor.set_clip_gain(struct.borrow(state,field=document),sound,0.35)
  let _=commands.seek(state,12)
  let frame:layout.Frame=layout.frame(1600.0,980.0)
  var rows:array<chrome.Control> =chrome.properties_panel(frame,state)
  let gain_row:option<u64>=row(rows,chrome.act_param_set(),"","gain")
  let found:bool=match gain_row {none=>false,some(index)=>{
    let c:ref<chrome.Control> =array.borrow(rows,index)
    let _=test.eq_u64(suite,c.target,sound,"Rendered Properties audio gain targets actual A clip")
    let _=test.near_f64(suite,c.value,0.35,0.000000001,"Rendered value comes from A, not V gain1.7")
    c.domain==chrome.domain_clip() and c.enabled},}
  let _=test.check(suite,found,"Properties exposes an enabled actual audio control")
  let _=test.check(suite,click_property(state,chrome.act_param_inc(),"","gain"),"Pointer hits visible gain+ in real shared Properties control list")
  let _=test.near_f64(suite,option.unwrap(editor.clip(struct.borrow(state,field=document),sound)).gain,0.4,0.000000001,"Gain+ changes A by its declared .05 step")
  let _=test.near_f64(suite,option.unwrap(editor.clip(struct.borrow(state,field=document),selected)).gain,1.7,0.000000001,"Gain+ leaves picture-only V untouched")
  let _=test.check(suite,click_property(state,chrome.act_param_dec(),"","gain"),"Pointer hits gain- on A")
  let _=test.near_f64(suite,option.unwrap(editor.clip(struct.borrow(state,field=document),sound)).gain,0.35,0.000000001,"Gain- restores A authored value")
  rows=chrome.properties_panel(frame,state)
  let key_row:option<u64>=row(rows,chrome.act_param_key(),"","gain")
  let correct_key:bool=match key_row {none=>false,some(index)=>struct.get(array.borrow(rows,index),field=target)==sound,}
  let _=test.check(suite,correct_key,"Rendered gain K carries actual A target")
  let _=test.check(suite,click_property(state,chrome.act_param_key(),"","gain"),"Pointer gain K invokes audio key command while V remains selected")
  let _=test.eq_u64(suite,editor.key_count(struct.borrow(state,field=document),sound,"gain"),1,"A owns the audible key")
  let _=test.eq_u64(suite,editor.key_count(struct.borrow(state,field=document),selected,"gain"),0,"V has no silent fake audio key")
  let _=test.near_f64(suite,editor.clip_value_at(struct.borrow(state,field=document),sound,"gain",12,99.0),0.35,0.000000001,"Key value and clip-local time are exact")
  let _=test.eq_u64(suite,app.current_clip(state),selected,"Pointer audio edits preserve V selection")
  let _=test.done(suite)

  let _=test.start(suite,"Properties EQ and compressor lookup and pointer edits belong to A")
  let doc:ref<editor.Document> =struct.borrow(state,field=document)
  let veq:u64=option.unwrap(editor.add_filter(doc,selected,"eq_3band"))
  let aeq:u64=option.unwrap(editor.add_filter(doc,sound,"eq_3band"))
  let vc:u64=option.unwrap(editor.add_filter(doc,selected,"compressor"))
  let ac:u64=option.unwrap(editor.add_filter(doc,sound,"compressor"))
  let _=editor.set_filter_param(doc,veq,"low",-7.0)
  let _=editor.set_filter_param(doc,aeq,"low",3.5)
  let _=editor.set_filter_param(doc,vc,"threshold",-1.0)
  let _=editor.set_filter_param(doc,ac,"threshold",-24.0)
  rows=chrome.properties_panel(frame,state)
  let eq_row:option<u64>=row(rows,chrome.act_param_set(),"eq_3band","low")
  let correct_eq:bool=match eq_row {none=>false,some(index)=>{
    let c:ref<chrome.Control> =array.borrow(rows,index)
    c.target==aeq and math.abs(c.value-3.5)<0.000000001},}
  let _=test.check(suite,correct_eq,"Rendered EQ row resolves A instance/value despite distinct V instance")
  let comp_row:option<u64>=row(rows,chrome.act_param_set(),"compressor","threshold")
  let correct_comp:bool=match comp_row {none=>false,some(index)=>{
    let c:ref<chrome.Control> =array.borrow(rows,index)
    c.target==ac and math.abs(c.value+24.0)<0.000000001},}
  let _=test.check(suite,correct_comp,"Rendered compressor resolves actual A filter/value")
  let _=test.check(suite,click_property(state,chrome.act_param_inc(),"eq_3band","low"),"Actual EQ+ pointer control is reachable")
  let _=test.near_f64(suite,editor.filter_param(struct.borrow(state,field=document),aeq,"low",99.0),4.0,0.000000001,"EQ+ changes actual A filter")
  let _=test.near_f64(suite,editor.filter_param(struct.borrow(state,field=document),veq,"low",99.0),-7.0,0.000000001,"EQ+ leaves V instance unchanged")
  let _=test.check(suite,click_property(state,chrome.act_param_inc(),"compressor","threshold"),"Actual compressor+ control is reachable")
  let _=test.near_f64(suite,editor.filter_param(struct.borrow(state,field=document),ac,"threshold",99.0),-23.0,0.000000001,"Compressor changes A threshold by declared1dB step")
  let _=test.near_f64(suite,editor.filter_param(struct.borrow(state,field=document),vc,"threshold",99.0),-1.0,0.000000001,"Compressor leaves V instance unchanged")
  let _=test.done(suite)

  let _=test.start(suite,"Grouping V selection retains all mates and paired nudge with exact Undo/Redo")
  let _=ref.swap(state,fixture(root))
  let first:u64=app.current_clip(state)
  let source_id:u64=option.unwrap(editor.clip(struct.borrow(state,field=document),first)).source
  let second:commands.Result=commands.append_source(state,source_id,100,30)
  let first_audio:u64=linked.mate(struct.borrow(state,field=document),first)
  let second_audio:u64=linked.mate(struct.borrow(state,field=document),second.value)
  let _=commands.select_only(state,first)
  let _=commands.add_to_selection(state,second.value)
  let original:string=encoded(struct.borrow(state,field=document))
  let depth:u64=editor.undo_depth(struct.borrow(state,field=history))
  let grouped:commands.Result=commands.group_selection(state)
  let _=test.check(suite,grouped.ok,"Two selected V clips expand their existing A mates before Group")
  if grouped.ok {
    let doc:ref<editor.Document> =struct.borrow(state,field=document)
    let _=test.check(suite,option.unwrap(editor.clip(doc,first)).group==grouped.value and option.unwrap(editor.clip(doc,second.value)).group==grouped.value and option.unwrap(editor.clip(doc,first_audio)).group==grouped.value and option.unwrap(editor.clip(doc,second_audio)).group==grouped.value,"All four actual pieces share the new user group")
    let _=test.eq_u64(suite,linked.mate(doc,first),first_audio,"First pair remains uniquely linked")
    let _=test.eq_u64(suite,linked.mate(doc,second.value),second_audio,"Second pair remains uniquely linked")
    let after:string=encoded(doc)
    roundtrip(suite,state,original,after,depth)
    let nudge_before:string=encoded(struct.borrow(state,field=document))
    let nudge_depth:u64=editor.undo_depth(struct.borrow(state,field=history))
    let moved:commands.Result=commands.nudge(state,first,5)
    let _=test.check(suite,moved.ok,"Paired nudge still works inside expanded user group")
    pair(suite,state,first,5,10,90)
    pair(suite,state,second.value,90,100,30)
    let nudge_after:string=encoded(struct.borrow(state,field=document))
    roundtrip(suite,state,nudge_before,nudge_after,nudge_depth)}
  let _=test.done(suite)

  let _=test.start(suite,"Invalid/locked/ambiguous grouping refuses without graph or history changes")
  let _=ref.swap(state,fixture(root))
  let first:u64=app.current_clip(state)
  let initial:string=stable(state)
  let lonely:commands.Result=commands.group_selection(state)
  let _=test.check(suite,not lonely.ok,"One selected V does not silently group its already linked pair")
  let _=test.eq_str(suite,stable(state),initial,"Failed insufficient-selection Group captures nothing")
  let source_id:u64=option.unwrap(editor.clip(struct.borrow(state,field=document),first)).source
  let second:commands.Result=commands.append_source(state,source_id,100,30)
  let _=commands.select_only(state,first)
  let _=commands.add_to_selection(state,second.value)
  let audio_lane:u64=app.default_audio_track(state)
  let _=editor.set_track_lock(struct.borrow(state,field=document),audio_lane,true)
  let locked:string=stable(state)
  let refusal:commands.Result=commands.group_selection(state)
  let _=test.check(suite,not refusal.ok,"Locked expanded mate lane refuses Group atomically")
  let _=test.eq_str(suite,stable(state),locked,"Locked Group leaves original pair memberships and revision/history unchanged")
  let _=editor.set_track_lock(struct.borrow(state,field=document),audio_lane,false)
  let second_audio:u64=linked.mate(struct.borrow(state,field=document),second.value)
  let doc:ref<editor.Document> =struct.borrow(state,field=document)
  let _=editor.move_clip(doc,second.value,app.default_video_track(state),0)
  let _=editor.move_clip(doc,second_audio,audio_lane,0)
  let _=editor.slip(doc,second.value,-90)
  let _=editor.slip(doc,second_audio,-90)
  let _=editor.trim_end(doc,first,30)
  let first_audio:u64=linked.mate(doc,first)
  let _=editor.trim_end(doc,first_audio,30)
  let ambiguous:string=stable(state)
  let refuse_ambiguous:commands.Result=commands.group_selection(state)
  let _=test.check(suite,not refuse_ambiguous.ok,"Identical mappings would lose unique mate identity and must refuse")
  let _=test.eq_str(suite,stable(state),ambiguous,"Ambiguous Group preserves all original memberships and snapshots")
  let _=test.done(suite)
'''
assert end in s;s=s.replace(end,more+'  test.conclude(suite,path.join(root,"linked-media-tests.json"),27)')
s=s.replace('option<u64>=','option<u64> =')
p.write_text(s,newline='\n')
