from pathlib import Path
import hashlib
import json

root = Path(__file__).resolve().parents[2]
work = Path(__file__).resolve().parent
frozen_path = root / 'build-windows/linked-lanes-contract-final-frozen.json'
frozen = json.loads(frozen_path.read_text())
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
production = {name: digest for name, digest in frozen['source_sha256'].items()
              if name.startswith('src/')}
overlays = {name: frozen['source_sha256'][name] for name in
            ['patches/air-editor.patch', 'patches/air-editor-io.patch',
             'patches/air-channel-deadlines.patch']}
for name, digest in {**production, **overlays}.items():
    assert sha(root / name) == digest, f'Frozen production/overlay drift: {name}'
sdk_sources = frozen['sdk_source_sha256']
for name, digest in sdk_sources.items():
    assert sha(root / 'build-windows/AIR-SDK' / name) == digest, f'Frozen SDK drift: {name}'
paths = ['linked-1080.ai', 'linked-1080.c', 'CMakeLists.txt',
         'native/Release/genesis-linked-1080.exe']
receipt = {
    'schema': 'genesis.linked_1080.client_build.v3', 'build_passed': True,
    'media_execution': 'not run; awaits root background gate',
    'freeze': 'linked-lanes-contract-final',
    'frozen_manifest_sha256': sha(frozen_path),
    'sdk_pin': frozen['sdk_pin'], 'worker_pin': frozen['worker_pin'],
    'compiler_sha256': '71ee6acdbfb48470da4d3ae946c8825e7abe3b7fa06c45f86b92ac9adaaa5dfa',
    'compiler': '/root/Genesis-AIR-compiler/bin/airc',
    'compiler_args': ['build', '--mode', 'release', '--provider',
                      'hash.sha256=portable', '--keep-c'],
    'c_compiler': 'MSVC19.44.35229, x64, static runtime, Release/O2/bigobj',
    'runtime_lib': {
        'path': 'build-windows/pro-content-stream-final-native/runtime/Release/air_rt.lib',
        'sha256': sha(root / 'build-windows/pro-content-stream-final-native/runtime/Release/air_rt.lib')},
    'production_sha256': production,
    'helper_sha256': {name: sha(work / name) for name in paths},
    'sdk_sources_sha256': sdk_sources,
    'overlay_sha256': overlays,
    'expected_cases': 3, 'expected_checks': 22,
    'arguments': ['PRIVATE_OUTPUT_ROOT', 'STAGED_WORKER_EXE',
                  r'C:\Users\Alexn\Downloads\AirFetch\Which is The Best Qwen3.8-27B_.mp4'],
    'source_expected_sha256': '061d76990215c31e6dc58d22f4ecd09ac92d414fdc73061e8dfcb502cee3f11d',
    'outputs': ['linked-1080-tests.json', 'linked-180.air',
                'scopes-0.png', 'scopes-90.png', 'scopes-179.png'],
    'scope': 'Readonly180frame60fps clip; paired routing, processed A wavecache, '
             'V source/time bitmaps, shared scope/lane PNG raster. No desktop '
             'or device playback. Existing detailed gates establish accuracy '
             'beyond raster existence.'}
(work / 'build-receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({'passed': True,
                  'client_sha256': receipt['helper_sha256']['native/Release/genesis-linked-1080.exe'],
                  'receipt_sha256': sha(work / 'build-receipt.json'),
                  'helper_sha256': receipt['helper_sha256']}, indent=2))
