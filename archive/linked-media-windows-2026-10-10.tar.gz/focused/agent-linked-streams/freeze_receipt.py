from pathlib import Path
import hashlib,json,subprocess
r=Path.cwd(); f=r/'build-windows/agent-linked-streams'; sdk=r/'build-windows/AIR-SDK'
digest=lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
overlay=json.loads((f/'overlay-receipt.json').read_text())
reports=[]
for execution in ['windows','linux','interp']:
    p=f/execution/'linked-streams-sdk-tests.json'
    actual=json.loads(p.read_text())['payload']
    assert actual['status']=='pass' and actual['checks']==77 and actual['cases']['passed']==7 and actual['cases']['failed']==0
    reports.append({'execution':execution,'path':p.relative_to(r).as_posix(),'cases':7,'checks':77,'sha256':digest(p)})
files=['patches/air-editor.patch','patches/air-editor-io.patch','build-windows/AIR-SDK/stdlib/editor.ai','build-windows/AIR-SDK/stdlib/editor_io.ai','build-windows/agent-linked-streams/streams.ai','build-windows/agent-linked-streams/streams.c','build-windows/agent-linked-streams/native/Release/genesis-linked-streams-sdk.exe']
for patch in ['air-editor.patch','air-editor-io.patch']:
    subprocess.run(['git','-C',str(sdk),'apply','--reverse','--check',str(r/'patches'/patch)],check=True)
receipt={'schema':'genesis.linked_streams.sdk.v1','passed':True,'sdk_pin':overlay['sdk_pin'],'masks':{'video':1,'audio':2,'legacy_both':3},'invalid_zero_refused':True,'schema_revision':2,'legacy_encoder_omits_default':True,'all_31_sdk_clip_literals_carry_streams':True,'overlay':overlay,'files':{name:digest(r/name) for name in files},'reports':reports,'scope':'Focused shared model/serialization CPU proof only; no native desktop, audio device, worker media, full build or publication.'}
(f/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
print(json.dumps(receipt['files'],indent=2));print('Final seven cases / 77 checks passed on Windows, Linux and interpreter; both reverse overlays still valid')
