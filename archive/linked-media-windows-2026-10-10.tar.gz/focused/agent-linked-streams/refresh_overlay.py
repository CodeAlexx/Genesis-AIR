from pathlib import Path
import difflib, hashlib, json, subprocess
r=Path.cwd(); sdk=r/'build-windows/AIR-SDK'; out=r/'build-windows/agent-linked-streams'
def git(where,*args):
    return subprocess.run(['git','-c','core.autocrlf=false','-C',str(where),*args],check=True,stdout=subprocess.PIPE).stdout
pin=git(sdk,'rev-parse','HEAD').decode().strip()
assert pin=='df80f270dd28af76674b6e80a4f08970c081be3e'
proof=out/'overlay-base'; (proof/'stdlib').mkdir(parents=True,exist_ok=True)
if not (proof/'.git').exists(): git(proof,'init')
receipts={}
for name in ('editor.ai','editor_io.ai'):
    base=git(sdk,'show','HEAD:stdlib/'+name).replace(b'\r\n',b'\n')
    target=(sdk/'stdlib'/name).read_bytes().replace(b'\r\n',b'\n')
    patch=r/'patches'/('air-editor.patch' if name=='editor.ai' else 'air-editor-io.patch')
    if patch.exists() and not (out/(patch.name+'.before')).exists():
        (out/(patch.name+'.before')).write_bytes(patch.read_bytes())
    diff='diff --git a/stdlib/'+name+' b/stdlib/'+name+'\n'+''.join(difflib.unified_diff(base.decode().splitlines(keepends=True),target.decode().splitlines(keepends=True),fromfile='a/stdlib/'+name,tofile='b/stdlib/'+name))
    assert len(diff)>100
    patch.write_bytes(diff.encode('utf-8'))
    restored=proof/'stdlib'/name; restored.write_bytes(base)
    git(proof,'apply','--check',str(patch)); git(proof,'apply',str(patch))
    assert restored.read_bytes()==target
    git(proof,'apply','--reverse','--check',str(patch))
    git(sdk,'apply','--reverse','--check',str(patch))
    receipts[name]={'source_sha256':hashlib.sha256((sdk/'stdlib'/name).read_bytes()).hexdigest(),'source_lf_sha256':hashlib.sha256(target).hexdigest(),'patch_sha256':hashlib.sha256(patch.read_bytes()).hexdigest(),'forward':True,'reverse':True,'source_roundtrip':True}
payload={'sdk_pin':pin,'schema_revision':2,'legacy_default_mask':3,'legacy_encoder_omits_both':True,'files':receipts}
(out/'overlay-receipt.json').write_text(json.dumps(payload,indent=2)+'\n',encoding='utf-8')
print(json.dumps(payload,indent=2))
