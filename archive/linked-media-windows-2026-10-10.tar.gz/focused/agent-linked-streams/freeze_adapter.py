from pathlib import Path
import json,hashlib
root=Path(__file__).resolve().parents[2]
work=root/'build-windows/agent-linked-streams'
paths=['src/linked_media.ai','build-windows/agent-linked-streams/linked-adapter.ai','build-windows/agent-linked-streams/linked-adapter.c','build-windows/agent-linked-streams/native/Release/genesis-linked-adapter.exe']
reports={}
for platform in ['windows','linux','interpreter']:
 p=work/f' adapter-{platform}'.strip()/'linked-adapter-tests.json'
 v=json.loads(p.read_text())['payload']
 assert v['status']=='pass' and v['cases']['total']==6 and v['checks']==41
 paths.append(p.relative_to(root).as_posix()); reports[platform]=v
hashes={name:hashlib.sha256((root/name).read_bytes()).hexdigest() for name in paths}
assert hashes['src/linked_media.ai'].upper()=='490C865704B48E42BBF38B66C8CD45B80EF786ECD760A4F28A1E733EE94C58A8'
(work/'linked-adapter-receipt.json').write_text(json.dumps({'schema':'genesis.linked_media.private.v1','passed':True,'cases':6,'checks':41,'platforms':list(reports),'hashes':hashes,'scope':'Pure document routing/content/atomicity; no native media or desktop'},indent=2)+'\n')
print(json.dumps({'passed':True,'cases':6,'checks':41,'hashes':hashes},indent=2))
