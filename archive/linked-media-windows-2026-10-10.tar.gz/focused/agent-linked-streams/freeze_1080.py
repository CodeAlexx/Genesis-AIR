from pathlib import Path
import json,hashlib
root=Path(__file__).resolve().parents[2]
work=root/'build-windows/agent-linked-streams'
paths=['src/linked_media.ai','src/commands.ai','src/app.ai','src/input.ai','src/preview.ai','src/preview_link.ai','src/view.ai','src/chrome.ai','src/timeline_media.ai','build-windows/AIR-SDK/stdlib/editor.ai','build-windows/AIR-SDK/stdlib/editor_io.ai','build-windows/agent-linked-streams/linked-1080.ai','build-windows/agent-linked-streams/linked-1080.c','build-windows/agent-linked-streams/native/Release/genesis-linked-1080.exe']
hashes={name:hashlib.sha256((root/name).read_bytes()).hexdigest() for name in paths}
assert hashes['src/linked_media.ai'].upper()=='DFA39B1500DE4092E8AB2A8BC5D6B7802BAF98D41F67E1E86352CD6135893411'
receipt={'schema':'genesis.linked_1080.client_build.v1','build_passed':True,'media_execution':'pending root suite terminal','expected_cases':3,'expected_checks':22,'command':'CLIENT PRIVATE_OUTPUT_ROOT STAGED_WORKER SOURCE','source_expected_sha256':'061d76990215c31e6dc58d22f4ecd09ac92d414fdc73061e8dfcb502cee3f11d','source_readonly':True,'scope':'180ownerframes60fps; V bitmaps/A processed peaks; seek0/90/179; shared scopes raster; no desktop/device','outputs':['linked-1080-tests.json','linked-180.air','scopes-0.png','scopes-90.png','scopes-179.png'],'hashes':hashes}
(work/'linked-1080-build.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt,indent=2))
