from pathlib import Path
import re

root = Path.cwd()
folder = root / 'build-windows/agent-linked-streams'
sdk = root / 'build-windows/AIR-SDK/stdlib'
folder.mkdir(parents=True, exist_ok=True)
for name in ('editor.ai', 'editor_io.ai'):
    backup = folder / ('before-' + name)
    if backup.exists():
        assert backup.read_bytes() == (sdk/name).read_bytes(), 'Already mutated; do not rerun'
    else:
        backup.write_bytes((sdk / name).read_bytes())

p = sdk / 'editor.ai'
s = p.read_text(encoding='utf-8')
anchor = 'pub fn track_audio() -> u32 effects {} { 1 }'
assert s.count(anchor) == 1
s = s.replace(anchor, anchor + '''

// Explicit stream routing is independent of lane presentation and scalar gain.
// Legacy clips route both streams; zero is never an admitted mask.
pub fn streams_video() -> u32 effects {} { 1 }
pub fn streams_audio() -> u32 effects {} { 2 }
pub fn streams_both() -> u32 effects {} { 3 }
pub fn stream_mask_valid(value: u32) -> bool effects {} { value >= 1 and value <= 3 }
pub fn clip_has_video(value: Clip) -> bool effects {} { value.streams == 1 or value.streams == 3 }
pub fn clip_has_audio(value: Clip) -> bool effects {} { value.streams == 2 or value.streams == 3 }
pub fn clip_streams(doc: ref<Document>, id: u64) -> u32 effects {} {
  match clip(doc,id) {some(value)=>value.streams,none=>0,}
}
pub fn set_clip_streams(doc: ref<Document>, id: u64, value: u32) -> bool effects {} {
  if not stream_mask_valid(value) {return false}
  match clip_slot(doc,id) {
    none=>false,some(slot)=>{
      struct.set(array.borrow(struct.borrow(doc,field=clips),slot),value,field=streams)
      true
    },
  }
}''')
anchor = '  speed: f64,\n  reverse: bool\n}'
assert s.count(anchor) == 1
s = s.replace(anchor, '  speed: f64,\n  reverse: bool,\n  streams: u32\n}')

# Every record reconstruction must carry the original stream route. Only new
# placements default to both; the new still inherits its original clip route.
pattern = re.compile(r'\bClip\s*\{')
changes = []
for match in pattern.finditer(s):
    start = match.end()
    depth = 1
    end = start
    while depth:
        if s[end] == '{': depth += 1
        elif s[end] == '}': depth -= 1
        end += 1
    block = s[start:end-1]
    assert 'streams:' not in block
    original = re.search(r'\bid\s*:\s*(old|value|moved|current)\.id', block)
    if original:
        value = original.group(1) + '.streams'
    elif re.search(r'\breverse\s*:\s*old\.reverse', block):
        value = 'old.streams'
    elif re.search(r'\bid\s*:\s*still\b', block):
        value = 'old.streams'
    elif re.search(r'\bid\s*:\s*right\b', block):
        value = 'old.streams'
    else:
        assert re.search(r'\bid\s*:\s*id\b', block), block
        value = 'streams_both()'
    changes.append((end-1, ', streams:' + value))
for at, text in reversed(changes): s = s[:at] + text + s[at:]
assert len(changes) == 31, len(changes)

# The existing detach API remains otherwise unchanged; the route, rather than
# gain alone, prevents authored gain keys from reviving original embedded sound.
begin = s.index('pub fn detach_audio(')
finish = s.index('// FREEZE FRAME', begin)
part = s[begin:finish]
assert part.count('streams:old.streams') == 1 and part.count('streams:current.streams') == 1
part = part.replace('streams:old.streams', 'streams:streams_audio()')
part = part.replace('streams:current.streams', 'streams:streams_video()')
part = part.replace('group: 0, enabled: true, selected: false,', 'group: 0, enabled: old.enabled, selected: false,')
s = s[:begin] + part + s[finish:]
s = s.replace('// Genesis `detach_audio`, which likewise uses only existing fields. Returns the clone\'s id.',
              '// The explicit stream route suppresses the original even when it owns gain keys. Returns the clone\'s id.')
# Refuse corrupt externally constructed snapshots before lifting any survivors.
anchor = '  let old:Clip=saved.clip\n'
assert s.count(anchor) == 1
s = s.replace(anchor, anchor + '  if not stream_mask_valid(old.streams) {return result.err("clipboard stream mask is invalid")}\n')
p.write_bytes(s.replace('\n', '\r\n').encode('utf-8'))

p = sdk / 'editor_io.ai'
s = p.read_text(encoding='utf-8')
anchor = '  codec.field_bool(w, "reverse", value.reverse)\n'
assert s.count(anchor) == 1
s = s.replace(anchor, anchor + '  if value.streams != editor.streams_both() {codec.field_u64(w,"streams",cast.wrap(value.streams))}\n')
anchor = 'pub fn encode(doc: ref<editor.Document>) -> result<string, codec.Error> effects {alloc} {\n'
assert s.count(anchor) == 1
s = s.replace(anchor, anchor + '''  var stream_at: u64 = 0
  loop {if stream_at >= array.len(struct.borrow(doc,field=clips)) {break}
    let value: editor.Clip = array.get(struct.borrow(doc,field=clips),stream_at)
    if not editor.stream_mask_valid(value.streams) {
      let at: string = text.concat("/clips/",text.concat(string.from_int(stream_at),"/streams"))
      return result.err(codec.error(codec.Code.Range,at,"stream mask 1..3",string.from_int(value.streams)))
    }
    stream_at=stream_at+1
  }
''')
s = s.replace('import std.json as json\n', 'import std.json as json\nimport std.text as text\n')
anchor = '        let reverse: bool = try codec.bool_field(document, entry, "reverse")\n'
assert s.count(anchor) == 1
s = s.replace(anchor, anchor + '''        let streams: u64 = try codec.u64_or(document,entry,"streams",3)
        if streams < 1 or streams > 3 {
          let at: string = text.concat(codec.reader_path(entry),"/streams")
          return result.err(codec.error(codec.Code.Range,at,"stream mask 1..3",string.from_int(streams)))
        }
''')
anchor = '          reverse: reverse})'
assert s.count(anchor) == 1
s = s.replace(anchor, '          reverse: reverse, streams: cast.sat(streams)})')
p.write_bytes(s.replace('\n', '\r\n').encode('utf-8'))
print('Stream mask added to',len(changes),'SDK clip reconstructions and revision2 persistence')
