from pathlib import Path
import json,hashlib
root=Path(__file__).resolve().parents[2]
work=root/'build-windows/agent-linked-streams'
paths=['src/linked_media.ai','build-windows/agent-linked-streams/linked-adapter.ai','build-windows/agent-linked-streams/linked-adapter.c','build-windows/agent-linked-streams/native/Release/genesis-linked-adapter.exe']
reports={}
for platform in ['windows','linux','interpreter']:
 p=work/f' adapter-import-{platform}'.strip()/'linked-adapter-tests.json'
 v=json.loads(p.read_text())['payload']
 assert v['status']=='pass' and v['cases']['total']==7 and v['checks']==47
 paths.append(p.relative_to(root).as_posix()); reports[platform]=v
hashes={name:hashlib.sha256((root/name).read_bytes()).hexdigest() for name in paths}
assert hashes['src/linked_media.ai'].upper()=='DFA39B1500DE4092E8AB2A8BC5D6B7802BAF98D41F67E1E86352CD6135893411'
(work/'linked-adapter-import-receipt.json').write_text(json.dumps({'schema':'genesis.linked_media.private.v1','passed':True,'cases':7,'checks':47,'platforms':list(reports),'hashes':hashes,'scope':'Pure document routing/content/atomicity; no native media or desktop'},indent=2)+'\n')
print(json.dumps({'passed':True,'cases':7,'checks':47,'hashes':hashes},indent=2))
